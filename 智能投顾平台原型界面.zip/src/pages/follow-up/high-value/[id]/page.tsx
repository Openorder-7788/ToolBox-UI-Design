import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MainLayout from '../../../../components/layout/MainLayout';
import Button from '../../../../components/common/Button';
import { highValueCustomers } from '../../../../mocks/followUpTasks';

// 获取客户详情的辅助函数
const getCustomerDetail = (id: string) => {
  return highValueCustomers.find(customer => customer.id === id);
};

// 推荐话术数据
const recommendedScripts = [
  {
    id: 'SCR003',
    title: '服务升级沟通话术',
    style: '专业型',
    scene: '服务升级',
    summary: '您好，根据您近期的投资情况和资产规模，我们注意到您可能适合我们的专属投顾服务。这项服务包括一对一投资顾问、定制化资产配置方案等...',
  },
  {
    id: 'SCR008',
    title: '高端服务价值介绍话术',
    style: '专业型',
    scene: '服务介绍',
    summary: '作为我们的高价值客户，专属投顾服务能为您提供更加个性化的投资建议和全方位的资产管理支持...',
  },
];

// 推荐产品数据
const recommendedProducts = [
  {
    id: 'AP002',
    name: '专属投顾服务 - 尊享版',
    type: '专属服务',
    price: '¥2999/月',
    reason: '客户资产规模已达到高阶服务标准，可享受一对一专属顾问服务',
    tags: ['一对一', '定制化', '高端服务'],
  },
  {
    id: 'AP007',
    name: '家庭财富规划服务',
    type: '专属服务',
    price: '¥4999/年',
    reason: '适合高净值客户进行家庭整体财富配置和长期规划',
    tags: ['家庭理财', '长期规划', '全面配置'],
  },
];

// 推荐投教内容
const recommendedContent = [
  {
    id: 'AC002',
    title: '投顾服务全解析：专属投顾能为你做什么',
    type: '服务说明',
    duration: '10 分钟',
    reason: '帮助客户了解专属投顾服务的价值',
  },
  {
    id: 'AC007',
    title: '家庭财富规划：不同人生阶段的理财重点',
    type: '投教图文',
    duration: '12 分钟',
    reason: '适合高净值客户的财富规划需求',
  },
];

const CustomerDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const customer = getCustomerDetail(id || '');
  
  const [isEditingTags, setIsEditingTags] = useState(false);
  const [managerTags, setManagerTags] = useState(['关注服务升级', '沟通配合度高', '决策谨慎']);
  const [newTag, setNewTag] = useState('');
  const [showAddNote, setShowAddNote] = useState(false);
  const [noteContent, setNoteContent] = useState('');

  if (!customer) {
    return (
      <MainLayout>
        <div className="p-6">
          <div className="text-center py-12">
            <i className="ri-error-warning-line text-6xl text-gray-300 w-16 h-16 flex items-center justify-center mx-auto mb-4"></i>
            <p className="text-gray-500">客户信息不存在</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  const handleAddTag = () => {
    if (newTag.trim()) {
      setManagerTags([...managerTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (index: number) => {
    setManagerTags(managerTags.filter((_, i) => i !== index));
  };

  const handleCopyScript = (script: any) => {
    navigator.clipboard.writeText(script.summary);
    alert('话术已复制到剪贴板');
  };

  const handleAddCommunicationNote = () => {
    if (noteContent.trim()) {
      alert('沟通记录已添加');
      setNoteContent('');
      setShowAddNote(false);
    }
  };

  const handleWeChatCommunication = () => {
    navigate(`/wechat-sidebar/customer-info?id=${id}`);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* 1️⃣ 客户基础信息区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white text-2xl font-semibold relative">
                {customer.name.charAt(0)}
                <i className="ri-vip-crown-fill absolute -top-1 -right-1 text-yellow-300 text-xl w-5 h-5 flex items-center justify-center"></i>
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-semibold text-gray-900">{customer.name}</h1>
                  <span className="px-3 py-1 bg-amber-50 text-amber-700 text-sm font-medium rounded-full">
                    {customer.valueLevel}
                  </span>
                  <span className="px-3 py-1 bg-purple-50 text-purple-700 text-sm font-medium rounded-full">
                    待服务升级
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>客户编号：{customer.id}</span>
                  <span>•</span>
                  <span>服务时长：{customer.serviceHistory}</span>
                </div>
              </div>
            </div>
            <Button onClick={() => navigate('/follow-up/high-value')}>
              <i className="ri-arrow-left-line mr-2"></i>
              返回列表
            </Button>
          </div>

          <div className="grid grid-cols-4 gap-6 pt-6 border-t border-gray-200">
            <div>
              <div className="text-sm text-gray-500 mb-1">联系电话</div>
              <div className="text-base font-medium text-gray-900">{customer.phone}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">资产规模</div>
              <div className="text-base font-medium text-amber-600 text-lg">{customer.assets}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">风险偏好</div>
              <div className="text-base font-medium text-gray-900">{customer.riskLevel}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">交易频次</div>
              <div className="text-base font-medium text-gray-900">{customer.tradingFrequency}</div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              客户信息仅用于内部服务管理
            </p>
          </div>
        </div>

        {/* 2️⃣ 客户画像与标签区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">客户画像与标签</h2>

          {/* 系统标签 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <h3 className="text-sm font-medium text-gray-700">系统标签</h3>
              <span className="text-xs text-gray-400">(系统生成，只读)</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-shield-check-line text-lg text-amber-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">风险偏好</div>
                  <div className="text-sm font-medium text-gray-900">{customer.riskLevel}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-line-chart-line text-lg text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">投资阶段</div>
                  <div className="text-sm font-medium text-gray-900">成熟期</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-pulse-line text-lg text-green-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">生命周期</div>
                  <div className="text-sm font-medium text-gray-900">活跃期</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-star-line text-lg text-purple-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">服务匹配度</div>
                  <div className="text-sm font-medium text-gray-900">{customer.matchScore}%</div>
                </div>
              </div>
            </div>
          </div>

          {/* 客户经理标签 */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-medium text-gray-700">客户经理标签</h3>
                <span className="text-xs text-gray-400">(可编辑)</span>
              </div>
              <button
                onClick={() => setIsEditingTags(!isEditingTags)}
                className="text-sm text-amber-600 hover:text-amber-700 cursor-pointer whitespace-nowrap"
              >
                {isEditingTags ? '完成编辑' : '编辑标签'}
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {managerTags.map((tag, index) => (
                <span
                  key={index}
                  className="px-3 py-1.5 bg-amber-50 text-amber-700 text-sm rounded-full flex items-center gap-2"
                >
                  {tag}
                  {isEditingTags && (
                    <button
                      onClick={() => handleRemoveTag(index)}
                      className="hover:text-amber-900 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-close-line"></i>
                    </button>
                  )}
                </span>
              ))}
              {isEditingTags && (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="输入新标签"
                    className="px-3 py-1.5 border border-gray-300 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                  />
                  <button
                    onClick={handleAddTag}
                    className="px-3 py-1.5 bg-amber-600 text-white text-sm rounded-full hover:bg-amber-700 cursor-pointer whitespace-nowrap"
                  >
                    添加
                  </button>
                </div>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-3">
              <i className="ri-information-line mr-1"></i>
              标签编辑行为将记录为操作日志
            </p>
          </div>
        </div>

        {/* 3️⃣ 客户跟进进度管理区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">跟进进度管理</h2>
            <span className="text-sm text-gray-500">当前阶段：已推荐服务</span>
          </div>

          <div className="relative">
            <div className="flex items-center justify-between">
              {[
                { id: 1, name: '已触达', completed: true },
                { id: 2, name: '已沟通', completed: true },
                { id: 3, name: '已推荐服务', completed: true },
                { id: 4, name: '客户考虑中', completed: false },
                { id: 5, name: '已转化', completed: false },
              ].map((stage, index, arr) => (
                <div key={stage.id} className="flex flex-col items-center flex-1">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold mb-2 ${
                      stage.completed
                        ? 'bg-amber-600 text-white'
                        : index === 3
                        ? 'bg-amber-100 text-amber-600 border-2 border-amber-600'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                  >
                    {stage.completed ? <i className="ri-check-line"></i> : stage.id}
                  </div>
                  <div
                    className={`text-sm text-center ${
                      stage.completed || index === 3
                        ? 'text-gray-900 font-medium'
                        : 'text-gray-400'
                    }`}
                  >
                    {stage.name}
                  </div>
                  {index < arr.length - 1 && (
                    <div
                      className={`absolute top-5 h-0.5 ${
                        stage.completed ? 'bg-amber-600' : 'bg-gray-200'
                      }`}
                      style={{
                        left: `${(index / (arr.length - 1)) * 100 + 10}%`,
                        width: `${80 / (arr.length - 1)}%`,
                      }}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              进度状态仅用于服务管理参考，客户经理可手动调整当前进度
            </p>
          </div>
        </div>

        {/* 4️⃣ AI 跟进建议区 */}
        <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border border-purple-200 p-6">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
              <i className="ri-sparkling-line text-white text-lg"></i>
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">AI 跟进建议</h2>
              <p className="text-sm text-gray-600 mb-4">
                基于客户当前状态与行为分析，为您提供以下服务建议
              </p>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 mb-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-2">当前客户状态解读</h3>
            <p className="text-sm text-gray-700 leading-relaxed">
              客户{customer.name}目前处于<span className="font-medium text-purple-600">高价值客户待服务升级</span>阶段。
              客户资产规模已达到{customer.assets}，风险偏好为{customer.riskLevel}，
              {customer.serviceHistory}，月均交易{customer.tradingFrequency}。
              当前使用{customer.currentService}，服务匹配度高达{customer.matchScore}%，
              非常适合升级至专属投顾服务。
            </p>
          </div>

          <div className="bg-white rounded-lg p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">建议跟进方向</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-1 text-amber-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">推荐专属投顾服务</div>
                  <div className="text-sm text-gray-600">
                    客户资产规模符合高阶服务标准，建议介绍专属投顾服务的价值与服务内容
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-2 text-amber-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">对比服务差异</div>
                  <div className="text-sm text-gray-600">
                    详细说明当前服务与专属服务的区别，让客户了解升级后的价值
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-3 text-amber-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">提供家庭财富规划</div>
                  <div className="text-sm text-gray-600">
                    高净值客户通常有家庭财富规划需求，可结合此服务进行沟通
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-purple-100 rounded-lg">
            <p className="text-xs text-purple-800">
              <i className="ri-information-line mr-1"></i>
              以上建议仅为服务辅助提示，不构成投资建议，所有服务推荐需经客户沟通确认
            </p>
          </div>
        </div>

        {/* 5️⃣ 推荐内容区 */}
        <div className="grid grid-cols-3 gap-6">
          {/* A. 推荐话术 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-chat-quote-line text-xl text-amber-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">推荐话术</h2>
            </div>
            <div className="space-y-4">
              {recommendedScripts.map((script) => (
                <div key={script.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-sm font-semibold text-gray-900 flex-1">{script.title}</h3>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded">
                      {script.style}
                    </span>
                    <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">
                      {script.scene}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mb-3 line-clamp-2">{script.summary}</p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleCopyScript(script)}
                      className="flex-1 px-3 py-1.5 bg-amber-600 text-white text-xs rounded hover:bg-amber-700 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-file-copy-line mr-1"></i>
                      复制话术
                    </button>
                    <button
                      onClick={() => navigate('/scripts')}
                      className="px-3 py-1.5 border border-gray-300 text-gray-700 text-xs rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                    >
                      查看详情
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* B. 投顾产品推荐 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-service-line text-xl text-purple-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">产品推荐</h2>
            </div>
            <div className="space-y-4">
              {recommendedProducts.map((product) => (
                <div key={product.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">
                      {product.type}
                    </span>
                    <span className="text-xs font-medium text-gray-900">{product.price}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {product.tags.map((tag, index) => (
                      <span key={index} className="px-2 py-0.5 bg-gray-200 text-gray-600 text-xs rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="p-2 bg-blue-50 rounded mb-3">
                    <p className="text-xs text-blue-800">
                      <i className="ri-lightbulb-line mr-1"></i>
                      推荐理由：{product.reason}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate('/advisory-products')}
                    className="w-full px-3 py-1.5 border border-purple-600 text-purple-600 text-xs rounded hover:bg-purple-50 cursor-pointer whitespace-nowrap"
                  >
                    查看详情
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* C. 投教内容推荐 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-book-open-line text-xl text-green-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">投教内容</h2>
            </div>
            <div className="space-y-4">
              {recommendedContent.map((content) => (
                <div key={content.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">{content.title}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">
                      {content.type}
                    </span>
                    <span className="text-xs text-gray-500">
                      <i className="ri-time-line mr-1"></i>
                      {content.duration}
                    </span>
                  </div>
                  <div className="p-2 bg-green-50 rounded mb-3">
                    <p className="text-xs text-green-800">
                      <i className="ri-lightbulb-line mr-1"></i>
                      {content.reason}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate('/advisory-content')}
                    className="w-full px-3 py-1.5 border border-green-600 text-green-600 text-xs rounded hover:bg-green-50 cursor-pointer whitespace-nowrap"
                  >
                    查看详情
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 6️⃣ 客户沟通与记录区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">沟通记录</h2>
            <div className="flex gap-2">
              <Button onClick={handleWeChatCommunication}>
                <i className="ri-wechat-line mr-2"></i>
                企业微信沟通
              </Button>
              <Button onClick={() => alert('发起电话')}>
                <i className="ri-phone-line mr-2"></i>
                电话沟通
              </Button>
              <Button onClick={() => setShowAddNote(!showAddNote)}>
                <i className="ri-add-line mr-2"></i>
                添加记录
              </Button>
            </div>
          </div>

          {showAddNote && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">添加沟通记录</h3>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="请输入沟通内容摘要..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"
                rows={4}
              />
              <div className="flex justify-end gap-2 mt-3">
                <button
                  onClick={() => setShowAddNote(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 text-sm rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                >
                  取消
                </button>
                <button
                  onClick={handleAddCommunicationNote}
                  className="px-4 py-2 bg-amber-600 text-white text-sm rounded hover:bg-amber-700 cursor-pointer whitespace-nowrap"
                >
                  保存记录
                </button>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div className="p-4 border border-gray-200 rounded-lg hover:border-amber-300 transition-colors">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                    <i className="ri-phone-line text-amber-600"></i>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">电话沟通</div>
                    <div className="text-xs text-gray-500">2025-01-12 14:30</div>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-700 mb-2 ml-11">介绍了专属投顾服务的内容和价值，客户表示感兴趣，需要时间考虑</p>
              <div className="ml-11 p-2 bg-amber-50 rounded">
                <p className="text-xs text-amber-800">
                  <i className="ri-arrow-right-line mr-1"></i>
                  下一步行动：发送服务对比资料，一周后回访
                </p>
              </div>
            </div>
            <div className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                    <i className="ri-wechat-line text-amber-600"></i>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">企业微信</div>
                    <div className="text-xs text-gray-500">2025-01-08 10:15</div>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-700 mb-2 ml-11">定期回访，了解客户近期投资情况和服务体验</p>
              <div className="ml-11 p-2 bg-amber-50 rounded">
                <p className="text-xs text-amber-800">
                  <i className="ri-arrow-right-line mr-1"></i>
                  下一步行动：评估服务升级可能性
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">服务记录</h3>
            <div className="space-y-2">
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                <div className="flex items-center gap-3">
                  <i className="ri-service-line text-gray-400"></i>
                  <div>
                    <div className="text-sm font-medium text-gray-900">{customer.currentService}</div>
                    <div className="text-xs text-gray-500">{customer.serviceHistory}</div>
                  </div>
                </div>
                <span className="px-2 py-1 text-xs rounded bg-green-100 text-green-700">
                  进行中
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 合规提示 */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-blue-600 text-lg flex-shrink-0 mt-0.5"></i>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• 所有分析与推荐仅为服务辅助提示，不构成投资建议或收益承诺</p>
              <p>• 所有服务升级、产品推荐需经客户沟通确认后执行</p>
              <p>• 所有操作将被记录并可追溯，用于合规审计</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CustomerDetailPage;
