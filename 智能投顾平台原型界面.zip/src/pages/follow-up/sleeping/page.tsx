import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';
import StatusTag from '../../../components/common/StatusTag';
import { sleepingCustomers } from '../../../mocks/followUpTasks';

export default function SleepingFollowUp() {
  const navigate = useNavigate();
  const [customers] = useState(sleepingCustomers);

  return (
    <MainLayout>
      <PageHeader
        title="沉睡客户待唤醒"
        description="长时间无互动客户，建议恢复沟通关系，重新建立服务连接"
        breadcrumbs={[
          { label: '首页', path: '/' },
          { label: '客户跟进', path: '/' },
          { label: '沉睡客户待唤醒' },
        ]}
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line">
              导出列表
            </Button>
            <Button type="primary" icon="ri-refresh-line">
              刷新数据
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* 统计卡片 */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">待唤醒客户</div>
                <div className="text-3xl font-bold text-gray-900">{customers.length}</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-user-unfollow-line text-2xl text-orange-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-red-50 to-red-100 border border-red-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">平均沉睡天数</div>
                <div className="text-3xl font-bold text-gray-900">95</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-time-line text-2xl text-red-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">已唤醒成功</div>
                <div className="text-3xl font-bold text-gray-900">6</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-user-heart-line text-2xl text-green-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 border border-gray-300 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">流失客户</div>
                <div className="text-3xl font-bold text-gray-900">2</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-user-forbid-line text-2xl text-gray-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
        </div>

        {/* 客户列表 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-gray-900">客户列表</h3>
              <div className="flex items-center gap-3">
                <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                  <option>全部沉睡时长</option>
                  <option>60-90天</option>
                  <option>90-120天</option>
                  <option>120天以上</option>
                </select>
                <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                  <option>按沉睡天数排序</option>
                  <option>按资产规模排序</option>
                  <option>按最后活动排序</option>
                </select>
              </div>
            </div>
          </div>

          <div className="divide-y divide-gray-200">
            {customers.map((customer) => (
              <div
                key={customer.id}
                className="p-6 hover:bg-gray-50 transition-colors cursor-pointer"
                onClick={() => navigate(`/follow-up/sleeping/${customer.id}`)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    {/* 客户头像 */}
                    <div className="w-12 h-12 bg-gradient-to-br from-gray-400 to-gray-500 rounded-full flex items-center justify-center text-white text-lg font-medium flex-shrink-0 relative opacity-60">
                      {customer.name.charAt(0)}
                      <i className="ri-zzz-line absolute -top-1 -right-1 text-orange-500 text-xl w-5 h-5 flex items-center justify-center"></i>
                    </div>

                    {/* 客户信息 */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-base font-semibold text-gray-900">{customer.name}</h4>
                        <span className="text-sm text-gray-500">{customer.id}</span>
                        <StatusTag type="warning" label={customer.riskLevel} />
                        <span className="px-2 py-1 bg-red-50 text-red-600 text-xs rounded border border-red-200">
                          沉睡 {customer.sleepDays} 天
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-4 mb-3">
                        <div className="text-sm">
                          <span className="text-gray-500">联系方式：</span>
                          <span className="text-gray-900">{customer.phone}</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">资产规模：</span>
                          <span className="text-gray-900">{customer.assets}</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">最后登录：</span>
                          <span className="text-gray-900">{customer.lastLoginDate}</span>
                        </div>
                      </div>
                      <div className="text-sm mb-3">
                        <span className="text-gray-500">最后活动：</span>
                        <span className="text-gray-900">{customer.lastActivity}</span>
                      </div>
                      <div className="flex items-start gap-2 text-sm bg-orange-50 border border-orange-100 rounded p-3">
                        <i className="ri-error-warning-line text-orange-600 w-4 h-4 flex items-center justify-center flex-shrink-0 mt-0.5"></i>
                        <div>
                          <span className="font-medium text-gray-900">流失风险分析：</span>
                          <span className="text-gray-700">{customer.possibleReason}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mt-3">
                        <span className="text-sm text-gray-500">历史兴趣：</span>
                        {customer.historicalInterests.map((interest, index) => (
                          <span
                            key={index}
                            className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded"
                          >
                            {interest}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      type="default"
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/follow-up/sleeping/${customer.id}`);
                      }}
                    >
                      查看详情
                    </Button>
                    <Button
                      type="primary"
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('开始唤醒', customer.id);
                      }}
                    >
                      开始唤醒
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 唤醒提示 */}
        <div className="mt-6 bg-orange-50 border border-orange-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-orange-600 text-xl w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5"></i>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-900 mb-1">唤醒建议</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                沉睡客户唤醒建议采用"情感关怀型"沟通方式，避免直接推销产品。
                可从节日问候、市场动态分享、投教内容推送等角度切入，重新建立与客户的联系。
                推荐邀请参加低门槛体验活动，降低客户重新参与的心理负担。
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
