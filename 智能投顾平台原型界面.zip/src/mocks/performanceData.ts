// 客户经理个人业绩数据（Mock）
export const performanceOverview = {
  period: '近30天',
  metrics: {
    newCustomers: 12,
    conversionRate: 68.5,
    productRecommendations: 45,
    productDeals: 18,
    scriptUsageCount: 128,
    scriptEfficiency: 72.3,
    customerActivityTrend: '+15.2%'
  }
};

export const scriptUsageAnalysis = {
  styleDistribution: [
    { name: '专业型', value: 35, color: '#3B82F6' },
    { name: '亲切型', value: 28, color: '#10B981' },
    { name: '简洁型', value: 22, color: '#F59E0B' },
    { name: '严谨型', value: 15, color: '#6366F1' }
  ],
  stylePerformance: [
    {
      style: '专业型',
      usageCount: 45,
      replyRate: 78.5,
      continueRate: 65.2,
      trend: 'up'
    },
    {
      style: '亲切型',
      usageCount: 36,
      replyRate: 82.3,
      continueRate: 71.8,
      trend: 'up'
    },
    {
      style: '简洁型',
      usageCount: 28,
      replyRate: 68.9,
      continueRate: 58.4,
      trend: 'stable'
    },
    {
      style: '严谨型',
      usageCount: 19,
      replyRate: 75.2,
      continueRate: 62.7,
      trend: 'down'
    }
  ]
};

export const customerOperationAnalysis = {
  distribution: [
    { type: '开户后未转化', count: 8, percentage: 32, color: '#3B82F6' },
    { type: '行为触发客户', count: 6, percentage: 24, color: '#10B981' },
    { type: '沉睡客户', count: 4, percentage: 16, color: '#F59E0B' },
    { type: '高价值客户', count: 7, percentage: 28, color: '#8B5CF6' }
  ],
  performanceByType: [
    {
      type: '开户后未转化',
      followUpCount: 8,
      successRate: 75.0,
      avgResponseTime: '2.5小时'
    },
    {
      type: '行为触发客户',
      followUpCount: 6,
      successRate: 83.3,
      avgResponseTime: '1.8小时'
    },
    {
      type: '沉睡客户',
      followUpCount: 4,
      successRate: 50.0,
      avgResponseTime: '4.2小时'
    },
    {
      type: '高价值客户',
      followUpCount: 7,
      successRate: 71.4,
      avgResponseTime: '1.5小时'
    }
  ]
};

export const abilityAnalysis = {
  strengths: [
    {
      title: '亲切型话术场景表现优秀',
      description: '在使用亲切型话术时，客户回应率达到82.3%，高于平均水平15个百分点',
      icon: 'ri-emotion-happy-line',
      color: 'green'
    },
    {
      title: '新客户开户引导能力突出',
      description: '新客户开户转化率68.5%，沟通完成度较高，客户满意度良好',
      icon: 'ri-user-smile-line',
      color: 'blue'
    },
    {
      title: '行为触发客户响应及时',
      description: '对行为触发客户的平均响应时间为1.8小时，跟进成功率83.3%',
      icon: 'ri-time-line',
      color: 'purple'
    }
  ],
  improvements: [
    {
      title: '沉睡客户唤醒成功率偏低',
      description: '沉睡客户唤醒成功率为50%，低于平均水平，建议加强情感关怀类沟通',
      icon: 'ri-user-unfollow-line',
      color: 'orange'
    },
    {
      title: '高价值客户沟通频次较少',
      description: '本月高价值客户平均沟通次数为2.3次，建议提升服务触达频率',
      icon: 'ri-vip-diamond-line',
      color: 'red'
    }
  ],
  suggestions: [
    {
      title: '优化沉睡客户唤醒策略',
      description: '可尝试在沉睡客户沟通中使用更具关怀性的标准话术，如节日问候、投教内容推送等',
      actionText: '查看推荐话术',
      actionLink: '/scripts'
    },
    {
      title: '加强高价值客户服务',
      description: '建议定期使用投教内容作为沟通切入点，提升客户粘性与满意度',
      actionText: '查看投教内容',
      actionLink: '/advisory-content'
    },
    {
      title: '参与 AI 模拟训练',
      description: '可参与"沉睡客户唤醒场景"和"高净值客户服务"的模拟训练，提升专业能力',
      actionText: '前往训练库',
      actionLink: '/training'
    }
  ]
};

export const recentActivities = [
  {
    date: '2024-01-15',
    activity: '使用话术',
    detail: '向客户张伟发送了"开户关怀型"话术',
    result: '客户已回复',
    status: 'success'
  },
  {
    date: '2024-01-15',
    activity: '客户跟进',
    detail: '完成对沉睡客户李明的唤醒沟通',
    result: '客户恢复活跃',
    status: 'success'
  },
  {
    date: '2024-01-14',
    activity: '产品推荐',
    detail: '向高价值客户王芳推荐投顾服务',
    result: '客户表示考虑',
    status: 'pending'
  },
  {
    date: '2024-01-14',
    activity: '使用话术',
    detail: '向新客户陈强发送了"产品介绍型"话术',
    result: '客户未回复',
    status: 'failed'
  },
  {
    date: '2024-01-13',
    activity: '客户跟进',
    detail: '完成对行为触发客户刘洋的跟进',
    result: '客户完成购买',
    status: 'success'
  }
];
