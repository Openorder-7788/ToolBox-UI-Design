import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import {
  riskTypes,
  highRiskPersonnel,
  pendingReviewContent,
  processedViolations,
  riskTrendData,
} from '../../../mocks/complianceRisk';

export default function ComplianceDashboardPage() {
  const navigate = useNavigate();
  const [selectedRiskLevel, setSelectedRiskLevel] = useState<string>('all');

  // 风险等级映射
  const riskLevelMap = {
    high: { label: '高风险', color: 'bg-red-100 text-red-700 border-red-200' },
    medium: { label: '中风险', color: 'bg-orange-100 text-orange-700 border-orange-200' },
    low: { label: '低风险', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' },
  };

  // 风险类型颜色映射
  const riskColorMap: Record<string, string> = {
    red: 'bg-red-500',
    orange: 'bg-orange-500',
    yellow: 'bg-yellow-500',
    purple: 'bg-purple-500',
  };

  // 筛选后的高风险人员
  const filteredPersonnel =
    selectedRiskLevel === 'all'
      ? highRiskPersonnel
      : highRiskPersonnel.filter((p) => p.riskLevel === selectedRiskLevel);

  // 计算总风险数
  const totalRiskCount = riskTypes.reduce((sum, type) => sum + type.count, 0);

  return (
    <MainLayout>
      <div className="min-h-screen bg-gray-50">
        {/* 页面标题 */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">合规风控总览</h1>
              <p className="text-sm text-gray-500 mt-1">
                通过 AI 分析结果快速发现潜在违规风险
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2">
                <i className="ri-download-line"></i>
                导出报告
              </button>
              <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2">
                <i className="ri-settings-3-line"></i>
                规则配置
              </button>
            </div>
          </div>
        </div>

        <div className="p-8">
          {/* 1️⃣ 风险概览指标区 */}
          <div className="grid grid-cols-4 gap-6 mb-8">
            <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <i className="ri-alert-line text-2xl text-red-600"></i>
                </div>
                <span className="px-2 py-1 bg-red-100 text-red-700 text-xs font-medium rounded-full">
                  +12
                </span>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">20</div>
              <div className="text-sm text-gray-500">今日新增风险预警</div>
            </div>

            <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <i className="ri-chat-warning-line text-2xl text-orange-600"></i>
                </div>
                <span className="px-2 py-1 bg-orange-100 text-orange-700 text-xs font-medium rounded-full">
                  高危
                </span>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">15</div>
              <div className="text-sm text-gray-500">高风险会话数量</div>
            </div>

            <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <i className="ri-file-list-3-line text-2xl text-blue-600"></i>
                </div>
                <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                  待处理
                </span>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">
                {pendingReviewContent.length}
              </div>
              <div className="text-sm text-gray-500">待人工审核内容</div>
            </div>

            <div className="bg-white rounded-xl p-6 border border-gray-200 hover:shadow-lg transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <i className="ri-checkbox-circle-line text-2xl text-green-600"></i>
                </div>
                <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                  已完成
                </span>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">
                {processedViolations.length}
              </div>
              <div className="text-sm text-gray-500">已处理违规事件</div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-6 mb-8">
            {/* 2️⃣ AI 合规分析概览区 */}
            <div className="col-span-2 bg-white rounded-xl p-6 border border-gray-200">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-bold text-gray-900">AI 合规分析概览</h2>
                  <p className="text-sm text-gray-500 mt-1">
                    AI 分析结果仅为风险提示，需人工复核
                  </p>
                </div>
                <button className="px-3 py-1.5 text-sm text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                  查看详情
                </button>
              </div>

              {/* 风险类型分布 */}
              <div className="space-y-4 mb-6">
                {riskTypes.map((risk) => (
                  <div key={risk.id}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">
                        {risk.name}
                      </span>
                      <span className="text-sm font-bold text-gray-900">
                        {risk.count} 次
                      </span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full ${riskColorMap[risk.color]}`}
                        style={{ width: `${(risk.count / totalRiskCount) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>

              {/* 风险趋势图 */}
              <div className="pt-6 border-t border-gray-200">
                <h3 className="text-sm font-bold text-gray-900 mb-4">
                  风险趋势（最近7天）
                </h3>
                <div className="flex items-end justify-between h-32 gap-2">
                  {riskTrendData.map((data, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center">
                      <div className="w-full bg-emerald-100 rounded-t-lg relative group cursor-pointer hover:bg-emerald-200 transition-colors"
                        style={{ height: `${(data.count / 20) * 100}%` }}>
                        <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                          {data.count} 次
                        </div>
                      </div>
                      <span className="text-xs text-gray-500 mt-2">{data.date}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 快捷入口区 */}
            <div className="bg-white rounded-xl p-6 border border-gray-200">
              <h2 className="text-lg font-bold text-gray-900 mb-6">快捷入口</h2>
              <div className="space-y-3">
                <button className="w-full px-4 py-3 bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-lg hover:shadow-md transition-all text-left group">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                        <i className="ri-file-list-3-line text-lg text-emerald-600"></i>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          内容合规审核
                        </div>
                        <div className="text-xs text-gray-500">
                          {pendingReviewContent.length} 条待审核
                        </div>
                      </div>
                    </div>
                    <i className="ri-arrow-right-s-line text-gray-400 group-hover:text-emerald-600 transition-colors"></i>
                  </div>
                </button>

                <button className="w-full px-4 py-3 bg-gradient-to-r from-orange-50 to-red-50 border border-orange-200 rounded-lg hover:shadow-md transition-all text-left group">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                        <i className="ri-alarm-warning-line text-lg text-orange-600"></i>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          违规预警处理
                        </div>
                        <div className="text-xs text-gray-500">15 条高风险预警</div>
                      </div>
                    </div>
                    <i className="ri-arrow-right-s-line text-gray-400 group-hover:text-orange-600 transition-colors"></i>
                  </div>
                </button>

                <button className="w-full px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg hover:shadow-md transition-all text-left group">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i className="ri-book-2-line text-lg text-blue-600"></i>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          合规规则库
                        </div>
                        <div className="text-xs text-gray-500">管理合规规则</div>
                      </div>
                    </div>
                    <i className="ri-arrow-right-s-line text-gray-400 group-hover:text-blue-600 transition-colors"></i>
                  </div>
                </button>

                <button className="w-full px-4 py-3 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200 rounded-lg hover:shadow-md transition-all text-left group">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i className="ri-history-line text-lg text-purple-600"></i>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          处理记录
                        </div>
                        <div className="text-xs text-gray-500">
                          {processedViolations.length} 条已处理
                        </div>
                      </div>
                    </div>
                    <i className="ri-arrow-right-s-line text-gray-400 group-hover:text-purple-600 transition-colors"></i>
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* 3️⃣ 高风险人员与团队提示区 */}
          <div className="bg-white rounded-xl p-6 border border-gray-200">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-lg font-bold text-gray-900">高风险人员与团队</h2>
                <p className="text-sm text-gray-500 mt-1">
                  共 {filteredPersonnel.length} 人需要关注
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 bg-gray-50 rounded-lg p-1">
                  <button
                    onClick={() => setSelectedRiskLevel('all')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                      selectedRiskLevel === 'all'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    全部
                  </button>
                  <button
                    onClick={() => setSelectedRiskLevel('high')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                      selectedRiskLevel === 'high'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    高风险
                  </button>
                  <button
                    onClick={() => setSelectedRiskLevel('medium')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                      selectedRiskLevel === 'medium'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    中风险
                  </button>
                  <button
                    onClick={() => setSelectedRiskLevel('low')}
                    className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors whitespace-nowrap ${
                      selectedRiskLevel === 'low'
                        ? 'bg-white text-gray-900 shadow-sm'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    低风险
                  </button>
                </div>
              </div>
            </div>

            {/* 高风险人员列表 */}
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      客户经理
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      所属团队
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      主管
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      风险类型
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      风险等级
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      风险次数
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-500">
                      最近风险时间
                    </th>
                    <th className="text-right py-3 px-4 text-sm font-medium text-gray-500">
                      操作
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPersonnel.map((person) => (
                    <tr
                      key={person.id}
                      className="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                    >
                      <td className="py-4 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full flex items-center justify-center text-white font-medium">
                            {person.name.charAt(0)}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {person.name}
                            </div>
                            <div className="text-xs text-gray-500">{person.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-sm text-gray-700">{person.team}</td>
                      <td className="py-4 px-4 text-sm text-gray-700">
                        {person.supervisor}
                      </td>
                      <td className="py-4 px-4">
                        <span className="text-sm text-gray-700">{person.riskType}</span>
                      </td>
                      <td className="py-4 px-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${
                            riskLevelMap[person.riskLevel as keyof typeof riskLevelMap]
                              .color
                          }`}
                        >
                          {
                            riskLevelMap[person.riskLevel as keyof typeof riskLevelMap]
                              .label
                          }
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <span className="text-sm font-medium text-red-600">
                          {person.riskCount} 次
                        </span>
                      </td>
                      <td className="py-4 px-4 text-sm text-gray-500">
                        {person.lastRiskTime}
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center justify-end gap-2">
                          <button className="px-3 py-1.5 text-sm text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                            查看详情
                          </button>
                          <button className="px-3 py-1.5 text-sm text-orange-600 hover:bg-orange-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                            发起预警
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
