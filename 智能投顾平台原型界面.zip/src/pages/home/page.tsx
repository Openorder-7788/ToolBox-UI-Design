import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import DataTable from '../../components/common/DataTable';
import StatusTag from '../../components/common/StatusTag';
import { customersData, performanceData } from '../../mocks/customers';

export default function Home() {
  const [dateRange] = useState('本月');
  const navigate = useNavigate();

  // 今日待办任务数据
  const todayTasks = [
    {
      id: 'open-account',
      title: '开户后 7 天未转化',
      count: 36,
      description: '建议今日主动联系，推荐合适的投资产品',
      className: 'bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200',
      path: '/follow-up/open-account',
    },
    {
      id: 'asset-diagnosis',
      title: '高价值客户待服务升级',
      count: 24,
      description: '可从普通服务升级到专属投顾服务',
      className: 'bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200',
      path: '/follow-up/high-value',
    },
    {
      id: 'behavior-trigger',
      title: '行为触发客户待跟进',
      count: 12,
      description: '近期出现投资相关行为，适合专业沟通',
      className: 'bg-gradient-to-br from-green-50 to-green-100 border-green-200',
      path: '/follow-up/behavior',
    },
    {
      id: 'sleeping-customer',
      title: '沉睡客户待唤醒',
      count: 7,
      description: '长时间未登录的客户，需要重新激活',
      className: 'bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200',
      path: '/follow-up/sleeping',
    },
  ];

  // 数据概览
  const statsData = [
    {
      label: '客户总数',
      value: '248',
      change: '+12',
      trend: 'up',
      icon: 'ri-team-line',
      color: 'text-blue-600',
    },
    {
      label: '本月新增',
      value: '32',
      change: '+8',
      trend: 'up',
      icon: 'ri-user-add-line',
      color: 'text-green-600',
    },
    {
      label: '待跟进',
      value: '18',
      change: '-3',
      trend: 'down',
      icon: 'ri-notification-3-line',
      color: 'text-orange-600',
    },
    {
      label: '本月业绩',
      value: '¥278.9万',
      change: '+15.8%',
      trend: 'up',
      icon: 'ri-money-cny-circle-line',
      color: 'text-red-600',
    },
  ];

  // 表格列配置
  const columns = [
    {
      key: 'name',
      title: '客户姓名',
      width: '120px',
      render: (value: string, record: any) => (
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
            {value.charAt(0)}
          </div>
          <div>
            <div className="font-medium text-gray-900">{value}</div>
            <div className="text-xs text-gray-500">{record.id}</div>
          </div>
        </div>
      ),
    },
    {
      key: 'phone',
      title: '联系方式',
      width: '120px',
    },
    {
      key: 'assets',
      title: '资产规模',
      width: '100px',
      render: (value: string) => <span className="font-medium text-gray-900">{value}</span>,
    },
    {
      key: 'riskLevel',
      title: '风险等级',
      width: '100px',
      render: (value: string) => {
        const typeMap: any = {
          保守型: 'default',
          稳健型: 'info',
          平衡型: 'warning',
          积极型: 'error',
        };
        return <StatusTag type={typeMap[value] || 'default'} label={value} />;
      },
    },
    {
      key: 'status',
      title: '状态',
      width: '90px',
      render: (value: string) => {
        const statusMap: any = {
          active: { type: 'success', label: '正常', icon: 'ri-checkbox-circle-line' },
          pending: { type: 'warning', label: '待跟进', icon: 'ri-time-line' },
          inactive: { type: 'default', label: '未激活', icon: 'ri-close-circle-line' },
        };
        const status = statusMap[value];
        return <StatusTag type={status.type} label={status.label} icon={status.icon} />;
      },
    },
    {
      key: 'lastContact',
      title: '最近联系',
      width: '100px',
      render: (value: string) => <span className="text-gray-600">{value}</span>,
    },
    {
      key: 'nextFollowUp',
      title: '下次跟进',
      width: '100px',
      render: (value: string) => <span className="text-gray-600">{value}</span>,
    },
    {
      key: 'tags',
      title: '标签',
      width: '150px',
      render: (value: string[]) => (
        <div className="flex gap-1.5 flex-wrap">
          {value.map((tag, index) => (
            <span key={index} className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
              {tag}
            </span>
          ))}
        </div>
      ),
    },
    {
      key: 'actions',
      title: '操作',
      width: '120px',
      align: 'center' as const,
      render: () => (
        <div className="flex items-center justify-center gap-2">
          <button className="text-blue-600 hover:text-blue-700 text-sm cursor-pointer whitespace-nowrap">
            查看
          </button>
          <span className="text-gray-300">|</span>
          <button className="text-blue-600 hover:text-blue-700 text-sm cursor-pointer whitespace-nowrap">
            跟进
          </button>
        </div>
      ),
    },
  ];

  return (
    <MainLayout>
      {/* 页面头部 */}
      <PageHeader
        title="工作台"
        description="欢迎回来，张经理。今日待跟进客户 18 人，待完成任务 5 项"
        actions={
          <Button type="primary" icon="ri-refresh-line">
            刷新数据
          </Button>
        }
      />

      <div className="p-6 space-y-6">
        {/* 今日待办 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-gray-900">今日待办</h3>
            </div>
            <button className="text-sm text-gray-600 hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap">
              全部待办
            </button>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-4 gap-4">
              {todayTasks.map((task) => (
                <button
                  key={task.id}
                  onClick={() => navigate(task.path)}
                  className={`${task.className} border rounded-lg p-5 hover:shadow-md transition-all cursor-pointer text-left`}
                >
                  <div className="text-sm font-medium text-gray-700 mb-2">{task.title}</div>
                  <div className="text-3xl font-bold text-gray-900 mb-3">{task.count}</div>
                  <div className="text-xs text-gray-600 leading-relaxed">{task.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 数据概览 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-gray-900">数据概览</h3>
              <p className="text-sm text-gray-500 mt-0.5">{dateRange}关键数据</p>
            </div>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-4 gap-4">
              {statsData.map((stat, index) => (
                <div
                  key={index}
                  className="bg-gradient-to-br from-gray-50 to-white border border-gray-200 rounded-lg p-5 hover:shadow-md transition-all"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="text-sm text-gray-500 mb-2">{stat.label}</div>
                      <div className="text-2xl font-semibold text-gray-900 mb-1">{stat.value}</div>
                      <div className="flex items-center gap-1 text-xs">
                        <span
                          className={`flex items-center gap-0.5 ${
                            stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                          }`}
                        >
                          <i
                            className={`${
                              stat.trend === 'up' ? 'ri-arrow-up-line' : 'ri-arrow-down-line'
                            } w-3 h-3 flex items-center justify-center`}
                          ></i>
                          {stat.change}
                        </span>
                        <span className="text-gray-400">较上月</span>
                      </div>
                    </div>
                    <div className={`w-10 h-10 bg-white border border-gray-200 rounded-lg flex items-center justify-center ${stat.color}`}>
                      <i className={`${stat.icon} text-xl w-5 h-5 flex items-center justify-center`}></i>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 最近客户跟进 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-gray-900">近期客户</h3>
              <p className="text-sm text-gray-500 mt-0.5">最近更新的客户列表</p>
            </div>
            <div className="flex items-center gap-3">
              <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                <option>全部状态</option>
                <option>正常</option>
                <option>待跟进</option>
                <option>未激活</option>
              </select>
              <Button type="default" size="small" icon="ri-filter-3-line">
                筛选
              </Button>
              <Button type="default" size="small" icon="ri-download-line">
                导出
              </Button>
            </div>
          </div>
          <div className="p-6">
            <DataTable
              columns={columns}
              data={customersData}
              rowKey="id"
              onRowClick={(record) => console.log('点击行:', record)}
            />
          </div>
        </div>

        {/* 业绩趋势 */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-base font-semibold text-gray-900">业绩趋势</h3>
                <p className="text-sm text-gray-500 mt-0.5">近 6 个月业绩数据</p>
              </div>
              <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                <option>近 6 个月</option>
                <option>近 12 个月</option>
              </select>
            </div>
            <div className="space-y-4">
              {performanceData.map((item, index) => {
                const maxRevenue = Math.max(...performanceData.map((d) => d.revenue));
                const percentage = (item.revenue / maxRevenue) * 100;
                return (
                  <div key={index}>
                    <div className="flex items-center justify-between text-sm mb-1.5">
                      <span className="text-gray-600">{item.month}</span>
                      <span className="font-medium text-gray-900">¥{(item.revenue / 10000).toFixed(1)}万</span>
                    </div>
                    <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full transition-all"
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-base font-semibold text-gray-900">待办事项</h3>
                <p className="text-sm text-gray-500 mt-0.5">今日需要完成的任务</p>
              </div>
              <Button type="text" size="small" icon="ri-add-line">
                添加
              </Button>
            </div>
            <div className="space-y-3">
              {[
                { task: '跟进王建国客户，推荐理财产品', time: '10:00', priority: 'high' },
                { task: '完成李明华客户风险评估报告', time: '14:00', priority: 'medium' },
                { task: '参加投资策略会议', time: '15:30', priority: 'high' },
                { task: '回访陈雪梅客户，了解产品使用情况', time: '16:00', priority: 'low' },
                { task: '整理本周客户服务数据', time: '17:00', priority: 'medium' },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer group"
                >
                  <input
                    type="checkbox"
                    className="mt-0.5 w-4 h-4 text-blue-600 border-gray-300 rounded cursor-pointer"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-gray-700 group-hover:text-gray-900">{item.task}</div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-gray-500 flex items-center gap-1">
                        <i className="ri-time-line w-3 h-3 flex items-center justify-center"></i>
                        {item.time}
                      </span>
                      <span
                        className={`px-1.5 py-0.5 text-xs rounded ${
                          item.priority === 'high'
                            ? 'bg-red-50 text-red-600'
                            : item.priority === 'medium'
                            ? 'bg-amber-50 text-amber-600'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        {item.priority === 'high' ? '高优先级' : item.priority === 'medium' ? '中' : '低'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
