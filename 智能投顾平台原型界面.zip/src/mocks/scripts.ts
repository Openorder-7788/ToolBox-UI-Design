export const scriptsData = [
  {
    id: 'SCR001',
    title: '基金定投服务介绍话术',
    scene: 'product',
    sceneName: '产品推荐',
    productType: 'operation',
    productTypeName: '实操辅助类',
    customerLevel: 'existing_basic',
    customerLevelName: '存量客户（基础付费）',
    style: 'professional',
    styleName: '专业型',
    summary: '您好，我是您的专属投资顾问。注意到您对基金投资比较关注，想向您介绍一下我们的基金定投服务...',
    content: `您好，我是您的专属投资顾问。

注意到您对基金投资比较关注，想向您介绍一下我们的基金定投服务。

基金定投是一种定期定额的投资方式，可以帮助您：
1. 分散市场波动风险
2. 养成长期投资习惯
3. 降低择时压力

我们提供的服务包括：
- 定投计划设置与调整
- 市场行情分析参考
- 定期服务回访

如果您感兴趣，我可以为您详细讲解服务内容和费用标准。

请问您方便了解吗？`,
    relatedContent: '基金定投精品课（查看详情）',
    isFavorite: true,
    isHighUsage: true,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR002',
    title: '沉睡客户唤醒话术',
    scene: 'reactivation',
    sceneName: '沉睡唤醒',
    productType: 'service',
    productTypeName: '专属服务类',
    customerLevel: 'existing_premium',
    customerLevelName: '存量客户（高阶付费）',
    style: 'friendly',
    styleName: '亲切型',
    summary: '您好，好久不见！我是您的投资顾问，最近市场有一些新的变化，想跟您分享一下...',
    content: `您好，好久不见！

我是您的投资顾问，注意到您已经有一段时间没有登录了。

最近市场有一些新的变化，我们也推出了一些服务升级，想跟您分享一下：

1. 新增了智能投顾工具
2. 优化了行情分析功能
3. 推出了专属客户服务

作为我们的高阶客户，您可以优先体验这些新功能。

如果您最近比较忙，我也可以帮您整理一份近期市场简报。

请问您需要了解哪方面的内容？`,
    relatedContent: null,
    isFavorite: false,
    isHighUsage: false,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR003',
    title: '开户流程引导话术',
    scene: 'onboarding',
    sceneName: '开户引导',
    productType: 'operation',
    productTypeName: '实操辅助类',
    customerLevel: 'prospect',
    customerLevelName: '即得客户（未购/免费体验）',
    style: 'concise',
    styleName: '简洁型',
    summary: '您好，开户流程非常简单，只需要3个步骤，大约5分钟即可完成...',
    content: `您好，开户流程非常简单。

只需要3个步骤，大约5分钟即可完成：

步骤1：填写基本信息
- 身份证信息
- 联系方式

步骤2：风险测评
- 简单的问卷调查
- 了解您的投资偏好

步骤3：签署协议
- 电子签名
- 开户完成

整个过程都在线上完成，非常便捷。

我可以现在指导您操作，或者发送详细的操作指引给您。

请问您现在方便操作吗？`,
    relatedContent: null,
    isFavorite: true,
    isHighUsage: true,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR004',
    title: '智能投顾服务介绍话术',
    scene: 'product',
    sceneName: '产品推荐',
    productType: 'advisory',
    productTypeName: '智能投顾类',
    customerLevel: 'high_value',
    customerLevelName: '高价值客户',
    style: 'professional',
    styleName: '专业型',
    summary: '您好，我们最新推出了智能投顾服务，这是一种结合大数据和算法的投资辅助工具...',
    content: `您好，我是您的专属投资顾问。

想向您介绍我们最新推出的智能投顾服务。

这是一种结合大数据和算法的投资辅助工具，可以为您提供：

功能特点：
- 市场数据实时分析
- 投资组合优化建议
- 风险监控与提醒

服务内容：
- 个性化资产配置方案参考
- 定期投资策略分析
- 专属投顾一对一解读

适用场景：
- 希望优化资产配置的投资者
- 需要专业分析工具的客户
- 追求长期稳健投资的人群

需要说明的是，智能投顾提供的是辅助参考工具，所有投资决策仍需您自主判断。

如果您感兴趣，我可以为您详细介绍服务内容和费用标准。

请问您方便了解吗？`,
    relatedContent: '智能投顾产品手册（查看详情）',
    isFavorite: false,
    isHighUsage: true,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR005',
    title: '活动邀约话术 - 投资策略分享会',
    scene: 'activity',
    sceneName: '活动邀约',
    productType: 'knowledge',
    productTypeName: '知识赋能类',
    customerLevel: 'existing_basic',
    customerLevelName: '存量客户（基础付费）',
    style: 'friendly',
    styleName: '亲切型',
    summary: '您好，我们本月将举办一场线上投资策略分享会，邀请资深分析师分享市场观点...',
    content: `您好，我是您的投资顾问。

我们本月将举办一场线上投资策略分享会，想邀请您参加。

活动信息：
时间：本月25日 下午2点
形式：线上直播
主题：当前市场形势分析与投资策略探讨

分享内容：
- 宏观经济形势分析
- 行业板块机会梳理
- 投资策略思路参考

嘉宾介绍：
资深投资分析师，15年从业经验

参与方式：
点击链接即可预约，活动当天会发送提醒

活动免费，名额有限。

请问您有兴趣参加吗？`,
    relatedContent: null,
    isFavorite: true,
    isHighUsage: false,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR006',
    title: '客户异议解答 - 费用疑问',
    scene: 'objection',
    sceneName: '异议解答',
    productType: 'service',
    productTypeName: '专属服务类',
    customerLevel: 'potential',
    customerLevelName: '潜在客户',
    style: 'rigorous',
    styleName: '严谨型',
    summary: '您好，我理解您对费用的关注。我们的收费标准是完全透明的，所有费用都会事先说明...',
    content: `您好，我理解您对费用的关注。

我们的收费标准是完全透明的，所有费用都会事先说明。

费用构成：
1. 基础服务费
   - 账户管理
   - 行情查看
   - 基础咨询

2. 增值服务费（可选）
   - 专属投顾服务
   - 高级分析工具
   - 专项培训课程

收费原则：
- 明码标价，无隐藏费用
- 服务前充分告知
- 可根据需求选择

我可以为您提供详细的费用说明文档，您可以仔细了解后再做决定。

请问您对哪部分费用有疑问？我可以为您详细解答。`,
    relatedContent: null,
    isFavorite: false,
    isHighUsage: false,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR007',
    title: '节日关怀话术 - 春节问候',
    scene: 'greeting',
    sceneName: '节日关怀',
    productType: 'service',
    productTypeName: '专属服务类',
    customerLevel: 'existing_premium',
    customerLevelName: '存量客户（高阶付费）',
    style: 'friendly',
    styleName: '亲切型',
    summary: '您好，春节即将到来，祝您新春快乐，阖家幸福！作为您的专属投资顾问，有几点温馨提示...',
    content: `您好，春节即将到来！

首先祝您新春快乐，阖家幸福，万事如意！

作为您的专属投资顾问，有几点温馨提示想与您分享：

节日期间安排：
- 春节假期市场休市时间
- 紧急联系方式
- 节后服务恢复时间

节后服务计划：
- 市场开盘行情分析
- 年度投资策略回顾
- 新年投资规划建议

如果您在假期有任何问题，可以随时联系我，我会尽快回复。

再次祝您和家人春节愉快，身体健康！`,
    relatedContent: null,
    isFavorite: true,
    isHighUsage: false,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR008',
    title: '获客触达话术 - 初次联系',
    scene: 'acquisition',
    sceneName: '获客触达',
    productType: 'service',
    productTypeName: '专属服务类',
    customerLevel: 'potential',
    customerLevelName: '潜在客户',
    style: 'professional',
    styleName: '专业型',
    summary: '您好，我是XX证券的投资顾问。了解到您对投资理财比较关注，想简单介绍一下我们的服务...',
    content: `您好，我是XX证券的投资顾问。

了解到您对投资理财比较关注，想简单介绍一下我们的服务。

我们提供：
- 专业的投资咨询服务
- 丰富的投资工具和资源
- 完善的客户服务体系

服务特色：
- 一对一专属投顾
- 定期市场分析
- 投资者教育培训

如果您感兴趣，我可以：
1. 为您详细介绍服务内容
2. 解答您的疑问
3. 根据您的需求提供个性化建议

不会占用您太多时间，大约10分钟左右。

请问您现在方便沟通吗？`,
    relatedContent: null,
    isFavorite: false,
    isHighUsage: true,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR009',
    title: '个人修改版 - 基金定投话术',
    scene: 'product',
    sceneName: '产品推荐',
    productType: 'operation',
    productTypeName: '实操辅助类',
    customerLevel: 'existing_basic',
    customerLevelName: '存量客户（基础付费）',
    style: 'friendly',
    styleName: '亲切型',
    summary: '您好，我是您的投资顾问小王。看您最近对基金挺感兴趣的，咱们聊聊基金定投这个事儿...',
    content: `您好，我是您的投资顾问小王。

看您最近对基金挺感兴趣的，咱们聊聊基金定投这个事儿。

简单说，就是每个月固定时间、固定金额买基金，好处是：
- 不用天天盯盘
- 平摊成本
- 养成储蓄习惯

我们这边能提供：
- 帮您设置自动定投
- 定期给您发市场分析
- 随时调整计划

您要是有兴趣，咱们可以根据您的情况，一起制定个合适的计划。

方便的话，咱们约个时间详细聊聊？`,
    relatedContent: null,
    isFavorite: true,
    isHighUsage: false,
    auditStatus: 'pending',
    isPersonal: true,
  },
  {
    id: 'SCR010',
    title: '社区活动邀约话术',
    scene: 'activity',
    sceneName: '活动邀约',
    productType: 'community',
    productTypeName: '社区互动类',
    customerLevel: 'medium_value',
    customerLevelName: '中价值客户',
    style: 'friendly',
    styleName: '亲切型',
    summary: '您好，我们的投资者社区本周将举办线上交流活动，邀请您一起参与讨论...',
    content: `您好，我是您的投资顾问。

我们的投资者社区本周将举办线上交流活动，邀请您一起参与。

活动形式：
- 线上社群讨论
- 投资经验分享
- 问题答疑交流

本期主题：
如何在震荡市场中保持理性投资

活动特色：
- 与其他投资者交流心得
- 学习不同的投资思路
- 获取实用的投资技巧

参与方式：
扫码加入社群，活动时间会提前通知

这是一个很好的学习和交流机会，建议您参与。

请问您有兴趣加入吗？`,
    relatedContent: null,
    isFavorite: false,
    isHighUsage: false,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR011',
    title: '知识课程推荐话术',
    scene: 'product',
    sceneName: '产品推荐',
    productType: 'knowledge',
    productTypeName: '知识赋能类',
    customerLevel: 'potential',
    customerLevelName: '潜在客户',
    style: 'professional',
    styleName: '专业型',
    summary: '您好，注意到您是投资新手，想向您推荐我们的投资者教育课程...',
    content: `您好，我是您的投资顾问。

注意到您是投资新手，想向您推荐我们的投资者教育课程。

课程内容：
1. 投资基础知识
   - 金融市场介绍
   - 投资工具认识
   - 风险认知建立

2. 实用投资技能
   - 如何看懂财报
   - 如何分析行情
   - 如何制定计划

3. 风险管理
   - 风险识别
   - 资产配置
   - 止损策略

课程特点：
- 由浅入深，循序渐进
- 理论结合实践
- 随时回看学习

作为新客户，您可以免费试听部分课程。

请问您有兴趣了解吗？`,
    relatedContent: '投资者教育课程体系（查看详情）',
    isFavorite: false,
    isHighUsage: true,
    auditStatus: 'approved',
    isPersonal: false,
  },
  {
    id: 'SCR012',
    title: '服务升级邀约话术',
    scene: 'product',
    sceneName: '产品推荐',
    productType: 'service',
    productTypeName: '专属服务类',
    customerLevel: 'existing_basic',
    customerLevelName: '存量客户（基础付费）',
    style: 'professional',
    styleName: '专业型',
    summary: '您好，作为我们的老客户，想向您介绍一下我们的高阶服务计划...',
    content: `您好，我是您的投资顾问。

作为我们的老客户，想向您介绍一下我们的高阶服务计划。

相比基础服务，高阶服务包括：

专属服务：
- 一对一投顾服务
- 专属客户经理
- 优先响应机制

高级工具：
- 专业分析软件
- 实时数据服务
- 智能投顾系统

增值服务：
- 定期策略报告
- 专项培训课程
- 行业专家咨询

适合人群：
- 资产规模较大的客户
- 需要专业支持的投资者
- 追求深度服务的客户

我可以为您详细介绍服务内容和费用标准，您可以根据自己的需求选择。

请问您有兴趣了解吗？`,
    relatedContent: null,
    isFavorite: true,
    isHighUsage: true,
    auditStatus: 'approved',
    isPersonal: false,
  },
];
