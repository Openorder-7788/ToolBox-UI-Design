// 个性化推荐与转化跟进 Mock 数据

export const customerRecommendationsData = [
  {
    customerId: 'C001',
    customerName: '王建国',
    riskLevel: '稳健型',
    tags: ['高净值', 'VIP'],
    recommendedProducts: [
      {
        productId: 'AP002',
        productName: '专属投顾服务 - 尊享版',
        matchScore: 92,
        matchReason: '该客户资产规模达 258.6 万元，符合专属投顾服务门槛，且风险偏好为稳健型，适合一对一定制化服务',
        conversionStatus: '已浏览',
        lastViewTime: '2025-01-16 10:23',
      },
      {
        productId: 'AP007',
        productName: '家庭财富规划服务',
        matchScore: 85,
        matchReason: '高净值客户通常有家庭财富管理需求，建议介绍长期规划与资产配置服务',
        conversionStatus: '未浏览',
        lastViewTime: null,
      },
    ],
    recommendedActivities: [
      {
        activityId: 'AA003',
        activityName: '高净值客户专属理财沙龙',
        matchScore: 95,
        matchReason: 'VIP 客户，适合参加高端社交与深度交流活动',
        inviteStatus: '已邀约',
        inviteTime: '2025-01-15',
      },
    ],
    followUpSuggestion: '客户已浏览专属投顾服务但未购买，建议主动沟通了解顾虑，可强调一对一服务优势',
    followUpPriority: 'high',
  },
  {
    customerId: 'C002',
    customerName: '李明华',
    riskLevel: '平衡型',
    tags: ['新客户'],
    recommendedProducts: [
      {
        productId: 'AP003',
        productName: '投教精品课程包',
        matchScore: 88,
        matchReason: '新客户需要系统学习投资知识，课程包适合建立投资基础',
        conversionStatus: '已加入购物车',
        lastViewTime: '2025-01-14 15:47',
      },
      {
        productId: 'AP001',
        productName: '智投宝 - 基础版',
        matchScore: 82,
        matchReason: '新手客户适合使用智能投顾服务入门，降低投资门槛',
        conversionStatus: '已浏览',
        lastViewTime: '2025-01-13 09:12',
      },
    ],
    recommendedActivities: [
      {
        activityId: 'AA004',
        activityName: '投资新手训练营（第三期）',
        matchScore: 90,
        matchReason: '新客户适合参加系统化培训，建立投资认知',
        inviteStatus: '待邀约',
        inviteTime: null,
      },
    ],
    followUpSuggestion: '客户已将课程包加入购物车，建议及时跟进促成购买，可提供限时优惠信息',
    followUpPriority: 'high',
  },
  {
    customerId: 'C003',
    customerName: '陈雪梅',
    riskLevel: '积极型',
    tags: ['高净值', 'VIP', '活跃'],
    recommendedProducts: [
      {
        productId: 'AP006',
        productName: '量化策略工具包',
        matchScore: 89,
        matchReason: '活跃投资者，风险偏好积极，适合使用专业量化工具提升投资效率',
        conversionStatus: '已购买',
        purchaseTime: '2025-01-10',
      },
      {
        productId: 'AP004',
        productName: '实盘诊断助手',
        matchScore: 87,
        matchReason: '高频交易客户，建议使用持仓诊断工具优化投资组合',
        conversionStatus: '已浏览',
        lastViewTime: '2025-01-15 14:20',
      },
    ],
    recommendedActivities: [
      {
        activityId: 'AA005',
        activityName: '量化投资策略研讨会',
        matchScore: 93,
        matchReason: '已购买量化工具包的客户，适合深度学习量化策略',
        inviteStatus: '已报名',
        inviteTime: '2025-01-14',
      },
    ],
    followUpSuggestion: '客户已购买量化工具，可跟进使用体验，推荐配套的实盘诊断服务',
    followUpPriority: 'medium',
  },
  {
    customerId: 'C004',
    customerName: '刘德华',
    riskLevel: '保守型',
    tags: ['稳定'],
    recommendedProducts: [
      {
        productId: 'AP001',
        productName: '智投宝 - 基础版',
        matchScore: 85,
        matchReason: '保守型客户适合使用智能配置服务，自动控制风险',
        conversionStatus: '未浏览',
        lastViewTime: null,
      },
      {
        productId: 'AP008',
        productName: '市场研报精选订阅',
        matchScore: 80,
        matchReason: '稳健客户需要专业信息支持投资决策',
        conversionStatus: '未浏览',
        lastViewTime: null,
      },
    ],
    recommendedActivities: [
      {
        activityId: 'AA001',
        activityName: '基金投资策略线上讲座',
        matchScore: 86,
        matchReason: '保守型客户适合参加基础投资讲座，了解稳健投资方法',
        inviteStatus: '待邀约',
        inviteTime: null,
      },
    ],
    followUpSuggestion: '客户尚未浏览推荐产品，建议主动介绍智能投顾服务的风险控制优势',
    followUpPriority: 'medium',
  },
  {
    customerId: 'C006',
    customerName: '赵敏',
    riskLevel: '积极型',
    tags: ['高净值', '活跃'],
    recommendedProducts: [
      {
        productId: 'AP002',
        productName: '专属投顾服务 - 尊享版',
        matchScore: 91,
        matchReason: '高净值活跃客户，建议提供专属投顾服务提升服务体验',
        conversionStatus: '已浏览',
        lastViewTime: '2025-01-16 16:35',
      },
      {
        productId: 'AP008',
        productName: '市场研报精选订阅',
        matchScore: 84,
        matchReason: '活跃投资者需要及时的市场信息与专业研报支持',
        conversionStatus: '已购买',
        purchaseTime: '2025-01-12',
      },
    ],
    recommendedActivities: [
      {
        activityId: 'AA003',
        activityName: '高净值客户专属理财沙龙',
        matchScore: 94,
        matchReason: '高净值活跃客户，适合参加专属社交与交流活动',
        inviteStatus: '已报名',
        inviteTime: '2025-01-13',
      },
    ],
    followUpSuggestion: '客户已购买研报订阅且浏览专属投顾服务，可结合研报使用体验推荐升级服务',
    followUpPriority: 'high',
  },
  {
    customerId: 'C007',
    customerName: '孙芳',
    riskLevel: '稳健型',
    tags: ['待跟进'],
    recommendedProducts: [
      {
        productId: 'AP003',
        productName: '投教精品课程包',
        matchScore: 83,
        matchReason: '需要提升投资认知，课程包可帮助系统学习',
        conversionStatus: '未浏览',
        lastViewTime: null,
      },
      {
        productId: 'AP005',
        productName: '投资社区 VIP 会员',
        matchScore: 78,
        matchReason: '通过社区交流可以增强客户粘性与活跃度',
        conversionStatus: '未浏览',
        lastViewTime: null,
      },
    ],
    recommendedActivities: [
      {
        activityId: 'AA001',
        activityName: '基金投资策略线上讲座',
        matchScore: 82,
        matchReason: '待跟进客户可通过活动重新建立联系',
        inviteStatus: '待邀约',
        inviteTime: null,
      },
    ],
    followUpSuggestion: '客户处于待跟进状态，建议通过活动邀约重新建立联系，引导了解投教产品',
    followUpPriority: 'high',
  },
];

export const conversionStatusOptions = [
  { value: 'all', label: '全部状态' },
  { value: '未浏览', label: '未浏览' },
  { value: '已浏览', label: '已浏览' },
  { value: '已加入购物车', label: '已加入购物车' },
  { value: '已购买', label: '已购买' },
];

export const followUpPriorityOptions = [
  { value: 'all', label: '全部优先级' },
  { value: 'high', label: '高优先级' },
  { value: 'medium', label: '中优先级' },
  { value: 'low', label: '低优先级' },
];

export const conversionFunnelData = [
  { stage: '推荐触达', count: 248, percentage: 100 },
  { stage: '已浏览', count: 156, percentage: 63 },
  { stage: '加入购物车', count: 67, percentage: 27 },
  { stage: '已购买', count: 42, percentage: 17 },
];
