import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';

export default function AccountSettings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('profile');
  
  // 获取当前用户角色
  const currentUserRole = 'manager'; // manager | admin | compliance

  const tabs = [
    { id: 'profile', label: '账号信息', icon: 'ri-user-line', roles: ['manager', 'admin', 'compliance'] },
    { id: 'role', label: '角色权限', icon: 'ri-shield-user-line', roles: ['admin'] },
    { id: 'logs', label: '操作日志', icon: 'ri-file-list-3-line', roles: ['admin', 'compliance'] },
  ];

  const filteredTabs = tabs.filter(tab => tab.roles.includes(currentUserRole));

  return (
    <MainLayout>
      <PageHeader
        title="账户与权限管理"
        description="管理账号信息、角色权限与操作日志"
        breadcrumb={[
          { label: '首页', path: '/' },
          { label: '系统设置', path: '/settings' },
          { label: '账户与权限' },
        ]}
      />

      <div className="p-6">
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* 选项卡 */}
          <div className="border-b border-gray-200 px-6">
            <div className="flex gap-6">
              {filteredTabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <i className={`${tab.icon} text-base w-4 h-4 flex items-center justify-center`}></i>
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 选项卡内容 */}
          <div className="p-6">
            {activeTab === 'profile' && (
              <div className="max-w-3xl">
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">账号信息</h3>
                  <p className="text-sm text-gray-500">查看和管理您的账号基本信息</p>
                </div>

                <div className="space-y-6">
                  {/* 账号信息卡片 */}
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xl font-semibold flex-shrink-0">
                        张
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="text-lg font-semibold text-gray-900">张明</h4>
                          <span className="px-2 py-1 bg-blue-600 text-white text-xs rounded">客户经理</span>
                        </div>
                        <div className="space-y-1.5 text-sm text-gray-700">
                          <div className="flex items-center gap-2">
                            <i className="ri-mail-line w-4 h-4 flex items-center justify-center"></i>
                            <span>zhangming@securities.com</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <i className="ri-phone-line w-4 h-4 flex items-center justify-center"></i>
                            <span>138****8888</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <i className="ri-building-line w-4 h-4 flex items-center justify-center"></i>
                            <span>营销服务部 · 北京分公司</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 登录方式 */}
                  <div className="border border-gray-200 rounded-lg p-5">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="text-sm font-semibold text-gray-900 mb-1">登录方式</h4>
                        <p className="text-xs text-gray-500">当前支持企业微信授权登录</p>
                      </div>
                      <div className="flex items-center gap-2 text-green-600">
                        <i className="ri-checkbox-circle-fill w-5 h-5 flex items-center justify-center"></i>
                        <span className="text-sm font-medium">已绑定</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                        <i className="ri-wechat-fill text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-900">企业微信</div>
                        <div className="text-xs text-gray-500">最近登录：2024年1月15日 09:30</div>
                      </div>
                    </div>
                  </div>

                  {/* 账号安全 */}
                  <div className="border border-gray-200 rounded-lg p-5">
                    <h4 className="text-sm font-semibold text-gray-900 mb-4">账号安全</h4>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="flex items-center gap-3">
                          <i className="ri-lock-password-line text-gray-400 text-lg w-5 h-5 flex items-center justify-center"></i>
                          <div>
                            <div className="text-sm font-medium text-gray-900">密码管理</div>
                            <div className="text-xs text-gray-500">在企业微信中修改密码</div>
                          </div>
                        </div>
                        <Button type="text" size="small">
                          前往设置
                        </Button>
                      </div>
                      <div className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="flex items-center gap-3">
                          <i className="ri-delete-bin-line text-gray-400 text-lg w-5 h-5 flex items-center justify-center"></i>
                          <div>
                            <div className="text-sm font-medium text-gray-900">注销账号</div>
                            <div className="text-xs text-gray-500">申请注销需管理员审批</div>
                          </div>
                        </div>
                        <Button type="text" size="small">
                          申请注销
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'role' && currentUserRole === 'admin' && (
              <div>
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">角色权限配置</h3>
                  <p className="text-sm text-gray-500">管理不同角色的功能模块与操作权限</p>
                </div>
                <Button 
                  type="primary" 
                  icon="ri-settings-3-line"
                  onClick={() => navigate('/settings/account/role-config')}
                >
                  进入权限配置
                </Button>
              </div>
            )}

            {activeTab === 'logs' && (currentUserRole === 'admin' || currentUserRole === 'compliance') && (
              <div>
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">操作日志</h3>
                  <p className="text-sm text-gray-500">查看系统关键操作记录，供合规审计使用</p>
                </div>
                <Button 
                  type="primary" 
                  icon="ri-file-list-3-line"
                  onClick={() => navigate('/settings/account/operation-logs')}
                >
                  查看操作日志
                </Button>
              </div>
            )}
          </div>
        </div>

        {/* 合规提示 */}
        <div className="mt-6 bg-amber-50 border border-amber-200 rounded-lg p-5">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 flex items-center justify-center text-amber-600 flex-shrink-0 mt-0.5">
              <i className="ri-shield-check-line text-lg w-5 h-5 flex items-center justify-center"></i>
            </div>
            <div className="flex-1 text-sm text-amber-900 leading-relaxed">
              <p><strong>权限管理合规要求：</strong></p>
              <p>• 所有权限变更操作将被记录并可供审计</p>
              <p>• 不允许通过权限设置绕过合规审核流程</p>
              <p>• 角色权限变更需具备明确的业务理由与审批流程</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
