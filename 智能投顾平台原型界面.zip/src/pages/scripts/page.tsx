import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import StatusTag from '../../components/common/StatusTag';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import { scriptsData } from '../../mocks/scripts';

export default function ScriptsLibrary() {
  const [activeTab, setActiveTab] = useState<'personal' | 'team'>('team');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedScene, setSelectedScene] = useState<string>('');
  const [selectedProductType, setSelectedProductType] = useState<string>('');
  const [selectedCustomerLevel, setSelectedCustomerLevel] = useState<string>('');
  const [selectedStyle, setSelectedStyle] = useState<string>('');
  const [sortBy, setSortBy] = useState<string>('default');
  const [selectedScript, setSelectedScript] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState('');

  // 筛选选项
  const sceneOptions = [
    { label: '全部场景', value: '' },
    { label: '获客触达', value: 'acquisition' },
    { label: '开户引导', value: 'onboarding' },
    { label: '产品推荐', value: 'product' },
    { label: '活动邀约', value: 'activity' },
    { label: '沉睡唤醒', value: 'reactivation' },
    { label: '异议解答', value: 'objection' },
    { label: '节日关怀', value: 'greeting' },
  ];

  const productTypeOptions = [
    { label: '全部类型', value: '' },
    { label: '知识赋能类', value: 'knowledge' },
    { label: '专属服务类', value: 'service' },
    { label: '实操辅助类', value: 'operation' },
    { label: '社区互动类', value: 'community' },
    { label: '智能投顾类', value: 'advisory' },
  ];

  const customerLevelOptions = [
    { label: '全部客户', value: '' },
    { label: '潜在客户', value: 'potential' },
    { label: '即得客户（未购/免费体验）', value: 'prospect' },
    { label: '存量客户（基础付费）', value: 'existing_basic' },
    { label: '存量客户（高阶付费）', value: 'existing_premium' },
    { label: '高价值客户', value: 'high_value' },
    { label: '中价值客户', value: 'medium_value' },
    { label: '低价值客户', value: 'low_value' },
  ];

  const styleOptions = [
    { label: '全部风格', value: '' },
    { label: '专业型', value: 'professional' },
    { label: '亲切型', value: 'friendly' },
    { label: '简洁型', value: 'concise' },
    { label: '严谨型', value: 'rigorous' },
  ];

  const sortOptions = [
    { label: '默认排序', value: 'default' },
    { label: '最近使用优先', value: 'recent' },
    { label: '收藏优先', value: 'favorite' },
  ];

  const handleViewDetail = (script: any) => {
    setSelectedScript(script);
    setEditedContent(script.content);
    setIsEditing(false);
  };

  const handleCopyScript = () => {
    if (selectedScript) {
      navigator.clipboard.writeText(selectedScript.content);
      alert('话术已复制到剪贴板');
    }
  };

  const handleSavePersonal = () => {
    alert('已保存到个人模板库');
    setSelectedScript(null);
  };

  const handleSaveEdited = () => {
    alert('修改已保存');
    setIsEditing(false);
  };

  const filteredData = scriptsData.filter((script) => {
    if (activeTab === 'personal' && !script.isPersonal) return false;
    if (activeTab === 'team' && script.isPersonal) return false;
    return true;
  });

  const handleNavigateToTraining = () => {
    if (window.REACT_APP_NAVIGATE) {
      window.REACT_APP_NAVIGATE('/training');
    }
  };

  return (
    <MainLayout>
      <PageHeader
        title="话术库"
        description="用于客户沟通的标准话术模板与个人话术管理"
        actions={
          <Button type="primary" icon="ri-robot-2-line" onClick={handleNavigateToTraining}>
            AI 模拟训练
          </Button>
        }
      />

      <div className="p-6 space-y-6">
        {/* Tab 切换 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('team')}
              className={`flex-1 px-6 py-3 text-sm font-medium transition-colors cursor-pointer ${
                activeTab === 'team'
                  ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/30'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <i className="ri-team-line w-4 h-4 flex items-center justify-center"></i>
                <span>团队共享库</span>
                {activeTab === 'team' && (
                  <span className="px-1.5 py-0.5 bg-green-50 text-green-600 text-xs rounded border border-green-200">
                    已合规审核
                  </span>
                )}
              </div>
            </button>
            <button
              onClick={() => setActiveTab('personal')}
              className={`flex-1 px-6 py-3 text-sm font-medium transition-colors cursor-pointer ${
                activeTab === 'personal'
                  ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/30'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center justify-center gap-2">
                <i className="ri-user-line w-4 h-4 flex items-center justify-center"></i>
                <span>个人模板库</span>
              </div>
            </button>
          </div>

          {/* 检索与筛选区 */}
          <div className="p-6 border-b border-gray-200">
            <div className="grid grid-cols-6 gap-3">
              <div className="col-span-2">
                <Input
                  placeholder="输入关键词搜索话术内容"
                  value={searchKeyword}
                  onChange={setSearchKeyword}
                  prefix="ri-search-line"
                />
              </div>
              <Select options={sceneOptions} value={selectedScene} onChange={setSelectedScene} />
              <Select
                options={productTypeOptions}
                value={selectedProductType}
                onChange={setSelectedProductType}
              />
              <Select
                options={customerLevelOptions}
                value={selectedCustomerLevel}
                onChange={setSelectedCustomerLevel}
              />
              <div className="flex gap-3">
                <Select options={styleOptions} value={selectedStyle} onChange={setSelectedStyle} />
              </div>
            </div>
            <div className="flex items-center justify-between mt-3">
              <div className="flex items-center gap-3">
                <Select options={sortOptions} value={sortBy} onChange={setSortBy} />
              </div>
              <div className="text-sm text-gray-500">
                共 <span className="font-medium text-gray-900">{filteredData.length}</span> 条话术模板
              </div>
            </div>
          </div>

          {/* 话术列表 */}
          <div className="divide-y divide-gray-200">
            {filteredData.map((script) => (
              <div key={script.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-start gap-3">
                      <h4 className="text-base font-semibold text-gray-900">{script.title}</h4>
                      {script.isHighUsage && (
                        <span className="px-2 py-0.5 bg-orange-50 text-orange-600 text-xs rounded border border-orange-200 whitespace-nowrap">
                          高使用率模板
                        </span>
                      )}
                      {script.auditStatus === 'approved' && activeTab === 'team' && (
                        <span className="px-2 py-0.5 bg-green-50 text-green-600 text-xs rounded border border-green-200 whitespace-nowrap">
                          已合规审核
                        </span>
                      )}
                      {script.auditStatus === 'pending' && (
                        <span className="px-2 py-0.5 bg-amber-50 text-amber-600 text-xs rounded border border-amber-200 whitespace-nowrap">
                          待审核
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mt-3 flex-wrap">
                      <StatusTag type="info" label={script.sceneName} />
                      <StatusTag type="default" label={script.productTypeName} />
                      <StatusTag type="default" label={script.customerLevelName} />
                      <StatusTag type="default" label={script.styleName} />
                    </div>

                    <p className="text-sm text-gray-600 mt-3 line-clamp-2">{script.summary}</p>

                    {script.relatedContent && (
                      <div className="mt-3 flex items-center gap-2">
                        <i className="ri-link text-gray-400 w-4 h-4 flex items-center justify-center"></i>
                        <span className="text-sm text-gray-500">关联内容：</span>
                        <button className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer">
                          {script.relatedContent}
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2 ml-6">
                    <Button
                      type="default"
                      size="small"
                      icon="ri-file-copy-line"
                      onClick={() => {
                        navigator.clipboard.writeText(script.content);
                        alert('话术已复制到剪贴板');
                      }}
                    >
                      复制
                    </Button>
                    <Button
                      type="default"
                      size="small"
                      icon={script.isFavorite ? 'ri-star-fill' : 'ri-star-line'}
                      onClick={() => alert('收藏状态已切换')}
                    >
                      {script.isFavorite ? '已收藏' : '收藏'}
                    </Button>
                    <Button
                      type="primary"
                      size="small"
                      icon="ri-eye-line"
                      onClick={() => handleViewDetail(script)}
                    >
                      查看详情
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 提示信息 */}
        {activeTab === 'team' && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <i className="ri-information-line text-blue-600 w-5 h-5 flex items-center justify-center mt-0.5"></i>
              <div className="flex-1">
                <p className="text-sm text-blue-900 font-medium">模板使用说明</p>
                <p className="text-sm text-blue-700 mt-1">
                  团队共享库中的话术模板均已通过合规审核，可直接用于客户沟通。模板效果数据仅用于内部优化参考。
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 话术详情弹窗 */}
      {selectedScript && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-6">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
            {/* 弹窗头部 */}
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-900">{selectedScript.title}</h3>
                <div className="flex items-center gap-2 mt-2">
                  <StatusTag type="info" label={selectedScript.sceneName} />
                  <StatusTag type="default" label={selectedScript.productTypeName} />
                  <StatusTag type="default" label={selectedScript.customerLevelName} />
                  <StatusTag type="default" label={selectedScript.styleName} />
                </div>
              </div>
              <button
                onClick={() => setSelectedScript(null)}
                className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
              >
                <i className="ri-close-line text-xl w-5 h-5 flex items-center justify-center"></i>
              </button>
            </div>

            {/* 弹窗内容 */}
            <div className="flex-1 overflow-auto p-6">
              {isEditing ? (
                <textarea
                  value={editedContent}
                  onChange={(e) => setEditedContent(e.target.value)}
                  className="w-full h-full min-h-[400px] px-4 py-3 text-sm text-gray-700 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                  placeholder="编辑话术内容..."
                />
              ) : (
                <div className="prose prose-sm max-w-none">
                  <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">
                    {selectedScript.content}
                  </div>
                </div>
              )}

              {selectedScript.relatedContent && !isEditing && (
                <div className="mt-6 p-4 bg-gray-50 border border-gray-200 rounded-lg">
                  <div className="flex items-start gap-3">
                    <i className="ri-link text-gray-400 w-5 h-5 flex items-center justify-center mt-0.5"></i>
                    <div>
                      <p className="text-sm font-medium text-gray-700">关联内容</p>
                      <button className="text-sm text-blue-600 hover:text-blue-700 mt-1 cursor-pointer">
                        {selectedScript.relatedContent}
                        <i className="ri-arrow-right-line ml-1 w-3 h-3 inline-flex items-center justify-center"></i>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* 弹窗底部操作 */}
            <div className="px-6 py-4 border-t border-gray-200 bg-gray-50">
              {isEditing ? (
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-500">编辑后可保存为个人模板，仅本人可见</p>
                  <div className="flex items-center gap-3">
                    <Button type="default" onClick={() => setIsEditing(false)}>
                      取消编辑
                    </Button>
                    <Button type="primary" icon="ri-save-line" onClick={handleSaveEdited}>
                      保存修改
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-500">复制后可粘贴至企业微信等沟通工具使用</p>
                  <div className="flex items-center gap-3">
                    <Button type="default" icon="ri-file-copy-line" onClick={handleCopyScript}>
                      复制话术
                    </Button>
                    <Button type="default" icon="ri-edit-line" onClick={() => setIsEditing(true)}>
                      编辑话术
                    </Button>
                    <Button type="primary" icon="ri-save-line" onClick={handleSavePersonal}>
                      保存为个人模板
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
