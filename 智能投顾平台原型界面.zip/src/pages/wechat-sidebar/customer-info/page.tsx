import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { customersData } from '../../../mocks/customers';
import { scriptsData } from '../../../mocks/scripts';

// 模拟会话列表数据
const conversationList = [
  {
    id: 'C001',
    name: '王建国',
    lastMessage: '好的，我考虑一下',
    time: '14:30',
    unread: 0,
    status: '跟进中',
    avatar: 'W',
  },
  {
    id: 'C002',
    name: '李明华',
    lastMessage: '谢谢您的介绍',
    time: '昨天',
    unread: 2,
    status: '未转化',
    avatar: 'L',
  },
  {
    id: 'C003',
    name: '陈雪梅',
    lastMessage: '我想了解一下智能投顾',
    time: '昨天',
    unread: 0,
    status: '跟进中',
    avatar: 'C',
  },
  {
    id: 'C006',
    name: '赵敏',
    lastMessage: '好的，明天联系',
    time: '周一',
    unread: 0,
    status: '跟进中',
    avatar: 'Z',
  },
  {
    id: 'C008',
    name: '周杰伦',
    lastMessage: '收到，感谢',
    time: '周日',
    unread: 1,
    status: '跟进中',
    avatar: 'Z',
  },
];

// 模拟聊天消息数据
const getChatMessages = (customerId: string) => {
  const messageMap: Record<string, any[]> = {
    'C001': [
      { id: 1, type: 'received', content: '您好，我想了解一下你们的投顾服务', time: '14:20' },
      { id: 2, type: 'sent', content: '您好！很高兴为您服务。我们的投顾服务包括一对一专属顾问、定制化投资策略分析等内容。根据您的资产规模，我建议您了解一下我们的专属投顾服务。', time: '14:22' },
      { id: 3, type: 'system', content: '客户已阅读消息', time: '14:23' },
      { id: 4, type: 'received', content: '具体包括哪些内容？', time: '14:25' },
      { id: 5, type: 'sent', content: '专属投顾服务包括：\n1. 一对一专属顾问服务\n2. 定制化投资策略分析\n3. 定期市场分析报告\n4. 优先响应机制\n\n这项服务特别适合像您这样的高价值客户。', time: '14:27' },
      { id: 6, type: 'received', content: '好的，我考虑一下', time: '14:30' },
    ],
    'C002': [
      { id: 1, type: 'sent', content: '您好，李先生！注意到您已经开户一段时间了，想了解一下您对我们的服务是否满意？', time: '10:15' },
      { id: 2, type: 'received', content: '还可以，就是还没怎么用', time: '10:20' },
      { id: 3, type: 'sent', content: '理解您的情况。我可以为您介绍一下我们的基金定投服务，这是一个很适合新手的投资方式，可以帮助您养成投资习惯。', time: '10:22' },
      { id: 4, type: 'received', content: '谢谢您的介绍', time: '10:25' },
    ],
  };
  return messageMap[customerId] || [];
};

// 获取客户详细信息
const getCustomerDetail = (id: string) => {
  const customer = customersData.find(c => c.id === id);
  if (!customer) return null;
  
  return {
    id: customer.id,
    name: customer.name,
    customerNo: customer.id,
    valueLevel: customer.tags.includes('高净值') ? '高价值' : customer.tags.includes('新客户') ? '中价值' : '低价值',
    riskPreference: customer.riskLevel,
    investmentStage: customer.status === 'active' ? '成长期' : customer.status === 'pending' ? '观望期' : '沉睡期',
    currentProgress: customer.status === 'active' ? '已推荐服务' : customer.status === 'pending' ? '已沟通' : '已触达',
    tags: customer.tags,
    managerNotes: ['关注养老规划', '沟通配合度高'],
  };
};

// 推荐话术（根据客户筛选）
const getRecommendedScripts = (customerId: string) => {
  return scriptsData.slice(3, 5); // 返回智能投顾和服务升级话术
};

// 推荐产品/服务
const recommendedService = {
  title: '专属投顾服务 - 尊享版',
  description: '一对一专属顾问服务，定制化投资策略',
  price: '¥2999/月',
  tags: ['一对一', '定制化', '高端服务'],
};

const WeChatSidebarCustomerInfo = () => {
  const [searchParams] = useSearchParams();
  const initialCustomerId = searchParams.get('id') || 'C001';
  
  const [currentCustomerId, setCurrentCustomerId] = useState(initialCustomerId);
  const [messages, setMessages] = useState(getChatMessages(initialCustomerId));
  const [inputMessage, setInputMessage] = useState('');
  const [currentProgress, setCurrentProgress] = useState('');
  const [showScriptDetail, setShowScriptDetail] = useState<any>(null);
  const [customerTags, setCustomerTags] = useState<string[]>([]);
  const [isEditingTags, setIsEditingTags] = useState(false);
  const [newTag, setNewTag] = useState('');

  const customer = getCustomerDetail(currentCustomerId);
  const recommendedScripts = getRecommendedScripts(currentCustomerId);

  // 初始化客户进度和标签
  useState(() => {
    if (customer) {
      setCurrentProgress(customer.currentProgress);
      setCustomerTags([...customer.tags, ...customer.managerNotes]);
    }
  });

  // 切换客户
  const handleSelectCustomer = (customerId: string) => {
    setCurrentCustomerId(customerId);
    setMessages(getChatMessages(customerId));
    const newCustomer = getCustomerDetail(customerId);
    if (newCustomer) {
      setCurrentProgress(newCustomer.currentProgress);
      setCustomerTags([...newCustomer.tags, ...newCustomer.managerNotes]);
    }
  };

  // 发送消息
  const handleSendMessage = () => {
    if (inputMessage.trim()) {
      const newMessage = {
        id: messages.length + 1,
        type: 'sent',
        content: inputMessage,
        time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages([...messages, newMessage]);
      setInputMessage('');
    }
  };

  // 一键发送话术
  const handleSendScript = (script: any) => {
    const newMessage = {
      id: messages.length + 1,
      type: 'sent',
      content: script.content,
      time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages([...messages, newMessage]);
  };

  // 一键发送产品信息
  const handleSendService = () => {
    const serviceMessage = `【${recommendedService.title}】\n\n${recommendedService.description}\n\n服务特色：${recommendedService.tags.join('、')}\n\n价格：${recommendedService.price}\n\n如果您感兴趣，我可以为您详细介绍服务内容。`;
    const newMessage = {
      id: messages.length + 1,
      type: 'sent',
      content: serviceMessage,
      time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages([...messages, newMessage]);
  };

  // 修改进度
  const handleProgressChange = (progress: string) => {
    setCurrentProgress(progress);
    console.log('进度已更新为:', progress);
  };

  // 添加标签
  const handleAddTag = () => {
    if (newTag.trim() && !customerTags.includes(newTag.trim())) {
      setCustomerTags([...customerTags, newTag.trim()]);
      setNewTag('');
    }
  };

  // 删除标签
  const handleRemoveTag = (tag: string) => {
    setCustomerTags(customerTags.filter(t => t !== tag));
  };

  // 复制话术
  const handleCopyScript = (script: any) => {
    navigator.clipboard.writeText(script.content);
    alert('话术已复制到剪贴板');
  };

  if (!customer) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center">客户信息加载失败</div>;
  }

  return (
    <div className="h-screen bg-gray-100 flex overflow-hidden">
      {/* ================================================ */}
      {/* 左侧栏：客户会话列表 (20%) */}
      {/* ================================================ */}
      <div className="w-1/5 bg-white border-r border-gray-200 flex flex-col">
        {/* 顶部标题 */}
        <div className="px-4 py-4 border-b border-gray-200">
          <h2 className="text-base font-semibold text-gray-900">客户会话</h2>
          <p className="text-xs text-gray-500 mt-1">共 {conversationList.length} 个会话</p>
        </div>

        {/* 会话列表 */}
        <div className="flex-1 overflow-y-auto">
          {conversationList.map((conv) => (
            <div
              key={conv.id}
              onClick={() => handleSelectCustomer(conv.id)}
              className={`px-4 py-3 border-b border-gray-100 cursor-pointer transition-colors ${
                currentCustomerId === conv.id
                  ? 'bg-teal-50 border-l-4 border-l-teal-600'
                  : 'hover:bg-gray-50'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
                  {conv.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-900 truncate">{conv.name}</span>
                    <span className="text-xs text-gray-500 flex-shrink-0 ml-2">{conv.time}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <p className="text-xs text-gray-600 truncate flex-1">{conv.lastMessage}</p>
                    {conv.unread > 0 && (
                      <span className="ml-2 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center flex-shrink-0">
                        {conv.unread}
                      </span>
                    )}
                  </div>
                  <span className="inline-block mt-1 px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded">
                    {conv.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ================================================ */}
      {/* 中间区域：聊天主窗口 (55%) */}
      {/* ================================================ */}
      <div className="flex-1 flex flex-col bg-gray-50">
        {/* 顶部栏 */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white text-base font-semibold">
                {customer.name.charAt(0)}
              </div>
              <div>
                <h2 className="text-base font-semibold text-gray-900">{customer.name}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded">
                    {customer.valueLevel}
                  </span>
                  <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">
                    {currentProgress}
                  </span>
                </div>
              </div>
            </div>
            <div className="text-xs text-gray-500">
              客户编号：{customer.customerNo}
            </div>
          </div>
        </div>

        {/* 消息展示区 */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {messages.map((msg) => (
            <div key={msg.id}>
              {msg.type === 'system' ? (
                <div className="flex justify-center">
                  <span className="px-3 py-1 bg-gray-200 text-gray-600 text-xs rounded-full">
                    {msg.content}
                  </span>
                </div>
              ) : (
                <div className={`flex ${msg.type === 'sent' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-md ${msg.type === 'sent' ? 'order-2' : 'order-1'}`}>
                    <div
                      className={`px-4 py-2 rounded-lg ${
                        msg.type === 'sent'
                          ? 'bg-teal-600 text-white'
                          : 'bg-white text-gray-900 border border-gray-200'
                      }`}
                    >
                      <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                    </div>
                    <div className={`text-xs text-gray-500 mt-1 ${msg.type === 'sent' ? 'text-right' : 'text-left'}`}>
                      {msg.time}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* 消息输入区 */}
        <div className="bg-white border-t border-gray-200 px-6 py-4">
          <div className="flex items-end gap-3">
            <textarea
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="输入消息内容..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
              rows={3}
            />
            <button
              onClick={handleSendMessage}
              className="px-6 py-2 bg-teal-600 text-white text-sm font-medium rounded-lg hover:bg-teal-700 cursor-pointer whitespace-nowrap h-10"
            >
              <i className="ri-send-plane-fill mr-2"></i>
              发送
            </button>
          </div>
          <p className="text-xs text-gray-400 mt-2">
            <i className="ri-information-line mr-1"></i>
            按 Enter 发送，Shift + Enter 换行
          </p>
        </div>
      </div>

      {/* ================================================ */}
      {/* 右侧边栏：客户详情 & AI 辅助区 (25%) */}
      {/* ================================================ */}
      <div className="w-1/4 bg-white border-l border-gray-200 flex flex-col overflow-y-auto">
        {/* 1️⃣ 客户画像展示区 */}
        <div className="border-b border-gray-200 p-4">
          <h3 className="text-sm font-semibold text-gray-900 mb-3">客户画像</h3>
          
          <div className="space-y-2">
            <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
              <i className="ri-user-line text-teal-600 w-4 h-4 flex items-center justify-center"></i>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-gray-500">客户姓名</div>
                <div className="text-sm font-medium text-gray-900">{customer.name}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
              <i className="ri-vip-crown-line text-amber-600 w-4 h-4 flex items-center justify-center"></i>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-gray-500">客户价值等级</div>
                <div className="text-sm font-medium text-gray-900">{customer.valueLevel}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
              <i className="ri-shield-check-line text-teal-600 w-4 h-4 flex items-center justify-center"></i>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-gray-500">风险偏好</div>
                <div className="text-sm font-medium text-gray-900">{customer.riskPreference}</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
              <i className="ri-line-chart-line text-blue-600 w-4 h-4 flex items-center justify-center"></i>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-gray-500">投资阶段</div>
                <div className="text-sm font-medium text-gray-900">{customer.investmentStage}</div>
              </div>
            </div>
          </div>
          
          <p className="text-xs text-gray-400 mt-3">
            <i className="ri-information-line mr-1"></i>
            信息仅用于服务参考，不构成投资建议
          </p>
        </div>

        {/* 2️⃣ 客户标签管理区 */}
        <div className="border-b border-gray-200 p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-gray-900">客户标签</h3>
            <button
              onClick={() => setIsEditingTags(!isEditingTags)}
              className="text-xs text-teal-600 hover:text-teal-700 cursor-pointer whitespace-nowrap"
            >
              {isEditingTags ? '完成' : '编辑'}
            </button>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {customerTags.map((tag, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-teal-50 text-teal-700 text-xs rounded flex items-center gap-1"
              >
                {tag}
                {isEditingTags && (
                  <button
                    onClick={() => handleRemoveTag(tag)}
                    className="hover:text-teal-900 cursor-pointer"
                  >
                    <i className="ri-close-line"></i>
                  </button>
                )}
              </span>
            ))}
          </div>
          
          {isEditingTags && (
            <div className="flex items-center gap-2 mt-3">
              <input
                type="text"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="添加新标签"
                className="flex-1 px-2 py-1 border border-gray-300 rounded text-xs focus:outline-none focus:ring-2 focus:ring-teal-500"
                onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
              />
              <button
                onClick={handleAddTag}
                className="px-3 py-1 bg-teal-600 text-white text-xs rounded hover:bg-teal-700 cursor-pointer whitespace-nowrap"
              >
                添加
              </button>
            </div>
          )}
          
          <p className="text-xs text-gray-400 mt-3">
            <i className="ri-information-line mr-1"></i>
            标签仅用于客户服务管理，不影响风险测评结果
          </p>
        </div>

        {/* 3️⃣ 服务进度展示与编辑区 */}
        <div className="border-b border-gray-200 p-4">
          <h3 className="text-sm font-semibold text-gray-900 mb-3">服务进度</h3>
          
          <div className="grid grid-cols-2 gap-2">
            {['已触达', '已沟通', '已推荐服务', '考虑中'].map((stage) => (
              <button
                key={stage}
                onClick={() => handleProgressChange(stage)}
                className={`px-3 py-2 text-xs font-medium rounded border transition-colors cursor-pointer whitespace-nowrap ${
                  stage === currentProgress
                    ? 'bg-teal-600 text-white border-teal-600'
                    : 'bg-white text-gray-700 border-gray-300 hover:border-teal-600 hover:text-teal-600'
                }`}
              >
                {stage}
              </button>
            ))}
          </div>
          
          <p className="text-xs text-gray-400 mt-3">
            <i className="ri-time-line mr-1"></i>
            修改将自动记录时间
          </p>
        </div>

        {/* 4️⃣ AI 话术推荐区 */}
        <div className="border-b border-gray-200 p-4">
          <div className="flex items-center gap-2 mb-3">
            <i className="ri-sparkling-line text-purple-600 w-4 h-4 flex items-center justify-center"></i>
            <h3 className="text-sm font-semibold text-gray-900">AI 话术推荐</h3>
          </div>
          
          <div className="space-y-3">
            {recommendedScripts.map((script) => (
              <div key={script.id} className="p-3 bg-gray-50 rounded border border-gray-200">
                <h4 className="text-sm font-medium text-gray-900 mb-2">{script.title}</h4>
                
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2 py-0.5 bg-teal-100 text-teal-700 text-xs rounded">
                    {script.styleName}
                  </span>
                  <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">
                    {script.sceneName}
                  </span>
                </div>
                
                <p className="text-xs text-gray-600 mb-3 line-clamp-2">{script.summary}</p>
                
                <div className="grid grid-cols-3 gap-1">
                  <button
                    onClick={() => setShowScriptDetail(script)}
                    className="px-2 py-1 bg-white text-gray-700 text-xs border border-gray-300 rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                  >
                    查看
                  </button>
                  <button
                    onClick={() => handleCopyScript(script)}
                    className="px-2 py-1 bg-white text-gray-700 text-xs border border-gray-300 rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                  >
                    复制
                  </button>
                  <button
                    onClick={() => handleSendScript(script)}
                    className="px-2 py-1 bg-teal-600 text-white text-xs rounded hover:bg-teal-700 cursor-pointer whitespace-nowrap"
                  >
                    发送
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <p className="text-xs text-gray-400 mt-3">
            <i className="ri-information-line mr-1"></i>
            话术仅为服务沟通建议，不构成投资意见
          </p>
        </div>

        {/* 5️⃣ 相关产品/服务推荐区 */}
        <div className="p-4">
          <div className="flex items-center gap-2 mb-3">
            <i className="ri-service-line text-purple-600 w-4 h-4 flex items-center justify-center"></i>
            <h3 className="text-sm font-semibold text-gray-900">服务推荐</h3>
          </div>
          
          <div className="p-3 bg-gradient-to-br from-purple-50 to-blue-50 rounded border border-purple-200">
            <h4 className="text-sm font-medium text-gray-900 mb-1">{recommendedService.title}</h4>
            <p className="text-xs text-gray-600 mb-2">{recommendedService.description}</p>
            
            <div className="flex flex-wrap gap-1 mb-2">
              {recommendedService.tags.map((tag, index) => (
                <span key={index} className="px-2 py-0.5 bg-white text-purple-700 text-xs rounded">
                  {tag}
                </span>
              ))}
            </div>
            
            <div className="text-xs font-medium text-purple-900 mb-3">
              {recommendedService.price}
            </div>
            
            <button
              onClick={handleSendService}
              className="w-full px-3 py-2 bg-purple-600 text-white text-xs font-medium rounded hover:bg-purple-700 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-send-plane-line mr-1"></i>
              发送到聊天框
            </button>
          </div>
          
          <p className="text-xs text-gray-400 mt-3">
            <i className="ri-information-line mr-1"></i>
            服务介绍不涉及交易操作
          </p>
        </div>

        {/* 合规提示 */}
        <div className="bg-blue-50 border-t border-blue-200 p-4">
          <div className="flex items-start gap-2">
            <i className="ri-information-line text-blue-600 w-4 h-4 flex items-center justify-center mt-0.5 flex-shrink-0"></i>
            <div className="text-xs text-blue-800">
              <p className="mb-1">• 页面不展示收益预测和买卖建议</p>
              <p className="mb-1">• 所有内容为服务辅助建议</p>
              <p>• 所有操作可留痕、可追溯</p>
            </div>
          </div>
        </div>
      </div>

      {/* 话术详情弹窗 */}
      {showScriptDetail && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">{showScriptDetail.title}</h3>
              <button
                onClick={() => setShowScriptDetail(null)}
                className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded cursor-pointer"
              >
                <i className="ri-close-line text-xl w-5 h-5 flex items-center justify-center"></i>
              </button>
            </div>
            
            <div className="flex-1 overflow-auto p-6">
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 bg-teal-100 text-teal-700 text-sm rounded">
                  {showScriptDetail.styleName}
                </span>
                <span className="px-3 py-1 bg-blue-100 text-blue-700 text-sm rounded">
                  {showScriptDetail.sceneName}
                </span>
              </div>
              
              <div className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">
                {showScriptDetail.content}
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-gray-200 bg-gray-50 flex gap-3">
              <button
                onClick={() => {
                  handleCopyScript(showScriptDetail);
                  setShowScriptDetail(null);
                }}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 text-sm font-medium rounded hover:bg-gray-100 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-file-copy-line mr-2"></i>
                复制话术
              </button>
              <button
                onClick={() => {
                  handleSendScript(showScriptDetail);
                  setShowScriptDetail(null);
                }}
                className="flex-1 px-4 py-2 bg-teal-600 text-white text-sm font-medium rounded hover:bg-teal-700 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-send-plane-fill mr-2"></i>
                发送到聊天框
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WeChatSidebarCustomerInfo;
