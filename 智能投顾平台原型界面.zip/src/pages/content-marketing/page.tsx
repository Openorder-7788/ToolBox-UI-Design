import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import StatusTag from '../../components/common/StatusTag';
import {
  customContentTemplatesData,
  contentGenerationRecordsData,
  contentPerformanceStatsData,
  themeOptions,
  audienceOptions,
  distributionChannelOptions,
} from '../../mocks/contentMarketing';

export default function ContentMarketing() {
  const [activeTab, setActiveTab] = useState<'templates' | 'records' | 'performance'>('templates');
  const [selectedTheme, setSelectedTheme] = useState('all');
  const [selectedAudience, setSelectedAudience] = useState('all');
  const [selectedChannel, setSelectedChannel] = useState('all');
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);

  // 筛选模板
  const filteredTemplates = customContentTemplatesData.filter((template) => {
    const themeMatch = selectedTheme === 'all' || template.theme === selectedTheme;
    const audienceMatch = selectedAudience === 'all' || template.targetAudience === selectedAudience;
    return themeMatch && audienceMatch;
  });

  // 筛选记录
  const filteredRecords = contentGenerationRecordsData.filter((record) => {
    const audienceMatch = selectedAudience === 'all' || record.targetAudience === selectedAudience;
    const channelMatch = selectedChannel === 'all' || record.distributionChannel === selectedChannel;
    return audienceMatch && channelMatch;
  });

  // 内容生成弹窗
  const GenerateContentModal = () => {
    if (!showGenerateModal) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
        <div className="bg-white rounded-lg w-full max-w-2xl">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">生成定制投教内容</h3>
            <button
              onClick={() => {
                setShowGenerateModal(false);
                setSelectedTemplate(null);
              }}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-close-line text-xl w-5 h-5 flex items-center justify-center"></i>
            </button>
          </div>
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">选择内容模板</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer">
                <option>请选择模板</option>
                {customContentTemplatesData.map((template) => (
                  <option key={template.id} value={template.id}>
                    {template.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">目标客户分层</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer">
                {audienceOptions.slice(1).map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">投教主题</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer">
                {themeOptions.slice(1).map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">分发渠道</label>
              <select className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer">
                {distributionChannelOptions.slice(1).map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">目标客户数量</label>
              <input
                type="number"
                placeholder="预计推送客户数量"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="text-sm text-blue-900 font-medium mb-1">
                <i className="ri-information-line w-4 h-4 flex items-center justify-center inline-flex mr-1"></i>
                内容生成说明
              </div>
              <div className="text-sm text-blue-700 leading-relaxed">
                系统将基于所选模板和目标人群，自动生成符合客户需求的定制化投教内容。生成后可预览并编辑，确认无误后可直接分发推送。
              </div>
            </div>
          </div>
          <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-end gap-3">
            <Button
              type="default"
              onClick={() => {
                setShowGenerateModal(false);
                setSelectedTemplate(null);
              }}
            >
              取消
            </Button>
            <Button type="primary" icon="ri-magic-line">
              生成内容
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <MainLayout>
      <PageHeader
        title="投教营销赋能"
        description="生成定制化投教内容，提升客户认知与服务体验"
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-bar-chart-line" size="small">
              查看数据报表
            </Button>
            <Button type="primary" icon="ri-add-line" onClick={() => setShowGenerateModal(true)}>
              生成新内容
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* 数据概览卡片 */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-gray-500">累计生成内容</div>
              <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                <i className="ri-file-text-line text-blue-600 text-xl w-5 h-5 flex items-center justify-center"></i>
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">{contentPerformanceStatsData.totalGenerated}</div>
            <div className="text-xs text-gray-500">篇内容</div>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-gray-500">总阅读次数</div>
              <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
                <i className="ri-eye-line text-green-600 text-xl w-5 h-5 flex items-center justify-center"></i>
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">
              {contentPerformanceStatsData.totalViews.toLocaleString()}
            </div>
            <div className="text-xs text-gray-500">次浏览</div>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-gray-500">平均阅读时长</div>
              <div className="w-10 h-10 bg-amber-50 rounded-lg flex items-center justify-center">
                <i className="ri-time-line text-amber-600 text-xl w-5 h-5 flex items-center justify-center"></i>
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">{contentPerformanceStatsData.avgReadTime}</div>
            <div className="text-xs text-gray-500">阅读时长</div>
          </div>
          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-gray-500">内容转化率</div>
              <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                <i className="ri-line-chart-line text-purple-600 text-xl w-5 h-5 flex items-center justify-center"></i>
              </div>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-1">{contentPerformanceStatsData.conversionRate}%</div>
            <div className="text-xs text-gray-500">{contentPerformanceStatsData.totalConversions} 次转化</div>
          </div>
        </div>

        {/* 标签页切换 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="border-b border-gray-200 px-6">
            <div className="flex items-center gap-6">
              <button
                onClick={() => setActiveTab('templates')}
                className={`px-1 py-4 text-sm font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'templates'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                内容模板库
              </button>
              <button
                onClick={() => setActiveTab('records')}
                className={`px-1 py-4 text-sm font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'records'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                生成记录
              </button>
              <button
                onClick={() => setActiveTab('performance')}
                className={`px-1 py-4 text-sm font-medium border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                  activeTab === 'performance'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                效果统计
              </button>
            </div>
          </div>

          {/* 内容模板库 */}
          {activeTab === 'templates' && (
            <div>
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center gap-4">
                  <select
                    value={selectedTheme}
                    onChange={(e) => setSelectedTheme(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
                  >
                    {themeOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <select
                    value={selectedAudience}
                    onChange={(e) => setSelectedAudience(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
                  >
                    {audienceOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="p-6">
                <div className="grid grid-cols-3 gap-4">
                  {filteredTemplates.map((template) => (
                    <div
                      key={template.id}
                      className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-all bg-white"
                    >
                      <div className="w-full h-36">
                        <img
                          src={template.thumbnail}
                          alt={template.name}
                          className="w-full h-full object-cover object-top"
                        />
                      </div>
                      <div className="p-4">
                        <h4 className="text-base font-semibold text-gray-900 mb-2">{template.name}</h4>
                        <div className="flex items-center gap-2 mb-3">
                          <StatusTag type="info" label={template.theme} />
                          <StatusTag type="default" label={template.targetAudience} />
                        </div>
                        <p className="text-sm text-gray-600 mb-4 line-clamp-2 leading-relaxed">
                          {template.description}
                        </p>
                        <div className="grid grid-cols-3 gap-2 mb-4 text-center">
                          <div>
                            <div className="text-lg font-semibold text-gray-900">{template.usageCount}</div>
                            <div className="text-xs text-gray-500">使用次数</div>
                          </div>
                          <div>
                            <div className="text-lg font-semibold text-gray-900">{template.avgReadTime}</div>
                            <div className="text-xs text-gray-500">平均阅读</div>
                          </div>
                          <div>
                            <div className="text-lg font-semibold text-gray-900">{template.avgEngagement}%</div>
                            <div className="text-xs text-gray-500">互动率</div>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            setSelectedTemplate(template);
                            setShowGenerateModal(true);
                          }}
                          className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap"
                        >
                          使用模板生成
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 生成记录 */}
          {activeTab === 'records' && (
            <div>
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center gap-4">
                  <select
                    value={selectedAudience}
                    onChange={(e) => setSelectedAudience(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
                  >
                    {audienceOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                  <select
                    value={selectedChannel}
                    onChange={(e) => setSelectedChannel(e.target.value)}
                    className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
                  >
                    {distributionChannelOptions.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="p-6">
                <div className="space-y-3">
                  {filteredRecords.map((record) => (
                    <div
                      key={record.id}
                      className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all bg-gradient-to-br from-white to-gray-50"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="text-base font-medium text-gray-900 mb-1">{record.templateName}</h4>
                          <div className="flex items-center gap-3 text-sm text-gray-500">
                            <span>
                              <i className="ri-calendar-line w-4 h-4 flex items-center justify-center inline-flex mr-1"></i>
                              {record.generatedDate}
                            </span>
                            <span>
                              <i className="ri-send-plane-line w-4 h-4 flex items-center justify-center inline-flex mr-1"></i>
                              {record.distributionChannel}
                            </span>
                            <span>
                              <i className="ri-user-line w-4 h-4 flex items-center justify-center inline-flex mr-1"></i>
                              {record.targetAudience}
                            </span>
                          </div>
                        </div>
                        <StatusTag
                          type={record.status === 'published' ? 'success' : 'warning'}
                          label={record.status === 'published' ? '已发布' : '待发布'}
                        />
                      </div>
                      <div className="grid grid-cols-5 gap-4 p-3 bg-gray-50 rounded-lg">
                        <div className="text-center">
                          <div className="text-lg font-semibold text-gray-900">{record.targetCustomerCount}</div>
                          <div className="text-xs text-gray-500">推送客户</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-semibold text-gray-900">{record.viewCount}</div>
                          <div className="text-xs text-gray-500">浏览次数</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-semibold text-gray-900">{record.avgReadTime}</div>
                          <div className="text-xs text-gray-500">平均时长</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-semibold text-gray-900">{record.shareCount}</div>
                          <div className="text-xs text-gray-500">转发次数</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-semibold text-green-600">{record.conversionCount}</div>
                          <div className="text-xs text-gray-500">转化次数</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* 效果统计 */}
          {activeTab === 'performance' && (
            <div className="p-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="border border-gray-200 rounded-lg p-6">
                  <h4 className="text-base font-semibold text-gray-900 mb-4">表现最佳主题</h4>
                  <div className="flex items-center justify-between p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                    <div>
                      <div className="text-sm text-gray-600 mb-1">最受欢迎主题</div>
                      <div className="text-2xl font-bold text-blue-600">
                        {contentPerformanceStatsData.topPerformingTheme}
                      </div>
                    </div>
                    <i className="ri-fire-line text-4xl text-blue-600 w-10 h-10 flex items-center justify-center"></i>
                  </div>
                </div>
                <div className="border border-gray-200 rounded-lg p-6">
                  <h4 className="text-base font-semibold text-gray-900 mb-4">最活跃客户群</h4>
                  <div className="flex items-center justify-between p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-lg">
                    <div>
                      <div className="text-sm text-gray-600 mb-1">互动最多的客户</div>
                      <div className="text-2xl font-bold text-green-600">
                        {contentPerformanceStatsData.mostActiveAudience}
                      </div>
                    </div>
                    <i className="ri-user-star-line text-4xl text-green-600 w-10 h-10 flex items-center justify-center"></i>
                  </div>
                </div>
              </div>

              <div className="mt-6 border border-gray-200 rounded-lg p-6">
                <h4 className="text-base font-semibold text-gray-900 mb-4">内容效果说明</h4>
                <div className="space-y-3 text-sm text-gray-600 leading-relaxed">
                  <div className="flex items-start gap-2">
                    <i className="ri-checkbox-circle-line w-5 h-5 flex items-center justify-center text-green-600 mt-0.5"></i>
                    <span>
                      数据统计仅用于内容效果分析与优化参考，不作为客户经理绩效考核依据
                    </span>
                  </div>
                  <div className="flex items-start gap-2">
                    <i className="ri-checkbox-circle-line w-5 h-5 flex items-center justify-center text-green-600 mt-0.5"></i>
                    <span>
                      转化次数指客户在阅读内容后产生的产品浏览、咨询或购买等后续行为
                    </span>
                  </div>
                  <div className="flex items-start gap-2">
                    <i className="ri-checkbox-circle-line w-5 h-5 flex items-center justify-center text-green-600 mt-0.5"></i>
                    <span>
                      建议根据数据反馈优化内容主题与目标人群匹配度，提升客户认知与服务体验
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 内容生成弹窗 */}
      <GenerateContentModal />
    </MainLayout>
  );
}
