import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';
import StatusTag from '../../../components/common/StatusTag';
import { highValueCustomers } from '../../../mocks/followUpTasks';

export default function HighValueFollowUp() {
  const navigate = useNavigate();
  const [customers] = useState(highValueCustomers);

  return (
    <MainLayout>
      <PageHeader
        title="高价值客户待服务升级"
        description="已有付费或高资产客户，建议提升服务层级与客户体验（非强制销售）"
        breadcrumbs={[
          { label: '首页', path: '/' },
          { label: '客户跟进', path: '/' },
          { label: '高价值客户待服务升级' },
        ]}
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line">
              导出列表
            </Button>
            <Button type="primary" icon="ri-refresh-line">
              刷新数据
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* 统计卡片 */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">待沟通客户</div>
                <div className="text-3xl font-bold text-gray-900">{customers.length}</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-vip-crown-line text-2xl text-purple-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">平均匹配度</div>
                <div className="text-3xl font-bold text-gray-900">92%</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-award-line text-2xl text-blue-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">已升级成功</div>
                <div className="text-3xl font-bold text-gray-900">8</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-checkbox-circle-line text-2xl text-green-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">客户暂缓</div>
                <div className="text-3xl font-bold text-gray-900">2</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-time-line text-2xl text-orange-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
        </div>

        {/* 客户列表 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-gray-900">客户列表</h3>
              <div className="flex items-center gap-3">
                <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                  <option>全部价值等级</option>
                  <option>高价值</option>
                  <option>超高价值</option>
                </select>
                <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                  <option>按匹配度排序</option>
                  <option>按资产规模排序</option>
                  <option>按交易频次排序</option>
                </select>
              </div>
            </div>
          </div>

          <div className="divide-y divide-gray-200">
            {customers.map((customer) => (
              <div
                key={customer.id}
                className="p-6 hover:bg-gray-50 transition-colors cursor-pointer"
                onClick={() => navigate(`/follow-up/high-value/${customer.id}`)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    {/* 客户头像 */}
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-full flex items-center justify-center text-white text-lg font-medium flex-shrink-0 relative">
                      {customer.name.charAt(0)}
                      <i className="ri-vip-crown-fill absolute -top-1 -right-1 text-amber-400 text-base w-4 h-4 flex items-center justify-center"></i>
                    </div>

                    {/* 客户信息 */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-base font-semibold text-gray-900">{customer.name}</h4>
                        <span className="text-sm text-gray-500">{customer.id}</span>
                        <StatusTag type="error" label={customer.valueLevel} />
                        <StatusTag type="warning" label={customer.riskLevel} />
                        <div className="flex items-center gap-1">
                          <i className="ri-star-fill text-amber-400 text-sm w-4 h-4 flex items-center justify-center"></i>
                          <span className="text-sm font-medium text-gray-900">匹配度 {customer.matchScore}%</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 mb-3">
                        <div className="text-sm">
                          <span className="text-gray-500">联系方式：</span>
                          <span className="text-gray-900">{customer.phone}</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">资产规模：</span>
                          <span className="text-gray-900 font-medium">{customer.assets}</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">交易频次：</span>
                          <span className="text-gray-900">{customer.tradingFrequency}</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 mb-3">
                        <div className="text-sm">
                          <span className="text-gray-500">当前服务：</span>
                          <span className="text-gray-900">{customer.currentService}</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">建议升级至：</span>
                          <span className="text-blue-600 font-medium">{customer.suggestedService}</span>
                        </div>
                      </div>
                      <div className="text-sm text-gray-600 bg-blue-50 border border-blue-100 rounded p-3 leading-relaxed">
                        <i className="ri-lightbulb-line text-blue-600 w-4 h-4 flex items-center justify-center inline-block mr-1"></i>
                        {customer.upgradeReason}
                      </div>
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      type="default"
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/follow-up/high-value/${customer.id}`);
                      }}
                    >
                      查看详情
                    </Button>
                    <Button
                      type="primary"
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('开始沟通', customer.id);
                      }}
                    >
                      沟通升级
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 服务升级说明 */}
        <div className="mt-6 bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-purple-600 text-xl w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5"></i>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-900 mb-1">服务升级说明</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                服务升级建议仅供参考，需经客户沟通确认后推进，不得自动触发任何升级操作。
                沟通时应充分说明服务差异与权益内容，尊重客户选择，不构成强制推销。
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
