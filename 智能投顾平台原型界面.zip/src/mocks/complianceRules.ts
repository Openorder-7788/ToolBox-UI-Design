// 合规规则库 Mock 数据

export interface ComplianceRule {
  id: string;
  name: string;
  description: string;
  contentTypes: string[];
  riskLevel: 'high' | 'medium' | 'low';
  status: 'active' | 'inactive';
  keywords: string[];
  examples: string[];
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

export interface RiskTag {
  id: string;
  name: string;
  category: 'high' | 'medium' | 'low';
  color: string;
  description: string;
  usageCount: number;
  status: 'active' | 'inactive';
}

// 合规规则列表
export const complianceRules: ComplianceRule[] = [
  {
    id: 'rule-001',
    name: '禁止收益保证类表述',
    description: '不得使用任何形式的收益保证、保本承诺等表述',
    contentTypes: ['聊天记录', 'AI话术模板', '投顾产品介绍', '投教文章'],
    riskLevel: 'high',
    status: 'active',
    keywords: ['保证收益', '稳赚不赔', '保本保息', '年化XX%保证', '必赚', '零风险'],
    examples: [
      '❌ "这款产品年化收益可达8%，保证收益"',
      '❌ "投资这个稳赚不赔"',
      '✅ "该产品历史年化收益约8%，但过往业绩不代表未来表现"'
    ],
    createdAt: '2024-01-15',
    updatedAt: '2024-03-20',
    createdBy: '合规部-张主管'
  },
  {
    id: 'rule-002',
    name: '未签约禁止提供投顾建议',
    description: '投顾服务未完成签约前，不得提供具体投资标的建议',
    contentTypes: ['聊天记录', 'AI话术模板'],
    riskLevel: 'high',
    status: 'active',
    keywords: ['建议买入', '推荐购买', '可以考虑', '建议关注', '建议配置'],
    examples: [
      '❌ "建议您买入XX股票"',
      '❌ "推荐您配置XX基金"',
      '✅ "如需具体投资建议，欢迎了解我们的投顾服务"'
    ],
    createdAt: '2024-01-20',
    updatedAt: '2024-03-18',
    createdBy: '合规部-张主管'
  },
  {
    id: 'rule-003',
    name: '产品介绍需附风险提示',
    description: '所有产品介绍必须包含明确的风险提示内容',
    contentTypes: ['投顾产品介绍', '投教文章', '主管任务内容'],
    riskLevel: 'medium',
    status: 'active',
    keywords: ['风险提示', '投资有风险', '市场风险', '本金损失'],
    examples: [
      '❌ 仅介绍产品收益，未提及风险',
      '✅ "投资有风险，入市需谨慎。该产品可能面临市场风险、流动性风险等"'
    ],
    createdAt: '2024-02-01',
    updatedAt: '2024-03-15',
    createdBy: '合规部-李经理'
  },
  {
    id: 'rule-004',
    name: '禁止内幕信息传播',
    description: '严禁传播或暗示任何内幕信息',
    contentTypes: ['聊天记录', 'AI话术模板', '投教文章'],
    riskLevel: 'high',
    status: 'active',
    keywords: ['内部消息', '小道消息', '可靠消息', '内幕', '提前知道'],
    examples: [
      '❌ "我有内部消息，这只股票要涨"',
      '❌ "提前告诉你一个小道消息"',
      '✅ "根据公开信息和市场分析..."'
    ],
    createdAt: '2024-01-10',
    updatedAt: '2024-03-22',
    createdBy: '合规部-张主管'
  },
  {
    id: 'rule-005',
    name: '禁止误导性陈述',
    description: '不得使用夸大、片面或误导性的表述',
    contentTypes: ['聊天记录', 'AI话术模板', '投顾产品介绍', '投教文章'],
    riskLevel: 'medium',
    status: 'active',
    keywords: ['必将', '一定会', '肯定', '绝对', '百分百'],
    examples: [
      '❌ "这只股票必将迎来大牛市"',
      '❌ "该产品一定会涨"',
      '✅ "根据市场分析，该产品可能存在上涨空间，但也面临下跌风险"'
    ],
    createdAt: '2024-02-10',
    updatedAt: '2024-03-10',
    createdBy: '合规部-李经理'
  },
  {
    id: 'rule-006',
    name: '禁止诱导频繁交易',
    description: '不得通过制造紧迫感等方式诱导客户频繁交易',
    contentTypes: ['聊天记录', 'AI话术模板', '主管任务内容'],
    riskLevel: 'medium',
    status: 'active',
    keywords: ['马上', '立即', '错过就没了', '最后机会', '限时'],
    examples: [
      '❌ "马上买入，错过就没机会了"',
      '❌ "今天是最后机会，必须立即操作"',
      '✅ "您可以根据自己的投资计划合理安排"'
    ],
    createdAt: '2024-02-15',
    updatedAt: '2024-03-12',
    createdBy: '合规部-王专员'
  },
  {
    id: 'rule-007',
    name: '禁止超范围经营',
    description: '不得提供超出业务许可范围的服务或建议',
    contentTypes: ['聊天记录', 'AI话术模板', '投顾产品介绍'],
    riskLevel: 'high',
    status: 'active',
    keywords: ['代客理财', '保证金账户', '场外配资', '杠杆融资'],
    examples: [
      '❌ "我可以帮您代客理财"',
      '❌ "我们提供场外配资服务"',
      '✅ "我们提供合规的投资顾问服务"'
    ],
    createdAt: '2024-01-25',
    updatedAt: '2024-03-08',
    createdBy: '合规部-张主管'
  },
  {
    id: 'rule-008',
    name: '客户信息保护规则',
    description: '严格保护客户隐私信息，禁止泄露或不当使用',
    contentTypes: ['聊天记录', 'AI话术模板', '主管任务内容'],
    riskLevel: 'high',
    status: 'active',
    keywords: ['客户资料', '身份证号', '银行账号', '交易记录', '资产信息'],
    examples: [
      '❌ 在非加密渠道传输客户敏感信息',
      '❌ 向第三方透露客户交易记录',
      '✅ 通过合规系统查询和使用客户信息'
    ],
    createdAt: '2024-02-20',
    updatedAt: '2024-03-05',
    createdBy: '合规部-李经理'
  },
  {
    id: 'rule-009',
    name: '禁止不当比较',
    description: '不得进行不当的产品比较或贬低竞争对手',
    contentTypes: ['聊天记录', 'AI话术模板', '投顾产品介绍', '投教文章'],
    riskLevel: 'low',
    status: 'active',
    keywords: ['比XX好', '远超', '碾压', '最好的', '第一'],
    examples: [
      '❌ "我们的产品比XX公司好得多"',
      '❌ "这是市场上最好的产品"',
      '✅ "我们的产品具有以下特点..."'
    ],
    createdAt: '2024-03-01',
    updatedAt: '2024-03-20',
    createdBy: '合规部-王专员'
  },
  {
    id: 'rule-010',
    name: '适当性管理要求',
    description: '必须遵守投资者适当性管理要求，向合适的客户推荐合适的产品',
    contentTypes: ['聊天记录', '投顾产品介绍', '主管任务内容'],
    riskLevel: 'medium',
    status: 'active',
    keywords: ['风险承受能力', '投资经验', '适当性评估', '风险等级'],
    examples: [
      '❌ 向保守型客户推荐高风险产品',
      '❌ 未进行适当性评估即推荐产品',
      '✅ "根据您的风险承受能力评估，建议关注稳健型产品"'
    ],
    createdAt: '2024-02-25',
    updatedAt: '2024-03-18',
    createdBy: '合规部-李经理'
  }
];

// 风险标签列表
export const riskTags: RiskTag[] = [
  {
    id: 'tag-001',
    name: '收益承诺',
    category: 'high',
    color: 'red',
    description: '涉及保证收益、保本保息等承诺性表述',
    usageCount: 156,
    status: 'active'
  },
  {
    id: 'tag-002',
    name: '超范围投顾',
    category: 'high',
    color: 'red',
    description: '未签约即提供具体投资建议',
    usageCount: 89,
    status: 'active'
  },
  {
    id: 'tag-003',
    name: '内幕信息',
    category: 'high',
    color: 'red',
    description: '涉嫌传播或暗示内幕信息',
    usageCount: 23,
    status: 'active'
  },
  {
    id: 'tag-004',
    name: '误导性陈述',
    category: 'medium',
    color: 'orange',
    description: '使用夸大、片面或误导性表述',
    usageCount: 134,
    status: 'active'
  },
  {
    id: 'tag-005',
    name: '风险提示不足',
    category: 'medium',
    color: 'orange',
    description: '产品介绍缺少必要的风险提示',
    usageCount: 78,
    status: 'active'
  },
  {
    id: 'tag-006',
    name: '诱导交易',
    category: 'medium',
    color: 'orange',
    description: '通过制造紧迫感诱导客户交易',
    usageCount: 67,
    status: 'active'
  },
  {
    id: 'tag-007',
    name: '不当比较',
    category: 'low',
    color: 'yellow',
    description: '进行不当的产品比较',
    usageCount: 45,
    status: 'active'
  },
  {
    id: 'tag-008',
    name: '适当性风险',
    category: 'medium',
    color: 'orange',
    description: '可能违反投资者适当性管理要求',
    usageCount: 92,
    status: 'active'
  },
  {
    id: 'tag-009',
    name: '信息保护风险',
    category: 'high',
    color: 'red',
    description: '涉及客户信息保护问题',
    usageCount: 34,
    status: 'active'
  },
  {
    id: 'tag-010',
    name: '超范围经营',
    category: 'high',
    color: 'red',
    description: '提供超出业务许可范围的服务',
    usageCount: 18,
    status: 'active'
  }
];

// 内容类型选项
export const contentTypeOptions = [
  { value: '聊天记录', label: '聊天记录' },
  { value: 'AI话术模板', label: 'AI话术模板' },
  { value: '投顾产品介绍', label: '投顾产品介绍' },
  { value: '投教文章', label: '投教文章' },
  { value: '主管任务内容', label: '主管任务内容' }
];
