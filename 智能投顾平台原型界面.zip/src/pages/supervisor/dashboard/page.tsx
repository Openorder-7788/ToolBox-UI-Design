import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';
import { supervisorDashboardData } from '../../../mocks/supervisorDashboard';

const SupervisorDashboardPage = () => {
  const navigate = useNavigate();
  const [sortBy, setSortBy] = useState<'conversion' | 'deal' | 'sleeping'>('conversion');

  const { teamMetrics, conversionFunnel, teamMembers } = supervisorDashboardData;

  // 排序团队成员
  const sortedMembers = [...teamMembers].sort((a, b) => {
    if (sortBy === 'conversion') {
      return parseFloat(b.conversionRate) - parseFloat(a.conversionRate);
    } else if (sortBy === 'transaction') {
      return parseFloat(b.transactionRate) - parseFloat(a.transactionRate);
    } else {
      return parseFloat(a.sleepingRate) - parseFloat(b.sleepingRate);
    }
  });

  // 找出转化下降最明显的环节
  const getBottleneckStage = () => {
    const rates = [
      { stage: '开户转化', rate: (conversionFunnel.openedAccount / conversionFunnel.potential) * 100 },
      { stage: '产品推荐', rate: (conversionFunnel.recommended / conversionFunnel.openedAccount) * 100 },
      { stage: '产品购买', rate: (conversionFunnel.purchased / conversionFunnel.recommended) * 100 },
    ];
    return rates.reduce((min, curr) => (curr.rate < min.rate ? curr : min));
  };

  const bottleneck = getBottleneckStage();

  // 处理点击客户经理行
  const handleManagerClick = (managerId: string) => {
    navigate(`/supervisor/member/${managerId}`);
  };

  return (
    <MainLayout>
      <PageHeader
        title="团队管理总览"
        description="掌握团队整体经营状况，识别转化瓶颈，优化团队表现"
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line">
              导出报表
            </Button>
            <Button type="primary" icon="ri-refresh-line">
              刷新数据
            </Button>
          </div>
        }
      />

      <div className="p-6 space-y-6">
        {/* 1️⃣ 团队核心指标总览区 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-base font-semibold text-gray-900">团队核心指标</h3>
            <p className="text-sm text-gray-500 mt-0.5">团队整体经营数据概览</p>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-5 gap-4">
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                    <i className="ri-team-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                  </div>
                </div>
                <div className="text-sm text-gray-600 mb-1">客户经理人数</div>
                <div className="text-3xl font-bold text-gray-900">{teamMetrics.managerCount}</div>
              </div>

              <div className="bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
                    <i className="ri-user-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                  </div>
                </div>
                <div className="text-sm text-gray-600 mb-1">团队客户总数</div>
                <div className="text-3xl font-bold text-gray-900">{teamMetrics.totalCustomers}</div>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                    <i className="ri-arrow-up-circle-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                  </div>
                </div>
                <div className="text-sm text-gray-600 mb-1">开户转化率</div>
                <div className="text-3xl font-bold text-gray-900">{teamMetrics.conversionRate}</div>
              </div>

              <div className="bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-200 rounded-lg p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-orange-600 rounded-lg flex items-center justify-center">
                    <i className="ri-shopping-cart-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                  </div>
                </div>
                <div className="text-sm text-gray-600 mb-1">投顾产品成交率</div>
                <div className="text-3xl font-bold text-gray-900">{teamMetrics.transactionRate}</div>
              </div>

              <div className="bg-gradient-to-br from-amber-50 to-amber-100 border border-amber-200 rounded-lg p-5">
                <div className="flex items-center justify-between mb-3">
                  <div className="w-10 h-10 bg-amber-600 rounded-lg flex items-center justify-center">
                    <i className="ri-vip-crown-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                  </div>
                </div>
                <div className="text-sm text-gray-600 mb-1">高价值客户覆盖率</div>
                <div className="text-3xl font-bold text-gray-900">{teamMetrics.highValueCoverage}</div>
              </div>
            </div>
          </div>
        </div>

        {/* 2️⃣ 转化漏斗概览区 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-gray-900">转化漏斗分析</h3>
                <p className="text-sm text-gray-500 mt-0.5">团队整体客户转化流程</p>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-red-50 border border-red-200 rounded-lg">
                <i className="ri-alert-line text-red-600 text-sm w-4 h-4 flex items-center justify-center"></i>
                <span className="text-sm text-red-600">
                  转化瓶颈：{bottleneck.stage}（{bottleneck.rate.toFixed(1)}%）
                </span>
              </div>
            </div>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-4 gap-6">
              {/* 潜在客户 */}
              <div className="relative">
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-300 rounded-lg p-6 text-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-user-search-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div className="text-sm font-medium text-gray-700 mb-2">潜在客户</div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">{conversionFunnel.potential}</div>
                  <div className="text-xs text-gray-500">基础客户池</div>
                </div>
                <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-white border-2 border-gray-300 rounded-full flex items-center justify-center z-10">
                  <i className="ri-arrow-right-line text-gray-600 text-sm w-4 h-4 flex items-center justify-center"></i>
                </div>
              </div>

              {/* 已开户未转化 */}
              <div className="relative">
                <div className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300 rounded-lg p-6 text-center">
                  <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-user-add-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div className="text-sm font-medium text-gray-700 mb-2">已开户未转化</div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">{conversionFunnel.openedAccount}</div>
                  <div className="text-xs text-green-600 font-medium">
                    转化率 {((conversionFunnel.openedAccount / conversionFunnel.potential) * 100).toFixed(1)}%
                  </div>
                </div>
                <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-white border-2 border-gray-300 rounded-full flex items-center justify-center z-10">
                  <i className="ri-arrow-right-line text-gray-600 text-sm w-4 h-4 flex items-center justify-center"></i>
                </div>
              </div>

              {/* 已推荐投顾产品 */}
              <div className="relative">
                <div className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-300 rounded-lg p-6 text-center">
                  <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-file-list-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div className="text-sm font-medium text-gray-700 mb-2">已推荐投顾产品</div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">{conversionFunnel.recommended}</div>
                  <div className="text-xs text-green-600 font-medium">
                    转化率 {((conversionFunnel.recommended / conversionFunnel.openedAccount) * 100).toFixed(1)}%
                  </div>
                </div>
                <div className="absolute -right-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-white border-2 border-gray-300 rounded-full flex items-center justify-center z-10">
                  <i className="ri-arrow-right-line text-gray-600 text-sm w-4 h-4 flex items-center justify-center"></i>
                </div>
              </div>

              {/* 已购买投顾产品 */}
              <div>
                <div className="bg-gradient-to-br from-amber-50 to-amber-100 border-2 border-amber-300 rounded-lg p-6 text-center">
                  <div className="w-12 h-12 bg-amber-600 rounded-full flex items-center justify-center mx-auto mb-3">
                    <i className="ri-checkbox-circle-line text-white text-xl w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div className="text-sm font-medium text-gray-700 mb-2">已购买投顾产品</div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">{conversionFunnel.purchased}</div>
                  <div className="text-xs text-green-600 font-medium">
                    成交率 {((conversionFunnel.purchased / conversionFunnel.recommended) * 100).toFixed(1)}%
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3️⃣ 团队成员表现概览区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-gray-900">团队成员表现</h3>
                <p className="text-sm text-gray-500 mt-0.5">各客户经理关键指标对比</p>
              </div>
              <div className="flex items-center gap-3">
                <select
                  className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                >
                  <option value="conversion">按开户转化率排序</option>
                  <option value="transaction">按产品成交率排序</option>
                  <option value="sleeping">按沉睡客户占比排序</option>
                </select>
              </div>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    排名
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    客户经理
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    负责客户数
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    开户转化率
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    投顾产品成交率
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    沉睡客户占比
                  </th>
                  <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                    操作
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {sortedMembers.map((member, index) => (
                  <tr
                    key={member.id}
                    onClick={() => handleManagerClick(member.id)}
                    className="border-t border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center justify-center">
                        {index === 0 && (
                          <div className="w-6 h-6 bg-amber-400 rounded-full flex items-center justify-center">
                            <i className="ri-trophy-line text-white text-sm w-4 h-4 flex items-center justify-center"></i>
                          </div>
                        )}
                        {index === 1 && (
                          <div className="w-6 h-6 bg-gray-300 rounded-full flex items-center justify-center">
                            <span className="text-white text-xs font-bold">2</span>
                          </div>
                        )}
                        {index === 2 && (
                          <div className="w-6 h-6 bg-orange-300 rounded-full flex items-center justify-center">
                            <span className="text-white text-xs font-bold">3</span>
                          </div>
                        )}
                        {index > 2 && (
                          <span className="text-sm text-gray-500 font-medium">{index + 1}</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
                          {member.name.charAt(0)}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{member.name}</div>
                          <div className="text-xs text-gray-500">{member.id}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className="text-sm font-medium text-gray-900">{member.customerCount}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex flex-col items-center gap-1">
                        <span className="text-sm font-semibold text-gray-900">{member.conversionRate}</span>
                        <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-green-500 to-green-600 rounded-full"
                            style={{ width: member.conversionRate }}
                          ></div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex flex-col items-center gap-1">
                        <span className="text-sm font-semibold text-gray-900">{member.transactionRate}</span>
                        <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full"
                            style={{ width: member.transactionRate }}
                          ></div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span
                        className={`text-sm font-medium ${
                          parseFloat(member.sleepingRate) > 20 ? 'text-red-600' : 'text-gray-900'
                        }`}
                      >
                        {member.sleepingRate}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <Button
                        size="small"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleManagerClick(member.id);
                        }}
                      >
                        查看详情
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 4️⃣ 主管行动入口区 */}
        <div className="grid grid-cols-3 gap-4">
          <button
            onClick={() => navigate('/supervisor/tasks/create')}
            className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-300 rounded-lg p-6 hover:shadow-lg transition-all cursor-pointer text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-blue-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <i className="ri-task-line text-white text-2xl w-7 h-7 flex items-center justify-center"></i>
              </div>
              <div className="flex-1">
                <div className="text-base font-semibold text-gray-900 mb-1">发布团队任务</div>
                <div className="text-sm text-gray-600">创建并分配团队运营任务</div>
              </div>
              <i className="ri-arrow-right-line text-blue-600 text-xl w-5 h-5 flex items-center justify-center group-hover:translate-x-1 transition-transform"></i>
            </div>
          </button>

          <button
            onClick={() => navigate('/supervisor/analytics/conversation')}
            className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300 rounded-lg p-6 hover:shadow-lg transition-all cursor-pointer text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-purple-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <i className="ri-chat-3-line text-white text-2xl w-7 h-7 flex items-center justify-center"></i>
              </div>
              <div className="flex-1">
                <div className="text-base font-semibold text-gray-900 mb-1">会话与话术分析</div>
                <div className="text-sm text-gray-600">查看团队沟通效果与话术使用</div>
              </div>
              <i className="ri-arrow-right-line text-purple-600 text-xl w-5 h-5 flex items-center justify-center group-hover:translate-x-1 transition-transform"></i>
            </div>
          </button>

          <button
            onClick={() => navigate('/supervisor/analytics/product')}
            className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-300 rounded-lg p-6 hover:shadow-lg transition-all cursor-pointer text-left group"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-green-600 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <i className="ri-bar-chart-box-line text-white text-2xl w-7 h-7 flex items-center justify-center"></i>
              </div>
              <div className="flex-1">
                <div className="text-base font-semibold text-gray-900 mb-1">产品转化分析</div>
                <div className="text-sm text-gray-600">查看各产品推荐与成交情况</div>
              </div>
              <i className="ri-arrow-right-line text-green-600 text-xl w-5 h-5 flex items-center justify-center group-hover:translate-x-1 transition-transform"></i>
            </div>
          </button>
        </div>
      </div>
    </MainLayout>
  );
};

export default SupervisorDashboardPage;
