
import { ReactNode } from 'react';

interface ButtonProps {
  children: ReactNode;
  type?: 'primary' | 'default' | 'text';
  size?: 'small' | 'medium' | 'large';
  icon?: string;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}

export default function Button({
  children,
  type = 'default',
  size = 'medium',
  icon,
  onClick,
  disabled = false,
  className = '',
}: ButtonProps) {
  const baseStyles = 'inline-flex items-center justify-center gap-2 font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap';
  
  const typeStyles = {
    primary: disabled
      ? 'bg-blue-300 text-white cursor-not-allowed'
      : 'bg-blue-600 text-white hover:bg-blue-700',
    default: disabled
      ? 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed'
      : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 hover:border-gray-400',
    text: disabled
      ? 'text-gray-400 cursor-not-allowed'
      : 'text-gray-700 hover:bg-gray-100',
  };

  const sizeStyles = {
    small: 'px-3 py-1.5 text-xs',
    medium: 'px-4 py-2 text-sm',
    large: 'px-5 py-2.5 text-base',
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${typeStyles[type]} ${sizeStyles[size]} ${className}`}
    >
      {icon && <i className={`${icon} w-4 h-4 flex items-center justify-center`}></i>}
      {children}
    </button>
  );
}
