import { useState } from 'react';
import MainLayout from '../../../components/layout/MainLayout';
import {
  pendingReviewItems,
  reviewedItems,
  contentTypes,
  riskLevels,
} from '../../../mocks/complianceReview';

export default function ComplianceReviewPage() {
  const [selectedType, setSelectedType] = useState('all');
  const [selectedRiskLevel, setSelectedRiskLevel] = useState('all');
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'pending' | 'reviewed'>('pending');
  const [reviewComment, setReviewComment] = useState('');

  // 风险等级样式映射
  const riskLevelStyles = {
    high: { bg: 'bg-red-100', text: 'text-red-700', border: 'border-red-200', label: '高风险' },
    medium: { bg: 'bg-orange-100', text: 'text-orange-700', border: 'border-orange-200', label: '中风险' },
    low: { bg: 'bg-yellow-100', text: 'text-yellow-700', border: 'border-yellow-200', label: '低风险' },
  };

  // 内容类型图标映射
  const typeIconMap: Record<string, string> = {
    chat: 'ri-chat-3-line',
    script: 'ri-file-text-line',
    product: 'ri-product-hunt-line',
    article: 'ri-article-line',
    task: 'ri-task-line',
  };

  // 筛选待审核内容
  const filteredPendingItems = pendingReviewItems.filter((item) => {
    const typeMatch = selectedType === 'all' || item.type === selectedType;
    const riskMatch = selectedRiskLevel === 'all' || item.riskLevel === selectedRiskLevel;
    return typeMatch && riskMatch;
  });

  // 处理审核操作
  const handleReview = (result: 'approved' | 'needRevision' | 'rejected') => {
    console.log('审核结果:', result, '审核意见:', reviewComment);
    // 这里应该调用API提交审核结果
    setSelectedItem(null);
    setReviewComment('');
  };

  return (
    <MainLayout>
      <div className="min-h-screen bg-gray-50">
        {/* 页面标题 */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">合规审核中心</h1>
              <p className="text-sm text-gray-500 mt-1">
                对话术、聊天记录、投顾产品、投教内容进行人工合规校验
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2">
                <i className="ri-filter-3-line"></i>
                高级筛选
              </button>
              <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2">
                <i className="ri-download-line"></i>
                导出记录
              </button>
            </div>
          </div>
        </div>

        <div className="p-8">
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧：筛选区 + 列表区 */}
            <div className="col-span-5">
              {/* Tab切换 */}
              <div className="bg-white rounded-xl border border-gray-200 mb-6">
                <div className="flex items-center border-b border-gray-200">
                  <button
                    onClick={() => setActiveTab('pending')}
                    className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                      activeTab === 'pending'
                        ? 'text-emerald-600 border-b-2 border-emerald-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    待审核内容
                    <span className="ml-2 px-2 py-0.5 bg-red-100 text-red-600 text-xs rounded-full">
                      {filteredPendingItems.length}
                    </span>
                  </button>
                  <button
                    onClick={() => setActiveTab('reviewed')}
                    className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                      activeTab === 'reviewed'
                        ? 'text-emerald-600 border-b-2 border-emerald-600'
                        : 'text-gray-500 hover:text-gray-700'
                    }`}
                  >
                    已审核记录
                    <span className="ml-2 px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded-full">
                      {reviewedItems.length}
                    </span>
                  </button>
                </div>
              </div>

              {/* 筛选区 */}
              {activeTab === 'pending' && (
                <div className="bg-white rounded-xl p-6 border border-gray-200 mb-6">
                  <h3 className="text-sm font-bold text-gray-900 mb-4">内容类型筛选</h3>
                  <div className="space-y-2 mb-6">
                    {contentTypes.map((type) => (
                      <button
                        key={type.value}
                        onClick={() => setSelectedType(type.value)}
                        className={`w-full px-4 py-2.5 rounded-lg text-left transition-colors flex items-center justify-between ${
                          selectedType === type.value
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <span className="text-sm font-medium">{type.label}</span>
                        <span className="text-xs px-2 py-0.5 bg-white rounded-full">
                          {type.count}
                        </span>
                      </button>
                    ))}
                  </div>

                  <h3 className="text-sm font-bold text-gray-900 mb-4">风险等级筛选</h3>
                  <div className="space-y-2">
                    {riskLevels.map((level) => (
                      <button
                        key={level.value}
                        onClick={() => setSelectedRiskLevel(level.value)}
                        className={`w-full px-4 py-2.5 rounded-lg text-left transition-colors flex items-center justify-between ${
                          selectedRiskLevel === level.value
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                        }`}
                      >
                        <span className="text-sm font-medium">{level.label}</span>
                        <span className="text-xs px-2 py-0.5 bg-white rounded-full">
                          {level.count}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 待审核内容列表 */}
              {activeTab === 'pending' && (
                <div className="bg-white rounded-xl border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <h3 className="text-sm font-bold text-gray-900">
                      待审核列表（{filteredPendingItems.length}）
                    </h3>
                  </div>
                  <div className="divide-y divide-gray-100 max-h-[600px] overflow-y-auto">
                    {filteredPendingItems.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setSelectedItem(item)}
                        className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                          selectedItem?.id === item.id ? 'bg-emerald-50' : ''
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            riskLevelStyles[item.riskLevel as keyof typeof riskLevelStyles].bg
                          }`}>
                            <i className={`${typeIconMap[item.type]} text-lg ${
                              riskLevelStyles[item.riskLevel as keyof typeof riskLevelStyles].text
                            }`}></i>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium text-gray-900">
                                {item.typeName}
                              </span>
                              <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${
                                riskLevelStyles[item.riskLevel as keyof typeof riskLevelStyles].bg
                              } ${
                                riskLevelStyles[item.riskLevel as keyof typeof riskLevelStyles].text
                              } ${
                                riskLevelStyles[item.riskLevel as keyof typeof riskLevelStyles].border
                              }`}>
                                {riskLevelStyles[item.riskLevel as keyof typeof riskLevelStyles].label}
                              </span>
                            </div>
                            <div className="text-xs text-gray-500 mb-2">
                              {item.source} · {item.sourceRole}
                              {item.customer && ` · 客户：${item.customer}`}
                            </div>
                            <div className="text-xs text-red-600 bg-red-50 px-2 py-1 rounded">
                              <i className="ri-error-warning-line mr-1"></i>
                              {item.aiRiskSummary}
                            </div>
                            <div className="text-xs text-gray-400 mt-2">
                              {item.submitTime}
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 已审核记录列表 */}
              {activeTab === 'reviewed' && (
                <div className="bg-white rounded-xl border border-gray-200">
                  <div className="p-6 border-b border-gray-200">
                    <h3 className="text-sm font-bold text-gray-900">
                      已审核记录（{reviewedItems.length}）
                    </h3>
                  </div>
                  <div className="divide-y divide-gray-100 max-h-[600px] overflow-y-auto">
                    {reviewedItems.map((item) => (
                      <div key={item.id} className="p-4">
                        <div className="flex items-start gap-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            item.reviewResult === 'approved'
                              ? 'bg-green-100'
                              : 'bg-red-100'
                          }`}>
                            <i className={`${typeIconMap[item.type]} text-lg ${
                              item.reviewResult === 'approved'
                                ? 'text-green-600'
                                : 'text-red-600'
                            }`}></i>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium text-gray-900">
                                {item.typeName}
                              </span>
                              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                                item.reviewResult === 'approved'
                                  ? 'bg-green-100 text-green-700'
                                  : 'bg-red-100 text-red-700'
                              }`}>
                                {item.reviewResult === 'approved' ? '已通过' : '已驳回'}
                              </span>
                            </div>
                            <div className="text-xs text-gray-500 mb-2">
                              {item.source} · {item.sourceRole}
                              {item.customer && ` · 客户：${item.customer}`}
                            </div>
                            <div className="text-xs text-gray-600 bg-gray-50 px-2 py-1 rounded mb-2">
                              审核意见：{item.reviewComment}
                            </div>
                            <div className="text-xs text-gray-400">
                              {item.reviewer} · {item.reviewTime}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* 右侧：内容详情与审核操作区 */}
            <div className="col-span-7">
              {selectedItem ? (
                <div className="bg-white rounded-xl border border-gray-200">
                  {/* 内容基本信息 */}
                  <div className="p-6 border-b border-gray-200">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <h2 className="text-lg font-bold text-gray-900">
                            {selectedItem.typeName}
                          </h2>
                          <span className={`px-3 py-1 rounded-full text-xs font-medium border ${
                            riskLevelStyles[selectedItem.riskLevel as keyof typeof riskLevelStyles].bg
                          } ${
                            riskLevelStyles[selectedItem.riskLevel as keyof typeof riskLevelStyles].text
                          } ${
                            riskLevelStyles[selectedItem.riskLevel as keyof typeof riskLevelStyles].border
                          }`}>
                            {riskLevelStyles[selectedItem.riskLevel as keyof typeof riskLevelStyles].label}
                          </span>
                        </div>
                        <div className="text-sm text-gray-500">
                          来源：{selectedItem.source}（{selectedItem.sourceRole}）
                          {selectedItem.customer && ` · 关联客户：${selectedItem.customer}`}
                        </div>
                        <div className="text-sm text-gray-400 mt-1">
                          提交时间：{selectedItem.submitTime}
                        </div>
                      </div>
                      <button
                        onClick={() => setSelectedItem(null)}
                        className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                      >
                        <i className="ri-close-line text-xl"></i>
                      </button>
                    </div>

                    {/* AI风险提示 */}
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <div className="flex items-start gap-2">
                        <i className="ri-error-warning-line text-red-600 text-lg mt-0.5"></i>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-red-900 mb-1">
                            AI 风险提示
                          </div>
                          <div className="text-sm text-red-700">
                            {selectedItem.aiRiskSummary}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* 内容详情与风险标注 */}
                  <div className="p-6 border-b border-gray-200">
                    <h3 className="text-sm font-bold text-gray-900 mb-4">内容详情</h3>
                    <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-700 leading-relaxed">
                      {selectedItem.content.split('\n').map((line: string, index: number) => {
                        let processedLine = line;
                        selectedItem.riskHighlights.forEach((highlight: any) => {
                          if (line.includes(highlight.text)) {
                            processedLine = line.replace(
                              highlight.text,
                              `<mark class="bg-red-200 text-red-900 px-1 rounded">${highlight.text}</mark>`
                            );
                          }
                        });
                        return (
                          <p
                            key={index}
                            dangerouslySetInnerHTML={{ __html: processedLine }}
                            className="mb-2"
                          />
                        );
                      })}
                    </div>

                    {/* 风险标注说明 */}
                    <div className="mt-4 space-y-2">
                      <h4 className="text-sm font-bold text-gray-900">风险标注说明</h4>
                      {selectedItem.riskHighlights.map((highlight: any, index: number) => (
                        <div
                          key={index}
                          className="flex items-start gap-2 text-sm bg-red-50 border border-red-200 rounded-lg p-3"
                        >
                          <i className="ri-alert-line text-red-600 mt-0.5"></i>
                          <div>
                            <span className="font-medium text-red-900">
                              "{highlight.text}"
                            </span>
                            <span className="text-red-700 ml-2">
                              → {highlight.reason}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 合规处理操作区 */}
                  <div className="p-6">
                    <h3 className="text-sm font-bold text-gray-900 mb-4">合规处理</h3>
                    
                    {/* 审核意见输入 */}
                    <div className="mb-6">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        审核意见说明
                      </label>
                      <textarea
                        value={reviewComment}
                        onChange={(e) => setReviewComment(e.target.value)}
                        placeholder="请填写审核意见或修改建议..."
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 text-sm resize-none"
                        rows={4}
                        maxLength={500}
                      />
                      <div className="text-xs text-gray-400 mt-1 text-right">
                        {reviewComment.length}/500
                      </div>
                    </div>

                    {/* 审核操作按钮 */}
                    <div className="grid grid-cols-3 gap-3">
                      <button
                        onClick={() => handleReview('approved')}
                        className="px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium whitespace-nowrap flex items-center justify-center gap-2"
                      >
                        <i className="ri-checkbox-circle-line text-lg"></i>
                        合规通过
                      </button>
                      <button
                        onClick={() => handleReview('needRevision')}
                        className="px-4 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors text-sm font-medium whitespace-nowrap flex items-center justify-center gap-2"
                      >
                        <i className="ri-edit-line text-lg"></i>
                        需要修改
                      </button>
                      <button
                        onClick={() => handleReview('rejected')}
                        className="px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium whitespace-nowrap flex items-center justify-center gap-2"
                      >
                        <i className="ri-close-circle-line text-lg"></i>
                        标记违规
                      </button>
                    </div>

                    {/* 快捷操作 */}
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="flex items-center gap-3">
                        <button className="px-3 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors whitespace-nowrap flex items-center gap-2">
                          <i className="ri-user-line"></i>
                          查看人员详情
                        </button>
                        <button className="px-3 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors whitespace-nowrap flex items-center gap-2">
                          <i className="ri-history-line"></i>
                          查看历史记录
                        </button>
                        <button className="px-3 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded-lg transition-colors whitespace-nowrap flex items-center gap-2">
                          <i className="ri-alarm-warning-line"></i>
                          发起预警
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-xl border border-gray-200 h-full flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <i className="ri-file-list-3-line text-4xl text-gray-400"></i>
                    </div>
                    <div className="text-sm text-gray-500">
                      请从左侧列表选择待审核内容
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
