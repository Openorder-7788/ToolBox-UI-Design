import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MainLayout from '../../../../components/layout/MainLayout';
import Button from '../../../../components/common/Button';
import { sleepingCustomers } from '../../../../mocks/followUpTasks';

// 推荐话术数据
const recommendedScripts = [
  {
    id: 'SCR006',
    title: '客户关怀话术',
    style: '亲和型',
    scene: '客户关怀',
    summary: '您好，好久不见！最近市场有一些新的变化，我们也推出了一些新的服务和投教内容。如果您有时间，欢迎随时与我交流...',
  },
  {
    id: 'SCR007',
    title: '持仓关怀话术',
    style: '专业型',
    scene: '服务关怀',
    summary: '您好，我注意到您持有的产品最近表现不错。作为您的客户经理，想和您分享一些市场分析和投资建议...',
  },
];

// 推荐产品数据
const recommendedProducts = [
  {
    id: 'AP006',
    name: '低门槛体验服务',
    type: '体验服务',
    price: '免费体验',
    reason: '适合沉睡客户重新激活，无门槛体验投顾服务',
    tags: ['免费体验', '低门槛', '唤醒专用'],
  },
  {
    id: 'AP008',
    name: '投教课程包',
    type: '投教服务',
    price: '¥99/季度',
    reason: '通过投教内容重新建立与客户的联系',
    tags: ['投教学习', '知识提升', '长期价值'],
  },
];

// 推荐投教内容
const recommendedContent = [
  {
    id: 'AC006',
    title: '市场回顾与2025年展望',
    type: '市场分析',
    duration: '20 分钟',
    reason: '帮助沉睡客户了解市场最新动态',
  },
  {
    id: 'AC008',
    title: '如何重新开始投资理财',
    type: '投教图文',
    duration: '10 分钟',
    reason: '适合长期未操作的客户重新建立投资信心',
  },
];

const CustomerDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const customer = sleepingCustomers.find((c) => c.id === id);
  
  const [isEditingTags, setIsEditingTags] = useState(false);
  const [managerTags, setManagerTags] = useState(customer?.historicalInterests || []);
  const [newTag, setNewTag] = useState('');
  const [showAddNote, setShowAddNote] = useState(false);
  const [noteContent, setNoteContent] = useState('');

  if (!customer) {
    return (
      <MainLayout>
        <div className="p-6">
          <div className="text-center py-12">
            <i className="ri-error-warning-line text-6xl text-gray-300 w-16 h-16 flex items-center justify-center mx-auto mb-4"></i>
            <p className="text-gray-500">客户信息不存在</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  const handleAddTag = () => {
    if (newTag.trim()) {
      setManagerTags([...managerTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (index: number) => {
    setManagerTags(managerTags.filter((_, i) => i !== index));
  };

  const handleCopyScript = (script: any) => {
    navigator.clipboard.writeText(script.summary);
    alert('话术已复制到剪贴板');
  };

  const handleAddCommunicationNote = () => {
    if (noteContent.trim()) {
      alert('沟通记录已添加');
      setNoteContent('');
      setShowAddNote(false);
    }
  };

  const handleWeChatCommunication = () => {
    navigate(`/wechat-sidebar/customer-info?id=${id}`);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* 1️⃣ 客户基础信息区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-gray-400 to-gray-500 flex items-center justify-center text-white text-2xl font-semibold relative opacity-70">
                {customer.name.charAt(0)}
                <i className="ri-zzz-line absolute -top-2 -right-2 text-orange-500 text-2xl w-6 h-6 flex items-center justify-center"></i>
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-semibold text-gray-900">{customer.name}</h1>
                  <span className="px-3 py-1 bg-gray-50 text-gray-700 text-sm font-medium rounded-full">
                    沉睡客户
                  </span>
                  <span className="px-3 py-1 bg-red-50 text-red-700 text-sm font-medium rounded-full">
                    沉睡 {customer.sleepDays} 天
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>客户编号：{customer.id}</span>
                  <span>•</span>
                  <span>最后登录：<span className="text-red-600 font-medium">{customer.lastLoginDate}</span></span>
                </div>
              </div>
            </div>
            <Button onClick={() => navigate('/follow-up/sleeping')}>
              <i className="ri-arrow-left-line mr-2"></i>
              返回列表
            </Button>
          </div>

          <div className="grid grid-cols-4 gap-6 pt-6 border-t border-gray-200">
            <div>
              <div className="text-sm text-gray-500 mb-1">联系电话</div>
              <div className="text-base font-medium text-gray-900">{customer.phone}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">资产规模</div>
              <div className="text-base font-medium text-gray-900">{customer.assets}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">风险偏好</div>
              <div className="text-base font-medium text-gray-900">{customer.riskLevel}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">最后活动</div>
              <div className="text-base font-medium text-gray-900">{customer.lastActivity}</div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              客户信息仅用于内部服务管理
            </p>
          </div>
        </div>

        {/* 2️⃣ 客户画像与标签区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">客户画像与标签</h2>

          {/* 系统标签 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <h3 className="text-sm font-medium text-gray-700">系统标签</h3>
              <span className="text-xs text-gray-400">(系统生成，只读)</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-shield-check-line text-lg text-gray-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">风险偏好</div>
                  <div className="text-sm font-medium text-gray-900">{customer.riskLevel}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-line-chart-line text-lg text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">投资阶段</div>
                  <div className="text-sm font-medium text-gray-900">成长期</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-pulse-line text-lg text-red-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">生命周期</div>
                  <div className="text-sm font-medium text-gray-900">沉睡期</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-time-line text-lg text-orange-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">沉睡时长</div>
                  <div className="text-sm font-medium text-gray-900">{customer.sleepDays} 天</div>
                </div>
              </div>
            </div>
          </div>

          {/* 客户经理标签 */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-medium text-gray-700">历史兴趣标签</h3>
                <span className="text-xs text-gray-400">(可编辑)</span>
              </div>
              <button
                onClick={() => setIsEditingTags(!isEditingTags)}
                className="text-sm text-orange-600 hover:text-orange-700 cursor-pointer whitespace-nowrap"
              >
                {isEditingTags ? '完成编辑' : '编辑标签'}
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {managerTags.map((tag, index) => (
                <span
                  key={index}
                  className="px-3 py-1.5 bg-orange-50 text-orange-700 text-sm rounded-full flex items-center gap-2"
                >
                  {tag}
                  {isEditingTags && (
                    <button
                      onClick={() => handleRemoveTag(index)}
                      className="hover:text-orange-900 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-close-line"></i>
                    </button>
                  )}
                </span>
              ))}
              {isEditingTags && (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="输入新标签"
                    className="px-3 py-1.5 border border-gray-300 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                  />
                  <button
                    onClick={handleAddTag}
                    className="px-3 py-1.5 bg-orange-600 text-white text-sm rounded-full hover:bg-orange-700 cursor-pointer whitespace-nowrap"
                  >
                    添加
                  </button>
                </div>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-3">
              <i className="ri-information-line mr-1"></i>
              标签编辑行为将记录为操作日志
            </p>
          </div>
        </div>

        {/* 3️⃣ 客户跟进进度管理区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">唤醒进度管理</h2>
            <span className="text-sm text-gray-500">当前阶段：未联系</span>
          </div>

          <div className="relative">
            <div className="flex items-center justify-between">
              {[
                { id: 1, name: '已触达', completed: false },
                { id: 2, name: '已沟通', completed: false },
                { id: 3, name: '已推荐服务', completed: false },
                { id: 4, name: '客户响应', completed: false },
                { id: 5, name: '已唤醒', completed: false },
              ].map((stage, index, arr) => (
                <div key={stage.id} className="flex flex-col items-center flex-1">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold mb-2 bg-gray-100 text-gray-400`}
                  >
                    {stage.id}
                  </div>
                  <div className="text-sm text-center text-gray-400">
                    {stage.name}
                  </div>
                  {index < arr.length - 1 && (
                    <div
                      className="absolute top-5 h-0.5 bg-gray-200"
                      style={{
                        left: `${(index / (arr.length - 1)) * 100 + 10}%`,
                        width: `${80 / (arr.length - 1)}%`,
                      }}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              进度状态仅用于服务管理参考，客户经理可手动调整当前进度
            </p>
          </div>
        </div>

        {/* 4️⃣ AI 跟进建议区 */}
        <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border border-purple-200 p-6">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
              <i className="ri-sparkling-line text-white text-lg"></i>
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">AI 唤醒建议</h2>
              <p className="text-sm text-gray-600 mb-4">
                基于客户当前状态与历史行为分析，为您提供以下唤醒建议
              </p>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 mb-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-2">当前客户状态解读</h3>
            <p className="text-sm text-gray-700 leading-relaxed">
              客户{customer.name}已沉睡<span className="font-medium text-red-600">{customer.sleepDays}天</span>。
              最后一次登录时间为{customer.lastLoginDate}，最后一次活动是{customer.lastActivity}。
              客户历史兴趣包括：{customer.historicalInterests.join('、')}。
              可能流失原因：{customer.possibleReason}。
              建议采用{customer.wakeStrategy}进行唤醒，避免客户完全流失。
            </p>
          </div>

          <div className="bg-white rounded-lg p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">建议唤醒方向</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-1 text-orange-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">情感关怀优先</div>
                  <div className="text-sm text-gray-600">
                    以关怀问候为主，避免直接推销产品，重新建立与客户的情感联系
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-2 text-orange-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">提供有价值的内容</div>
                  <div className="text-sm text-gray-600">
                    分享市场动态、投教内容等有价值的信息，重新激发客户兴趣
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-3 text-orange-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">邀请参加低门槛活动</div>
                  <div className="text-sm text-gray-600">
                    邀请客户参加免费投教活动或体验服务，降低重新参与的门槛
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-purple-100 rounded-lg">
            <p className="text-xs text-purple-800">
              <i className="ri-information-line mr-1"></i>
              以上建议仅为服务辅助提示，不构成投资建议，所有服务推荐需经客户沟通确认
            </p>
          </div>
        </div>

        {/* 5️⃣ 推荐内容区 */}
        <div className="grid grid-cols-3 gap-6">
          {/* A. 推荐话术 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-chat-quote-line text-xl text-orange-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">推荐话术</h2>
            </div>
            <div className="space-y-4">
              {recommendedScripts.map((script) => (
                <div key={script.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-sm font-semibold text-gray-900 flex-1">{script.title}</h3>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded">
                      {script.style}
                    </span>
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">
                      {script.scene}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mb-3 line-clamp-2">{script.summary}</p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleCopyScript(script)}
                      className="flex-1 px-3 py-1.5 bg-orange-600 text-white text-xs rounded hover:bg-orange-700 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-file-copy-line mr-1"></i>
                      复制话术
                    </button>
                    <button
                      onClick={() => navigate('/scripts')}
                      className="px-3 py-1.5 border border-gray-300 text-gray-700 text-xs rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                    >
                      查看详情
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* B. 投顾产品推荐 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-service-line text-xl text-purple-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">产品推荐</h2>
            </div>
            <div className="space-y-4">
              {recommendedProducts.map((product) => (
                <div key={product.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">
                      {product.type}
                    </span>
                    <span className="text-xs font-medium text-gray-900">{product.price}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {product.tags.map((tag, index) => (
                      <span key={index} className="px-2 py-0.5 bg-gray-200 text-gray-600 text-xs rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="p-2 bg-blue-50 rounded mb-3">
                    <p className="text-xs text-blue-800">
                      <i className="ri-lightbulb-line mr-1"></i>
                      推荐理由：{product.reason}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate('/advisory-products')}
                    className="w-full px-3 py-1.5 border border-purple-600 text-purple-600 text-xs rounded hover:bg-purple-50 cursor-pointer whitespace-nowrap"
                  >
                    查看详情
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* C. 投教内容推荐 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-book-open-line text-xl text-green-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">投教内容</h2>
            </div>
            <div className="space-y-4">
              {recommendedContent.map((content) => (
                <div key={content.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">{content.title}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">
                      {content.type}
                    </span>
                    <span className="text-xs text-gray-500">
                      <i className="ri-time-line mr-1"></i>
                      {content.duration}
                    </span>
                  </div>
                  <div className="p-2 bg-green-50 rounded mb-3">
                    <p className="text-xs text-green-800">
                      <i className="ri-lightbulb-line mr-1"></i>
                      {content.reason}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate('/advisory-content')}
                    className="w-full px-3 py-1.5 border border-green-600 text-green-600 text-xs rounded hover:bg-green-50 cursor-pointer whitespace-nowrap"
                  >
                    查看详情
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 6️⃣ 客户沟通与记录区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">沟通记录</h2>
            <div className="flex gap-2">
              <Button onClick={handleWeChatCommunication}>
                <i className="ri-wechat-line mr-2"></i>
                企业微信沟通
              </Button>
              <Button onClick={() => alert('发起电话')}>
                <i className="ri-phone-line mr-2"></i>
                电话沟通
              </Button>
              <Button onClick={() => setShowAddNote(!showAddNote)}>
                <i className="ri-add-line mr-2"></i>
                添加记录
              </Button>
            </div>
          </div>

          {showAddNote && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">添加沟通记录</h3>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="请输入沟通内容摘要..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-orange-500 resize-none"
                rows={4}
              />
              <div className="flex justify-end gap-2 mt-3">
                <button
                  onClick={() => setShowAddNote(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 text-sm rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                >
                  取消
                </button>
                <button
                  onClick={handleAddCommunicationNote}
                  className="px-4 py-2 bg-orange-600 text-white text-sm rounded hover:bg-orange-700 cursor-pointer whitespace-nowrap"
                >
                  保存记录
                </button>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div className="text-center py-12 text-gray-400">
              <i className="ri-inbox-line text-5xl mb-3 w-12 h-12 flex items-center justify-center mx-auto"></i>
              <p className="text-sm">暂无沟通记录</p>
              <p className="text-xs mt-1">建议尽快与客户建立联系</p>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">服务记录</h3>
            <div className="text-center py-8 text-gray-400 text-sm">
              <i className="ri-inbox-line text-4xl mb-2 w-10 h-10 flex items-center justify-center mx-auto"></i>
              暂无服务记录
            </div>
          </div>
        </div>

        {/* 合规提示 */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-blue-600 text-lg flex-shrink-0 mt-0.5"></i>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• 所有分析与推荐仅为服务辅助提示，不构成投资建议或收益承诺</p>
              <p>• 唤醒行为仅用于服务维护，不得骚扰或强制联系客户</p>
              <p>• 所有操作将被记录并可追溯，用于合规审计</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CustomerDetailPage;
