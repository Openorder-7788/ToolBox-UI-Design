
import { useState } from 'react';

export default function TopBar() {
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-white border-b border-gray-200 z-50">
      <div className="flex items-center justify-between h-full px-6">
        {/* 左侧：系统名称 + Logo */}
        <div className="flex items-center gap-3">
          <img 
            src="https://public.readdy.ai/ai/img_res/d71b1d15-d17f-415f-8db9-f742e30d45d3.png" 
            alt="系统 Logo" 
            className="h-8 w-auto"
          />
          <div className="h-6 w-px bg-gray-200"></div>
          <h1 className="text-base font-medium text-gray-800">AI 智能营销系统</h1>
        </div>

        {/* 右侧：操作区 */}
        <div className="flex items-center gap-4">
          {/* 通知 */}
          <button className="relative w-8 h-8 flex items-center justify-center text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-md transition-colors cursor-pointer">
            <i className="ri-notification-3-line text-lg"></i>
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
          </button>

          {/* 帮助 */}
          <button className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-md transition-colors cursor-pointer">
            <i className="ri-question-line text-lg"></i>
          </button>

          {/* 分隔线 */}
          <div className="h-6 w-px bg-gray-200"></div>

          {/* 用户信息 */}
          <div className="relative">
            <button 
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 px-3 py-1.5 hover:bg-gray-50 rounded-md transition-colors cursor-pointer"
            >
              <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
                张
              </div>
              <div className="text-left">
                <div className="text-sm font-medium text-gray-700">张经理</div>
                <div className="text-xs text-gray-500">投资顾问</div>
              </div>
              <i className={`ri-arrow-down-s-line text-gray-400 transition-transform ${showUserMenu ? 'rotate-180' : ''}`}></i>
            </button>

            {/* 下拉菜单 */}
            {showUserMenu && (
              <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-gray-200 rounded-lg shadow-lg">
                <div className="py-1">
                  <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2 cursor-pointer whitespace-nowrap">
                    <i className="ri-user-line w-4 h-4 flex items-center justify-center"></i>
                    个人设置
                  </button>
                  <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2 cursor-pointer whitespace-nowrap">
                    <i className="ri-shield-user-line w-4 h-4 flex items-center justify-center"></i>
                    权限管理
                  </button>
                  <div className="my-1 border-t border-gray-100"></div>
                  <button className="w-full px-4 py-2 text-left text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2 cursor-pointer whitespace-nowrap">
                    <i className="ri-logout-box-line w-4 h-4 flex items-center justify-center"></i>
                    退出登录
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
