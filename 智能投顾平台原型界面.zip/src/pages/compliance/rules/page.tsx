import { useState } from 'react';
import MainLayout from '../../../components/layout/MainLayout';
import {
  complianceRules,
  riskTags,
  contentTypeOptions,
  type ComplianceRule,
  type RiskTag,
} from '../../../mocks/complianceRules';

export default function ComplianceRulesPage() {
  const [activeTab, setActiveTab] = useState<'rules' | 'tags'>('rules');
  const [selectedRule, setSelectedRule] = useState<ComplianceRule | null>(
    complianceRules[0]
  );
  const [selectedTag, setSelectedTag] = useState<RiskTag | null>(null);
  const [ruleFilter, setRuleFilter] = useState({
    contentType: 'all',
    riskLevel: 'all',
    status: 'all',
  });
  const [tagFilter, setTagFilter] = useState({
    category: 'all',
    status: 'all',
  });
  const [showRuleModal, setShowRuleModal] = useState(false);
  const [showTagModal, setShowTagModal] = useState(false);

  // 风险等级映射
  const riskLevelMap = {
    high: { label: '高风险', color: 'bg-red-100 text-red-700 border-red-200' },
    medium: { label: '中风险', color: 'bg-orange-100 text-orange-700 border-orange-200' },
    low: { label: '低风险', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' },
  };

  // 筛选规则
  const filteredRules = complianceRules.filter((rule) => {
    if (ruleFilter.contentType !== 'all' && !rule.contentTypes.includes(ruleFilter.contentType)) {
      return false;
    }
    if (ruleFilter.riskLevel !== 'all' && rule.riskLevel !== ruleFilter.riskLevel) {
      return false;
    }
    if (ruleFilter.status !== 'all' && rule.status !== ruleFilter.status) {
      return false;
    }
    return true;
  });

  // 筛选标签
  const filteredTags = riskTags.filter((tag) => {
    if (tagFilter.category !== 'all' && tag.category !== tagFilter.category) {
      return false;
    }
    if (tagFilter.status !== 'all' && tag.status !== tagFilter.status) {
      return false;
    }
    return true;
  });

  return (
    <MainLayout>
      <div className="min-h-screen bg-gray-50">
        {/* 页面标题 */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">合规规则库</h1>
              <p className="text-sm text-gray-500 mt-1">
                管理系统内的合规规则、风险标签与校验逻辑
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2">
                <i className="ri-download-line"></i>
                导出规则
              </button>
              <button
                onClick={() => {
                  if (activeTab === 'rules') {
                    setShowRuleModal(true);
                  } else {
                    setShowTagModal(true);
                  }
                }}
                className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2"
              >
                <i className="ri-add-line"></i>
                {activeTab === 'rules' ? '新增规则' : '新增标签'}
              </button>
            </div>
          </div>
        </div>

        <div className="p-8">
          {/* Tab 切换 */}
          <div className="bg-white rounded-xl border border-gray-200 mb-6">
            <div className="flex items-center border-b border-gray-200">
              <button
                onClick={() => setActiveTab('rules')}
                className={`px-6 py-4 text-sm font-medium transition-colors relative ${
                  activeTab === 'rules'
                    ? 'text-emerald-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                合规规则管理
                {activeTab === 'rules' && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600"></div>
                )}
              </button>
              <button
                onClick={() => setActiveTab('tags')}
                className={`px-6 py-4 text-sm font-medium transition-colors relative ${
                  activeTab === 'tags'
                    ? 'text-emerald-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                风险标签管理
                {activeTab === 'tags' && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-600"></div>
                )}
              </button>
            </div>
          </div>

          {/* 合规规则管理 */}
          {activeTab === 'rules' && (
            <div className="grid grid-cols-3 gap-6">
              {/* 左侧：规则列表 */}
              <div className="col-span-1 bg-white rounded-xl border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">规则列表</h2>
                  
                  {/* 筛选器 */}
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">内容类型</label>
                      <select
                        value={ruleFilter.contentType}
                        onChange={(e) =>
                          setRuleFilter({ ...ruleFilter, contentType: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="all">全部类型</option>
                        {contentTypeOptions.map((option) => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">风险等级</label>
                      <select
                        value={ruleFilter.riskLevel}
                        onChange={(e) =>
                          setRuleFilter({ ...ruleFilter, riskLevel: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="all">全部等级</option>
                        <option value="high">高风险</option>
                        <option value="medium">中风险</option>
                        <option value="low">低风险</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">启用状态</label>
                      <select
                        value={ruleFilter.status}
                        onChange={(e) =>
                          setRuleFilter({ ...ruleFilter, status: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="all">全部状态</option>
                        <option value="active">已启用</option>
                        <option value="inactive">已停用</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* 规则列表 */}
                <div className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 400px)' }}>
                  {filteredRules.map((rule) => (
                    <div
                      key={rule.id}
                      onClick={() => setSelectedRule(rule)}
                      className={`p-4 border-b border-gray-100 cursor-pointer transition-colors ${
                        selectedRule?.id === rule.id
                          ? 'bg-emerald-50 border-l-4 border-l-emerald-600'
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="text-sm font-medium text-gray-900">{rule.name}</h3>
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${
                            riskLevelMap[rule.riskLevel].color
                          }`}
                        >
                          {riskLevelMap[rule.riskLevel].label}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mb-2 line-clamp-2">
                        {rule.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {rule.contentTypes.slice(0, 2).map((type, index) => (
                            <span
                              key={index}
                              className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded"
                            >
                              {type}
                            </span>
                          ))}
                          {rule.contentTypes.length > 2 && (
                            <span className="text-xs text-gray-400">
                              +{rule.contentTypes.length - 2}
                            </span>
                          )}
                        </div>
                        <span
                          className={`text-xs ${
                            rule.status === 'active' ? 'text-green-600' : 'text-gray-400'
                          }`}
                        >
                          {rule.status === 'active' ? '已启用' : '已停用'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 右侧：规则详情 */}
              <div className="col-span-2 bg-white rounded-xl border border-gray-200 p-6">
                {selectedRule ? (
                  <div>
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <h2 className="text-xl font-bold text-gray-900">
                            {selectedRule.name}
                          </h2>
                          <span
                            className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${
                              riskLevelMap[selectedRule.riskLevel].color
                            }`}
                          >
                            {riskLevelMap[selectedRule.riskLevel].label}
                          </span>
                          <span
                            className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                              selectedRule.status === 'active'
                                ? 'bg-green-100 text-green-700 border border-green-200'
                                : 'bg-gray-100 text-gray-700 border border-gray-200'
                            }`}
                          >
                            {selectedRule.status === 'active' ? '已启用' : '已停用'}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">{selectedRule.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="px-3 py-1.5 text-sm text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                          <i className="ri-edit-line mr-1"></i>
                          编辑
                        </button>
                        <button className="px-3 py-1.5 text-sm text-orange-600 hover:bg-orange-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                          {selectedRule.status === 'active' ? (
                            <>
                              <i className="ri-pause-circle-line mr-1"></i>
                              停用
                            </>
                          ) : (
                            <>
                              <i className="ri-play-circle-line mr-1"></i>
                              启用
                            </>
                          )}
                        </button>
                        <button className="px-3 py-1.5 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                          <i className="ri-delete-bin-line mr-1"></i>
                          删除
                        </button>
                      </div>
                    </div>

                    {/* 适用内容类型 */}
                    <div className="mb-6">
                      <h3 className="text-sm font-bold text-gray-900 mb-3">适用内容类型</h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedRule.contentTypes.map((type, index) => (
                          <span
                            key={index}
                            className="px-3 py-1.5 bg-emerald-50 text-emerald-700 text-sm rounded-lg border border-emerald-200"
                          >
                            {type}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* 关键词列表 */}
                    <div className="mb-6">
                      <h3 className="text-sm font-bold text-gray-900 mb-3">
                        风险关键词（共 {selectedRule.keywords.length} 个）
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {selectedRule.keywords.map((keyword, index) => (
                          <span
                            key={index}
                            className="px-3 py-1.5 bg-red-50 text-red-700 text-sm rounded-lg border border-red-200 font-medium"
                          >
                            {keyword}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* 规则示例 */}
                    <div className="mb-6">
                      <h3 className="text-sm font-bold text-gray-900 mb-3">规则示例</h3>
                      <div className="space-y-3">
                        {selectedRule.examples.map((example, index) => (
                          <div
                            key={index}
                            className={`p-4 rounded-lg border ${
                              example.startsWith('❌')
                                ? 'bg-red-50 border-red-200'
                                : 'bg-green-50 border-green-200'
                            }`}
                          >
                            <p
                              className={`text-sm ${
                                example.startsWith('❌') ? 'text-red-700' : 'text-green-700'
                              }`}
                            >
                              {example}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* 规则信息 */}
                    <div className="pt-6 border-t border-gray-200">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">创建人：</span>
                          <span className="text-gray-900 font-medium">
                            {selectedRule.createdBy}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">创建时间：</span>
                          <span className="text-gray-900">{selectedRule.createdAt}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">最后更新：</span>
                          <span className="text-gray-900">{selectedRule.updatedAt}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">规则ID：</span>
                          <span className="text-gray-900 font-mono text-xs">
                            {selectedRule.id}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400">
                    <div className="text-center">
                      <i className="ri-file-list-3-line text-6xl mb-4"></i>
                      <p className="text-sm">请从左侧选择一条规则查看详情</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 风险标签管理 */}
          {activeTab === 'tags' && (
            <div className="grid grid-cols-3 gap-6">
              {/* 左侧：标签列表 */}
              <div className="col-span-1 bg-white rounded-xl border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h2 className="text-lg font-bold text-gray-900 mb-4">标签列表</h2>
                  
                  {/* 筛选器 */}
                  <div className="space-y-3">
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">风险等级</label>
                      <select
                        value={tagFilter.category}
                        onChange={(e) =>
                          setTagFilter({ ...tagFilter, category: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="all">全部等级</option>
                        <option value="high">高风险</option>
                        <option value="medium">中风险</option>
                        <option value="low">低风险</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">启用状态</label>
                      <select
                        value={tagFilter.status}
                        onChange={(e) =>
                          setTagFilter({ ...tagFilter, status: e.target.value })
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="all">全部状态</option>
                        <option value="active">已启用</option>
                        <option value="inactive">已停用</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* 标签列表 */}
                <div className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 400px)' }}>
                  {filteredTags.map((tag) => (
                    <div
                      key={tag.id}
                      onClick={() => setSelectedTag(tag)}
                      className={`p-4 border-b border-gray-100 cursor-pointer transition-colors ${
                        selectedTag?.id === tag.id
                          ? 'bg-emerald-50 border-l-4 border-l-emerald-600'
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${
                              riskLevelMap[tag.category].color
                            }`}
                          >
                            {tag.name}
                          </span>
                        </div>
                        <span
                          className={`text-xs ${
                            tag.status === 'active' ? 'text-green-600' : 'text-gray-400'
                          }`}
                        >
                          {tag.status === 'active' ? '已启用' : '已停用'}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mb-2">{tag.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-400">
                          使用次数：{tag.usageCount}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 右侧：标签详情 */}
              <div className="col-span-2 bg-white rounded-xl border border-gray-200 p-6">
                {selectedTag ? (
                  <div>
                    <div className="flex items-start justify-between mb-6">
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <h2 className="text-xl font-bold text-gray-900">{selectedTag.name}</h2>
                          <span
                            className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border ${
                              riskLevelMap[selectedTag.category].color
                            }`}
                          >
                            {riskLevelMap[selectedTag.category].label}
                          </span>
                          <span
                            className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${
                              selectedTag.status === 'active'
                                ? 'bg-green-100 text-green-700 border border-green-200'
                                : 'bg-gray-100 text-gray-700 border border-gray-200'
                            }`}
                          >
                            {selectedTag.status === 'active' ? '已启用' : '已停用'}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600">{selectedTag.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button className="px-3 py-1.5 text-sm text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                          <i className="ri-edit-line mr-1"></i>
                          编辑
                        </button>
                        <button className="px-3 py-1.5 text-sm text-orange-600 hover:bg-orange-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                          {selectedTag.status === 'active' ? (
                            <>
                              <i className="ri-pause-circle-line mr-1"></i>
                              停用
                            </>
                          ) : (
                            <>
                              <i className="ri-play-circle-line mr-1"></i>
                              启用
                            </>
                          )}
                        </button>
                        <button className="px-3 py-1.5 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors font-medium whitespace-nowrap">
                          <i className="ri-delete-bin-line mr-1"></i>
                          删除
                        </button>
                      </div>
                    </div>

                    {/* 标签统计 */}
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-lg p-4 border border-emerald-200">
                        <div className="text-2xl font-bold text-emerald-700 mb-1">
                          {selectedTag.usageCount}
                        </div>
                        <div className="text-xs text-emerald-600">累计使用次数</div>
                      </div>
                      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200">
                        <div className="text-2xl font-bold text-blue-700 mb-1">
                          {Math.floor(selectedTag.usageCount / 30)}
                        </div>
                        <div className="text-xs text-blue-600">月均使用次数</div>
                      </div>
                      <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg p-4 border border-purple-200">
                        <div className="text-2xl font-bold text-purple-700 mb-1">
                          {selectedTag.status === 'active' ? '正常' : '已停用'}
                        </div>
                        <div className="text-xs text-purple-600">当前状态</div>
                      </div>
                    </div>

                    {/* 标签说明 */}
                    <div className="mb-6">
                      <h3 className="text-sm font-bold text-gray-900 mb-3">标签说明</h3>
                      <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <p className="text-sm text-gray-700">{selectedTag.description}</p>
                      </div>
                    </div>

                    {/* 关联规则 */}
                    <div className="mb-6">
                      <h3 className="text-sm font-bold text-gray-900 mb-3">关联合规规则</h3>
                      <div className="space-y-2">
                        {complianceRules
                          .filter((rule) => rule.name.includes(selectedTag.name.slice(0, 2)))
                          .slice(0, 3)
                          .map((rule) => (
                            <div
                              key={rule.id}
                              className="p-3 bg-white rounded-lg border border-gray-200 hover:border-emerald-300 transition-colors cursor-pointer"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-medium text-gray-900">
                                    {rule.name}
                                  </span>
                                  <span
                                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${
                                      riskLevelMap[rule.riskLevel].color
                                    }`}
                                  >
                                    {riskLevelMap[rule.riskLevel].label}
                                  </span>
                                </div>
                                <i className="ri-arrow-right-s-line text-gray-400"></i>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>

                    {/* 标签信息 */}
                    <div className="pt-6 border-t border-gray-200">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">标签ID：</span>
                          <span className="text-gray-900 font-mono text-xs">
                            {selectedTag.id}
                          </span>
                        </div>
                        <div>
                          <span className="text-gray-500">标签颜色：</span>
                          <span className="text-gray-900">{selectedTag.color}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400">
                    <div className="text-center">
                      <i className="ri-price-tag-3-line text-6xl mb-4"></i>
                      <p className="text-sm">请从左侧选择一个标签查看详情</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 新增规则弹窗（占位） */}
      {showRuleModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-2xl">
            <h3 className="text-lg font-bold text-gray-900 mb-4">新增合规规则</h3>
            <p className="text-sm text-gray-500 mb-4">功能开发中...</p>
            <button
              onClick={() => setShowRuleModal(false)}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors text-sm font-medium whitespace-nowrap"
            >
              关闭
            </button>
          </div>
        </div>
      )}

      {/* 新增标签弹窗（占位） */}
      {showTagModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-6 w-full max-w-2xl">
            <h3 className="text-lg font-bold text-gray-900 mb-4">新增风险标签</h3>
            <p className="text-sm text-gray-500 mb-4">功能开发中...</p>
            <button
              onClick={() => setShowTagModal(false)}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors text-sm font-medium whitespace-nowrap"
            >
              关闭
            </button>
          </div>
        </div>
      )}
    </MainLayout>
  );
}
