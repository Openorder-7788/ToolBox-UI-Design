
interface StatusTagProps {
  type: 'success' | 'warning' | 'error' | 'info' | 'default';
  label: string;
  icon?: string;
}

const typeStyles = {
  success: 'bg-green-50 text-green-700 border-green-200',
  warning: 'bg-amber-50 text-amber-700 border-amber-200',
  error: 'bg-red-50 text-red-700 border-red-200',
  info: 'bg-blue-50 text-blue-700 border-blue-200',
  default: 'bg-gray-50 text-gray-700 border-gray-200',
};

export default function StatusTag({ type, label, icon }: StatusTagProps) {
  return (
    <span
      className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium border rounded-md whitespace-nowrap ${typeStyles[type]}`}
    >
      {icon && <i className={`${icon} w-3 h-3 flex items-center justify-center`}></i>}
      {label}
    </span>
  );
}
