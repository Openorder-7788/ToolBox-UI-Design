import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import {
  performanceOverview,
  scriptUsageAnalysis,
  customerOperationAnalysis,
  abilityAnalysis,
  recentActivities
} from '../../mocks/performanceData';

export default function Service() {
  const [selectedPeriod, setSelectedPeriod] = useState('30');

  return (
    <MainLayout>
      <PageHeader
        title="我的业绩面板"
        description="以下数据用于个人服务能力复盘与提升参考"
        breadcrumb={[{ label: '首页', path: '/' }, { label: '业绩数据' }]}
      />

      <div className="p-6 space-y-6">
        {/* 统计周期选择 */}
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            当前统计周期：<span className="font-medium text-gray-900">{performanceOverview.period}</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedPeriod('7')}
              className={`px-4 py-2 text-sm rounded-lg border cursor-pointer whitespace-nowrap transition-colors ${
                selectedPeriod === '7'
                  ? 'bg-teal-50 border-teal-500 text-teal-700'
                  : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
              }`}
            >
              近7天
            </button>
            <button
              onClick={() => setSelectedPeriod('30')}
              className={`px-4 py-2 text-sm rounded-lg border cursor-pointer whitespace-nowrap transition-colors ${
                selectedPeriod === '30'
                  ? 'bg-teal-50 border-teal-500 text-teal-700'
                  : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
              }`}
            >
              近30天
            </button>
            <button
              onClick={() => setSelectedPeriod('90')}
              className={`px-4 py-2 text-sm rounded-lg border cursor-pointer whitespace-nowrap transition-colors ${
                selectedPeriod === '90'
                  ? 'bg-teal-50 border-teal-500 text-teal-700'
                  : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
              }`}
            >
              近90天
            </button>
          </div>
        </div>

        {/* 核心业务指标区 */}
        <div>
          <h3 className="text-base font-semibold text-gray-900 mb-4">核心业务指标</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 新增客户数 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                  <i className="ri-user-add-line text-blue-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">获客与转化</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceOverview.metrics.newCustomers}</div>
              <div className="text-sm text-gray-500">新增客户数</div>
            </div>

            {/* 开户转化率 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
                  <i className="ri-arrow-right-up-line text-green-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">获客与转化</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceOverview.metrics.conversionRate}%</div>
              <div className="text-sm text-gray-500">开户转化率</div>
            </div>

            {/* 产品推荐次数 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                  <i className="ri-lightbulb-line text-purple-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">投顾服务推广</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceOverview.metrics.productRecommendations}</div>
              <div className="text-sm text-gray-500">产品推荐次数</div>
            </div>

            {/* 产品成交次数 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center">
                  <i className="ri-checkbox-circle-line text-orange-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">投顾服务推广</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceOverview.metrics.productDeals}</div>
              <div className="text-sm text-gray-500">产品成交次数</div>
            </div>

            {/* 话术使用频次 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-teal-50 rounded-lg flex items-center justify-center">
                  <i className="ri-message-3-line text-teal-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">沟通与服务</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceOverview.metrics.scriptUsageCount}</div>
              <div className="text-sm text-gray-500">话术使用频次</div>
            </div>

            {/* 话术转化效率 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center">
                  <i className="ri-line-chart-line text-indigo-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">沟通与服务</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceOverview.metrics.scriptEfficiency}%</div>
              <div className="text-sm text-gray-500">话术转化效率</div>
            </div>

            {/* 客户活跃度变化 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-pink-50 rounded-lg flex items-center justify-center">
                  <i className="ri-pulse-line text-pink-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">沟通与服务</span>
              </div>
              <div className="text-2xl font-bold text-green-600 mb-1">{performanceOverview.metrics.customerActivityTrend}</div>
              <div className="text-sm text-gray-500">客户活跃度变化</div>
            </div>

            {/* 客户满意度 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-amber-50 rounded-lg flex items-center justify-center">
                  <i className="ri-star-line text-amber-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
                <span className="text-xs text-gray-400">服务质量</span>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">4.8分</div>
              <div className="text-sm text-gray-500">客户满意度评分</div>
              <div className="mt-2 text-xs text-gray-400">基于客户服务反馈</div>
            </div>
          </div>
        </div>

        {/* 行为与工具使用分析区 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 话术使用分析 */}
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-base font-semibold text-gray-900 mb-5">话术使用分析</h3>
            
            {/* 话术风格分布 */}
            <div className="mb-6">
              <div className="text-sm text-gray-600 mb-3">话术风格使用占比</div>
              <div className="space-y-3">
                {scriptUsageAnalysis.styleDistribution.map((item) => (
                  <div key={item.name}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-700">{item.name}</span>
                      <span className="font-medium text-gray-900">{item.value}%</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{ width: `${item.value}%`, backgroundColor: item.color }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 话术风格表现 */}
            <div>
              <div className="text-sm text-gray-600 mb-3">不同话术风格客户互动反馈</div>
              <div className="space-y-2">
                {scriptUsageAnalysis.stylePerformance.map((item) => (
                  <div
                    key={item.style}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium text-gray-900">{item.style}</span>
                      <span className="text-xs text-gray-500">使用{item.usageCount}次</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-xs text-gray-500">回复率</div>
                        <div className="text-sm font-medium text-gray-900">{item.replyRate}%</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-500">继续沟通率</div>
                        <div className="text-sm font-medium text-gray-900">{item.continueRate}%</div>
                      </div>
                      {item.trend === 'up' && (
                        <i className="ri-arrow-up-line text-green-600 w-4 h-4 flex items-center justify-center"></i>
                      )}
                      {item.trend === 'stable' && (
                        <i className="ri-subtract-line text-gray-400 w-4 h-4 flex items-center justify-center"></i>
                      )}
                      {item.trend === 'down' && (
                        <i className="ri-arrow-down-line text-red-600 w-4 h-4 flex items-center justify-center"></i>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 客户运营行为分析 */}
          <div className="bg-white border border-gray-200 rounded-lg p-6">
            <h3 className="text-base font-semibold text-gray-900 mb-5">客户运营行为分析</h3>
            
            {/* 跟进客户类型分布 */}
            <div className="mb-6">
              <div className="text-sm text-gray-600 mb-3">跟进客户类型分布</div>
              <div className="space-y-3">
                {customerOperationAnalysis.distribution.map((item) => (
                  <div key={item.type}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-700">{item.type}</span>
                      <span className="font-medium text-gray-900">{item.count}人 ({item.percentage}%)</span>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* 各类型客户跟进表现 */}
            <div>
              <div className="text-sm text-gray-600 mb-3">各类型客户跟进表现</div>
              <div className="space-y-2">
                {customerOperationAnalysis.performanceByType.map((item) => (
                  <div
                    key={item.type}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="text-sm font-medium text-gray-900 flex-1">{item.type}</div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-xs text-gray-500">跟进次数</div>
                        <div className="text-sm font-medium text-gray-900">{item.followUpCount}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-500">成功率</div>
                        <div className="text-sm font-medium text-gray-900">{item.successRate}%</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-500">平均响应</div>
                        <div className="text-sm font-medium text-gray-900">{item.avgResponseTime}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 能力分析与 AI 辅助建议区 */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-5">个人能力分析</h3>

          {/* 优势能力 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-medal-line text-green-600 w-5 h-5 flex items-center justify-center"></i>
              <span className="text-sm font-medium text-gray-900">优势能力</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {abilityAnalysis.strengths.map((item, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 ${
                    item.color === 'green'
                      ? 'bg-green-50 border-green-200'
                      : item.color === 'blue'
                      ? 'bg-blue-50 border-blue-200'
                      : 'bg-purple-50 border-purple-200'
                  }`}
                >
                  <div className="flex items-start gap-3 mb-2">
                    <i
                      className={`${item.icon} text-xl w-6 h-6 flex items-center justify-center ${
                        item.color === 'green'
                          ? 'text-green-600'
                          : item.color === 'blue'
                          ? 'text-blue-600'
                          : 'text-purple-600'
                      }`}
                    ></i>
                    <div className="flex-1">
                      <div
                        className={`text-sm font-medium mb-1 ${
                          item.color === 'green'
                            ? 'text-green-900'
                            : item.color === 'blue'
                            ? 'text-blue-900'
                            : 'text-purple-900'
                        }`}
                      >
                        {item.title}
                      </div>
                      <div
                        className={`text-xs leading-relaxed ${
                          item.color === 'green'
                            ? 'text-green-700'
                            : item.color === 'blue'
                            ? 'text-blue-700'
                            : 'text-purple-700'
                        }`}
                      >
                        {item.description}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 待提升能力 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-focus-line text-orange-600 w-5 h-5 flex items-center justify-center"></i>
              <span className="text-sm font-medium text-gray-900">待提升能力</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {abilityAnalysis.improvements.map((item, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${
                    item.color === 'orange'
                      ? 'bg-orange-50 border-orange-200'
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <i
                      className={`${item.icon} text-xl w-6 h-6 flex items-center justify-center ${
                        item.color === 'orange' ? 'text-orange-600' : 'text-red-600'
                      }`}
                    ></i>
                    <div className="flex-1">
                      <div
                        className={`text-sm font-medium mb-1 ${
                          item.color === 'orange' ? 'text-orange-900' : 'text-red-900'
                        }`}
                      >
                        {item.title}
                      </div>
                      <div
                        className={`text-xs leading-relaxed ${
                          item.color === 'orange' ? 'text-orange-700' : 'text-red-700'
                        }`}
                      >
                        {item.description}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 优化建议 */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-lightbulb-flash-line text-blue-600 w-5 h-5 flex items-center justify-center"></i>
              <span className="text-sm font-medium text-gray-900">优化建议（辅助性建议）</span>
            </div>
            <div className="space-y-3">
              {abilityAnalysis.suggestions.map((item, index) => (
                <div
                  key={index}
                  className="p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-start justify-between gap-4"
                >
                  <div className="flex-1">
                    <div className="text-sm font-medium text-blue-900 mb-1">{item.title}</div>
                    <div className="text-xs text-blue-700 leading-relaxed">{item.description}</div>
                  </div>
                  <Button
                    type="default"
                    size="small"
                    onClick={() => (window.REACT_APP_NAVIGATE ? window.REACT_APP_NAVIGATE(item.actionLink) : null)}
                    className="flex-shrink-0 whitespace-nowrap"
                  >
                    {item.actionText}
                    <i className="ri-arrow-right-line w-4 h-4 flex items-center justify-center"></i>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 近期服务动态 */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-5">近期服务动态</h3>
          <div className="space-y-3">
            {recentActivities.map((item, index) => (
              <div
                key={index}
                className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                    item.status === 'success'
                      ? 'bg-green-100'
                      : item.status === 'pending'
                      ? 'bg-yellow-100'
                      : 'bg-gray-200'
                  }`}
                >
                  {item.status === 'success' && (
                    <i className="ri-check-line text-green-600 w-5 h-5 flex items-center justify-center"></i>
                  )}
                  {item.status === 'pending' && (
                    <i className="ri-time-line text-yellow-600 w-5 h-5 flex items-center justify-center"></i>
                  )}
                  {item.status === 'failed' && (
                    <i className="ri-close-line text-gray-500 w-5 h-5 flex items-center justify-center"></i>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-900">{item.activity}</span>
                    <span className="text-xs text-gray-400">{item.date}</span>
                  </div>
                  <div className="text-sm text-gray-600 mb-1">{item.detail}</div>
                  <div
                    className={`text-xs ${
                      item.status === 'success'
                        ? 'text-green-600'
                        : item.status === 'pending'
                        ? 'text-yellow-600'
                        : 'text-gray-500'
                    }`}
                  >
                    {item.result}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 数据说明与合规提示区 */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
          <div className="flex gap-3">
            <i className="ri-information-line text-blue-600 text-xl w-6 h-6 flex items-center justify-center flex-shrink-0"></i>
            <div>
              <div className="text-sm font-medium text-blue-900 mb-2">数据说明与合规提示</div>
              <div className="text-sm text-blue-800 leading-relaxed space-y-1">
                <p>• 所有数据仅用于个人服务行为分析，不作为绩效考核或排名依据</p>
                <p>• 不涉及客户投资结果或收益情况，仅反映服务过程与行为数据</p>
                <p>• AI 分析结果仅供参考，不构成任何投资建议或策略判断</p>
                <p>• 所有优化建议为辅助性建议，用于能力提升，非强制执行任务</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
