
import { ReactNode } from 'react';

interface FormItemProps {
  label: string;
  required?: boolean;
  error?: string;
  children: ReactNode;
  description?: string;
}

export default function FormItem({ label, required, error, children, description }: FormItemProps) {
  return (
    <div className="mb-5">
      <label className="block mb-2">
        <span className="text-sm font-medium text-gray-700">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </span>
      </label>
      {children}
      {description && <p className="mt-1.5 text-xs text-gray-500">{description}</p>}
      {error && (
        <p className="mt-1.5 text-xs text-red-600 flex items-center gap-1">
          <i className="ri-error-warning-line w-3 h-3 flex items-center justify-center"></i>
          {error}
        </p>
      )}
    </div>
  );
}
