import { useState } from 'react';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';
import StatusTag from '../../../components/common/StatusTag';

export default function NotificationSettings() {
  const [activeTab, setActiveTab] = useState('todo');

  const tabs = [
    { id: 'todo', label: '待办提醒', icon: 'ri-task-line' },
    { id: 'compliance', label: '合规预警', icon: 'ri-shield-check-line' },
    { id: 'system', label: '系统通知', icon: 'ri-notification-3-line' },
    { id: 'rules', label: '提醒规则', icon: 'ri-settings-4-line' },
  ];

  // 待办提醒配置
  const todoNotifications = [
    {
      id: 'high-intent',
      name: '高意向客户待跟进',
      description: '客户浏览产品或咨询后未跟进',
      enabled: true,
      method: ['wechat', 'system'],
    },
    {
      id: 'sleeping',
      name: '沉睡客户唤醒提醒',
      description: '长时间未登录的客户需要重新激活',
      enabled: true,
      method: ['wechat', 'system'],
    },
    {
      id: 'callback',
      name: '产品购买后回访',
      description: '客户购买产品后的定期回访提醒',
      enabled: true,
      method: ['system'],
    },
    {
      id: 'open-account',
      name: '开户后待转化',
      description: '新开户客户超过7天未交易提醒',
      enabled: false,
      method: [],
    },
  ];

  // 合规预警配置
  const complianceAlerts = [
    {
      id: 'risk-words',
      name: '违规话术检测',
      description: '检测到使用了高风险或违规话术',
      level: 'high',
      enabled: true,
      method: ['wechat', 'system'],
    },
    {
      id: 'compliance-rate',
      name: '合规通过率预警',
      description: '话术合规通过率持续低于标准',
      level: 'medium',
      enabled: true,
      method: ['system'],
    },
    {
      id: 'audit-pending',
      name: '审核超时提醒',
      description: '话术模板提交审核超过48小时未处理',
      level: 'low',
      enabled: false,
      method: [],
    },
  ];

  // 自定义提醒规则
  const customRules = [
    {
      id: 1,
      name: '产品浏览未跟进提醒',
      condition: '客户浏览产品后 3 天未跟进',
      action: '企业微信消息提醒',
      status: 'active',
      createTime: '2024-01-10',
    },
    {
      id: 2,
      name: '高价值客户定期回访',
      condition: '资产超过100万的客户每月回访',
      action: '系统内通知',
      status: 'active',
      createTime: '2024-01-08',
    },
  ];

  return (
    <MainLayout>
      <PageHeader
        title="消息通知"
        description="管理待办提醒、合规预警与系统通知"
        breadcrumb={[
          { label: '首页', path: '/' },
          { label: '系统设置', path: '/settings' },
          { label: '消息通知' },
        ]}
        actions={
          <Button type="primary" icon="ri-save-line">
            保存配置
          </Button>
        }
      />

      <div className="p-6">
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* 选项卡 */}
          <div className="border-b border-gray-200 px-6">
            <div className="flex gap-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <i className={`${tab.icon} text-base w-4 h-4 flex items-center justify-center`}></i>
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 选项卡内容 */}
          <div className="p-6">
            {activeTab === 'todo' && (
              <div className="max-w-4xl space-y-4">
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">待办提醒配置</h3>
                  <p className="text-sm text-gray-500">设置客户跟进与服务提醒</p>
                </div>

                {todoNotifications.map((item) => (
                  <div
                    key={item.id}
                    className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="text-sm font-semibold text-gray-900">{item.name}</h4>
                          <StatusTag
                            type={item.enabled ? 'success' : 'default'}
                            label={item.enabled ? '已启用' : '已禁用'}
                            icon={item.enabled ? 'ri-checkbox-circle-line' : 'ri-close-circle-line'}
                          />
                        </div>
                        <p className="text-sm text-gray-500 mb-3">{item.description}</p>
                        {item.enabled && (
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-500">提醒方式：</span>
                            {item.method.includes('wechat') && (
                              <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded flex items-center gap-1">
                                <i className="ri-wechat-line w-3 h-3 flex items-center justify-center"></i>
                                企业微信
                              </span>
                            )}
                            {item.method.includes('system') && (
                              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded flex items-center gap-1">
                                <i className="ri-notification-3-line w-3 h-3 flex items-center justify-center"></i>
                                系统内通知
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer ml-4">
                        <input
                          type="checkbox"
                          className="sr-only peer"
                          defaultChecked={item.enabled}
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'compliance' && (
              <div className="max-w-4xl space-y-4">
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">合规预警配置</h3>
                  <p className="text-sm text-gray-500">设置合规风险提醒与预警</p>
                </div>

                {complianceAlerts.map((item) => (
                  <div
                    key={item.id}
                    className={`border-2 rounded-lg p-5 ${
                      item.level === 'high'
                        ? 'border-red-200 bg-red-50'
                        : item.level === 'medium'
                        ? 'border-amber-200 bg-amber-50'
                        : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="text-sm font-semibold text-gray-900">{item.name}</h4>
                          <span
                            className={`px-2 py-1 text-xs rounded ${
                              item.level === 'high'
                                ? 'bg-red-600 text-white'
                                : item.level === 'medium'
                                ? 'bg-amber-600 text-white'
                                : 'bg-gray-600 text-white'
                            }`}
                          >
                            {item.level === 'high' ? '高' : item.level === 'medium' ? '中' : '低'}风险
                          </span>
                          <StatusTag
                            type={item.enabled ? 'success' : 'default'}
                            label={item.enabled ? '已启用' : '已禁用'}
                            icon={item.enabled ? 'ri-checkbox-circle-line' : 'ri-close-circle-line'}
                          />
                        </div>
                        <p className="text-sm text-gray-700 mb-3">{item.description}</p>
                        {item.enabled && (
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-600">提醒方式：</span>
                            {item.method.includes('wechat') && (
                              <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded flex items-center gap-1">
                                <i className="ri-wechat-line w-3 h-3 flex items-center justify-center"></i>
                                企业微信
                              </span>
                            )}
                            {item.method.includes('system') && (
                              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded flex items-center gap-1">
                                <i className="ri-notification-3-line w-3 h-3 flex items-center justify-center"></i>
                                系统内通知
                              </span>
                            )}
                          </div>
                        )}
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer ml-4">
                        <input
                          type="checkbox"
                          className="sr-only peer"
                          defaultChecked={item.enabled}
                        />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === 'system' && (
              <div className="max-w-4xl">
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">系统通知</h3>
                  <p className="text-sm text-gray-500">查看系统更新与配置变更通知</p>
                </div>

                <div className="space-y-3">
                  {[
                    {
                      title: '系统功能更新',
                      content: '新增"客户画像分析"功能，支持多维度客户洞察',
                      time: '2024-01-15 10:00',
                      type: 'update',
                    },
                    {
                      title: '权限配置变更',
                      content: '您的角色权限已更新，新增"数据导出"权限',
                      time: '2024-01-14 15:30',
                      type: 'permission',
                    },
                    {
                      title: '系统维护通知',
                      content: '系统将于1月20日凌晨2:00-4:00进行升级维护',
                      time: '2024-01-13 09:00',
                      type: 'maintenance',
                    },
                  ].map((notice, index) => (
                    <div
                      key={index}
                      className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                            notice.type === 'update'
                              ? 'bg-blue-100 text-blue-600'
                              : notice.type === 'permission'
                              ? 'bg-green-100 text-green-600'
                              : 'bg-amber-100 text-amber-600'
                          }`}
                        >
                          <i
                            className={`${
                              notice.type === 'update'
                                ? 'ri-notification-3-line'
                                : notice.type === 'permission'
                                ? 'ri-shield-check-line'
                                : 'ri-tools-line'
                            } text-lg w-5 h-5 flex items-center justify-center`}
                          ></i>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-sm font-semibold text-gray-900 mb-1">{notice.title}</h4>
                          <p className="text-sm text-gray-600 mb-2">{notice.content}</p>
                          <div className="text-xs text-gray-400">{notice.time}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'rules' && (
              <div className="max-w-4xl space-y-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-base font-semibold text-gray-900 mb-1">自定义提醒规则</h3>
                    <p className="text-sm text-gray-500">创建个性化的客户跟进提醒规则</p>
                  </div>
                  <Button type="primary" icon="ri-add-line">
                    新建规则
                  </Button>
                </div>

                <div className="space-y-3">
                  {customRules.map((rule) => (
                    <div
                      key={rule.id}
                      className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-all"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="text-sm font-semibold text-gray-900">{rule.name}</h4>
                            <StatusTag type="success" label="已启用" icon="ri-checkbox-circle-line" />
                          </div>
                          <div className="space-y-1.5 text-sm text-gray-600 mb-3">
                            <div className="flex items-center gap-2">
                              <i className="ri-checkbox-line w-4 h-4 flex items-center justify-center text-gray-400"></i>
                              <span>触发条件：{rule.condition}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <i className="ri-notification-3-line w-4 h-4 flex items-center justify-center text-gray-400"></i>
                              <span>执行动作：{rule.action}</span>
                            </div>
                          </div>
                          <div className="text-xs text-gray-400">创建时间：{rule.createTime}</div>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Button type="text" size="small" icon="ri-edit-line">
                            编辑
                          </Button>
                          <Button type="text" size="small" icon="ri-delete-bin-line">
                            删除
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* 规则说明 */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-5">
                  <div className="flex items-start gap-3">
                    <div className="w-5 h-5 flex items-center justify-center text-blue-600 flex-shrink-0 mt-0.5">
                      <i className="ri-information-line text-lg w-5 h-5 flex items-center justify-center"></i>
                    </div>
                    <div className="flex-1 text-sm text-blue-900 leading-relaxed">
                      <p><strong>提醒规则说明：</strong></p>
                      <p>• 自定义规则仅影响您个人的提醒设置</p>
                      <p>• 规则不会自动触发任何业务操作</p>
                      <p>• 提醒仅用于服务管理参考，不构成业务指令</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
