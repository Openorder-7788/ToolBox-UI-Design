import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import StatusTag from '../../components/common/StatusTag';
import {
  customerRecommendationsData,
  conversionStatusOptions,
  followUpPriorityOptions,
  conversionFunnelData,
} from '../../mocks/advisoryRecommendations';

export default function AdvisoryRecommendations() {
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedPriority, setSelectedPriority] = useState('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);

  // 筛选客户推荐
  const filteredRecommendations = customerRecommendationsData.filter((rec) => {
    const priorityMatch = selectedPriority === 'all' || rec.followUpPriority === selectedPriority;
    const statusMatch =
      selectedStatus === 'all' ||
      rec.recommendedProducts.some((p) => p.conversionStatus === selectedStatus);
    const keywordMatch =
      searchKeyword === '' || rec.customerName.includes(searchKeyword) || rec.tags.some((tag) => tag.includes(searchKeyword));

    return priorityMatch && statusMatch && keywordMatch;
  });

  // 客户推荐详情弹窗
  const CustomerDetailModal = () => {
    if (!selectedCustomer) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
        <div className="bg-white rounded-lg w-full max-w-5xl max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">客户推荐详情</h3>
            <button
              onClick={() => setSelectedCustomer(null)}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-close-line text-xl w-5 h-5 flex items-center justify-center"></i>
            </button>
          </div>
          <div className="p-6 space-y-6">
            {/* 客户基本信息 */}
            <div className="p-5 bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-medium">
                  {selectedCustomer.customerName.charAt(0)}
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-bold text-gray-900 mb-2">{selectedCustomer.customerName}</h4>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-sm text-gray-600">客户编号: {selectedCustomer.customerId}</span>
                    <span className="text-sm text-gray-600">风险等级: {selectedCustomer.riskLevel}</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {selectedCustomer.tags.map((tag: string, index: number) => (
                      <span key={index} className="px-2 py-1 bg-blue-600 text-white text-xs rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* 推荐产品 */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h5 className="text-base font-semibold text-gray-900">推荐产品</h5>
                <span className="text-sm text-gray-500">{selectedCustomer.recommendedProducts.length} 个产品</span>
              </div>
              <div className="space-y-3">
                {selectedCustomer.recommendedProducts.map((product: any) => (
                  <div key={product.productId} className="border border-gray-200 rounded-lg p-4 bg-white">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h6 className="text-base font-medium text-gray-900 mb-1">{product.productName}</h6>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-500">产品编号: {product.productId}</span>
                          <StatusTag
                            type={
                              product.conversionStatus === '已购买'
                                ? 'success'
                                : product.conversionStatus === '已加入购物车'
                                ? 'warning'
                                : product.conversionStatus === '已浏览'
                                ? 'info'
                                : 'default'
                            }
                            label={product.conversionStatus}
                          />
                        </div>
                      </div>
                      <div className="px-3 py-1 bg-green-50 text-green-600 text-sm font-medium rounded-lg">
                        匹配度 {product.matchScore}%
                      </div>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg mb-3">
                      <div className="text-xs text-gray-500 mb-1">推荐理由</div>
                      <div className="text-sm text-gray-700 leading-relaxed">{product.matchReason}</div>
                    </div>
                    {product.lastViewTime && (
                      <div className="text-xs text-gray-500">
                        <i className="ri-time-line w-3.5 h-3.5 flex items-center justify-center inline-flex mr-1"></i>
                        最近浏览: {product.lastViewTime}
                      </div>
                    )}
                    {product.purchaseTime && (
                      <div className="text-xs text-green-600">
                        <i className="ri-check-line w-3.5 h-3.5 flex items-center justify-center inline-flex mr-1"></i>
                        购买时间: {product.purchaseTime}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 推荐活动 */}
            {selectedCustomer.recommendedActivities && selectedCustomer.recommendedActivities.length > 0 && (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <h5 className="text-base font-semibold text-gray-900">推荐活动</h5>
                  <span className="text-sm text-gray-500">{selectedCustomer.recommendedActivities.length} 个活动</span>
                </div>
                <div className="space-y-3">
                  {selectedCustomer.recommendedActivities.map((activity: any) => (
                    <div key={activity.activityId} className="border border-gray-200 rounded-lg p-4 bg-white">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h6 className="text-base font-medium text-gray-900 mb-1">{activity.activityName}</h6>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-gray-500">活动编号: {activity.activityId}</span>
                            <StatusTag
                              type={
                                activity.inviteStatus === '已报名'
                                  ? 'success'
                                  : activity.inviteStatus === '已邀约'
                                  ? 'warning'
                                  : 'default'
                              }
                              label={activity.inviteStatus}
                            />
                          </div>
                        </div>
                        <div className="px-3 py-1 bg-green-50 text-green-600 text-sm font-medium rounded-lg">
                          匹配度 {activity.matchScore}%
                        </div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg mb-3">
                        <div className="text-xs text-gray-500 mb-1">推荐理由</div>
                        <div className="text-sm text-gray-700 leading-relaxed">{activity.matchReason}</div>
                      </div>
                      {activity.inviteTime && (
                        <div className="text-xs text-gray-500">
                          <i className="ri-calendar-line w-3.5 h-3.5 flex items-center justify-center inline-flex mr-1"></i>
                          邀约时间: {activity.inviteTime}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 跟进建议 */}
            <div
              className={`p-4 rounded-lg border ${
                selectedCustomer.followUpPriority === 'high'
                  ? 'bg-red-50 border-red-200'
                  : selectedCustomer.followUpPriority === 'medium'
                  ? 'bg-amber-50 border-amber-200'
                  : 'bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex items-start gap-3">
                <i
                  className={`ri-information-line w-5 h-5 flex items-center justify-center mt-0.5 ${
                    selectedCustomer.followUpPriority === 'high'
                      ? 'text-red-600'
                      : selectedCustomer.followUpPriority === 'medium'
                      ? 'text-amber-600'
                      : 'text-gray-600'
                  }`}
                ></i>
                <div className="flex-1">
                  <div
                    className={`text-sm font-medium mb-1 ${
                      selectedCustomer.followUpPriority === 'high'
                        ? 'text-red-900'
                        : selectedCustomer.followUpPriority === 'medium'
                        ? 'text-amber-900'
                        : 'text-gray-900'
                    }`}
                  >
                    跟进建议 ({selectedCustomer.followUpPriority === 'high' ? '高优先级' : selectedCustomer.followUpPriority === 'medium' ? '中优先级' : '低优先级'})
                  </div>
                  <div
                    className={`text-sm leading-relaxed ${
                      selectedCustomer.followUpPriority === 'high'
                        ? 'text-red-700'
                        : selectedCustomer.followUpPriority === 'medium'
                        ? 'text-amber-700'
                        : 'text-gray-700'
                    }`}
                  >
                    {selectedCustomer.followUpSuggestion}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex items-center justify-end gap-3">
            <Button type="default" onClick={() => setSelectedCustomer(null)}>
              关闭
            </Button>
            <Button type="default" icon="ri-phone-line">
              联系客户
            </Button>
            <Button type="primary" icon="ri-edit-line">
              创建跟进任务
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <MainLayout>
      <PageHeader
        title="个性化推荐中心"
        description="基于客户画像的智能推荐与转化状态跟进"
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line" size="small">
              导出推荐数据
            </Button>
            <Button type="primary" icon="ri-refresh-line">
              刷新推荐
            </Button>
          </div>
        }
      />

      <div className="p-6 space-y-6">
        {/* 转化漏斗 */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-5">产品转化漏斗</h3>
          <div className="space-y-4">
            {conversionFunnelData.map((stage, index) => (
              <div key={index}>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">{stage.stage}</span>
                  <span className="font-medium text-gray-900">
                    {stage.count} 人 ({stage.percentage}%)
                  </span>
                </div>
                <div className="w-full h-8 bg-gray-100 rounded-lg overflow-hidden">
                  <div
                    className={`h-full rounded-lg transition-all flex items-center justify-end pr-3 text-white text-sm font-medium ${
                      index === 0
                        ? 'bg-gradient-to-r from-blue-400 to-blue-500'
                        : index === 1
                        ? 'bg-gradient-to-r from-blue-500 to-blue-600'
                        : index === 2
                        ? 'bg-gradient-to-r from-blue-600 to-blue-700'
                        : 'bg-gradient-to-r from-green-500 to-green-600'
                    }`}
                    style={{ width: `${stage.percentage}%` }}
                  >
                    {stage.percentage >= 20 && `${stage.count} 人`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 客户推荐列表 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* 筛选区域 */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="relative">
                  <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 flex items-center justify-center"></i>
                  <input
                    type="text"
                    placeholder="搜索客户姓名或标签..."
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
              >
                {conversionStatusOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <select
                value={selectedPriority}
                onChange={(e) => setSelectedPriority(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
              >
                {followUpPriorityOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 列表 */}
          <div className="p-6">
            <div className="mb-4 text-sm text-gray-500">
              共 <span className="font-medium text-gray-900">{filteredRecommendations.length}</span> 个客户有推荐
            </div>
            <div className="space-y-4">
              {filteredRecommendations.map((rec) => (
                <div
                  key={rec.customerId}
                  className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-all bg-gradient-to-br from-white to-gray-50"
                >
                  <div className="flex items-start gap-4">
                    {/* 客户头像 */}
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-lg font-medium flex-shrink-0">
                      {rec.customerName.charAt(0)}
                    </div>

                    {/* 客户信息 */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="text-base font-semibold text-gray-900 mb-1">{rec.customerName}</h4>
                          <div className="flex items-center gap-3 text-sm text-gray-500 mb-2">
                            <span>{rec.customerId}</span>
                            <span>{rec.riskLevel}</span>
                          </div>
                          <div className="flex flex-wrap gap-1.5">
                            {rec.tags.map((tag, index) => (
                              <span key={index} className="px-2 py-0.5 bg-blue-50 text-blue-600 text-xs rounded">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </div>
                        <StatusTag
                          type={
                            rec.followUpPriority === 'high'
                              ? 'error'
                              : rec.followUpPriority === 'medium'
                              ? 'warning'
                              : 'default'
                          }
                          label={
                            rec.followUpPriority === 'high'
                              ? '高优先级'
                              : rec.followUpPriority === 'medium'
                              ? '中优先级'
                              : '低优先级'
                          }
                        />
                      </div>

                      {/* 推荐产品概览 */}
                      <div className="mb-3">
                        <div className="text-sm text-gray-500 mb-2">推荐产品 ({rec.recommendedProducts.length})</div>
                        <div className="space-y-2">
                          {rec.recommendedProducts.map((product) => (
                            <div
                              key={product.productId}
                              className="flex items-center justify-between p-2 bg-gray-50 rounded text-sm"
                            >
                              <span className="text-gray-700">{product.productName}</span>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-green-600 font-medium">匹配 {product.matchScore}%</span>
                                <StatusTag
                                  type={
                                    product.conversionStatus === '已购买'
                                      ? 'success'
                                      : product.conversionStatus === '已加入购物车'
                                      ? 'warning'
                                      : product.conversionStatus === '已浏览'
                                      ? 'info'
                                      : 'default'
                                  }
                                  label={product.conversionStatus}
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* 跟进建议 */}
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg mb-3">
                        <div className="text-xs text-amber-900 font-medium mb-1">跟进建议</div>
                        <div className="text-sm text-amber-700 leading-relaxed">{rec.followUpSuggestion}</div>
                      </div>

                      {/* 操作按钮 */}
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setSelectedCustomer(rec)}
                          className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
                        >
                          查看详情
                        </button>
                        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                          创建跟进任务
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 客户详情弹窗 */}
      <CustomerDetailModal />
    </MainLayout>
  );
}
