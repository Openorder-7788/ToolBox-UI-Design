// 合规风控数据模型

// 风险类型定义
export const riskTypes = [
  { id: 'promise-return', name: '承诺收益类风险话术', color: 'red', count: 15 },
  { id: 'over-scope', name: '超范围投顾建议', color: 'orange', count: 8 },
  { id: 'no-contract', name: '未签约即提供投顾内容', color: 'yellow', count: 12 },
  { id: 'non-compliant-product', name: '未合规产品推荐', color: 'purple', count: 5 },
];

// 高风险人员列表
export const highRiskPersonnel = [
  {
    id: 'M001',
    name: '张伟',
    team: '华东一区',
    supervisor: '李明',
    riskType: '承诺收益类风险话术',
    riskLevel: 'high',
    riskCount: 5,
    lastRiskTime: '2024-01-15 14:30',
    riskDetail: '在与客户沟通中使用"保证年化收益15%"等表述',
  },
  {
    id: 'M003',
    name: '王芳',
    team: '华东一区',
    supervisor: '李明',
    riskType: '未签约即提供投顾内容',
    riskLevel: 'high',
    riskCount: 4,
    lastRiskTime: '2024-01-15 11:20',
    riskDetail: '向未签署投顾服务协议的客户推荐具体投资组合',
  },
  {
    id: 'M005',
    name: '刘强',
    team: '华南二区',
    supervisor: '赵敏',
    riskType: '超范围投顾建议',
    riskLevel: 'medium',
    riskCount: 3,
    lastRiskTime: '2024-01-15 09:45',
    riskDetail: '向保守型客户推荐高风险衍生品',
  },
  {
    id: 'M007',
    name: '陈静',
    team: '华北三区',
    supervisor: '周杰',
    riskType: '承诺收益类风险话术',
    riskLevel: 'high',
    riskCount: 6,
    lastRiskTime: '2024-01-14 16:50',
    riskDetail: '使用"稳赚不赔""保本保息"等违规表述',
  },
  {
    id: 'M009',
    name: '杨洋',
    team: '华南二区',
    supervisor: '赵敏',
    riskType: '未合规产品推荐',
    riskLevel: 'medium',
    riskCount: 2,
    lastRiskTime: '2024-01-14 14:15',
    riskDetail: '推荐未经合规审核的第三方产品',
  },
  {
    id: 'M011',
    name: '黄磊',
    team: '华东一区',
    supervisor: '李明',
    riskType: '超范围投顾建议',
    riskLevel: 'medium',
    riskCount: 3,
    lastRiskTime: '2024-01-14 10:30',
    riskDetail: '向客户提供超出其风险承受能力的投资建议',
  },
  {
    id: 'M013',
    name: '赵雪',
    team: '华北三区',
    supervisor: '周杰',
    riskType: '未签约即提供投顾内容',
    riskLevel: 'high',
    riskCount: 5,
    lastRiskTime: '2024-01-13 15:40',
    riskDetail: '在客户未完成投顾服务签约前提供详细投资策略',
  },
  {
    id: 'M015',
    name: '孙涛',
    team: '华南二区',
    supervisor: '赵敏',
    riskType: '承诺收益类风险话术',
    riskLevel: 'low',
    riskCount: 1,
    lastRiskTime: '2024-01-13 11:25',
    riskDetail: '使用"预期收益"表述时未充分说明风险',
  },
];

// 待审核内容列表
export const pendingReviewContent = [
  {
    id: 'R001',
    type: '话术内容',
    submitter: '张伟',
    submitTime: '2024-01-15 14:00',
    content: '新增智能投顾话术模板',
    status: 'pending',
  },
  {
    id: 'R002',
    type: '营销素材',
    submitter: '王芳',
    submitTime: '2024-01-15 10:30',
    content: '基金定投宣传海报',
    status: 'pending',
  },
  {
    id: 'R003',
    type: '产品介绍',
    submitter: '刘强',
    submitTime: '2024-01-14 16:20',
    content: '新产品服务说明书',
    status: 'pending',
  },
];

// 已处理违规事件
export const processedViolations = [
  {
    id: 'V001',
    personnel: '李华',
    violationType: '承诺收益',
    processTime: '2024-01-14 18:00',
    result: '警告处理',
    handler: '合规部-王经理',
  },
  {
    id: 'V002',
    personnel: '周明',
    violationType: '超范围建议',
    processTime: '2024-01-13 15:30',
    result: '培训整改',
    handler: '合规部-张主管',
  },
  {
    id: 'V003',
    personnel: '钱多多',
    violationType: '未签约服务',
    processTime: '2024-01-12 14:20',
    result: '严重警告',
    handler: '合规部-王经理',
  },
];

// 风险趋势数据（最近7天）
export const riskTrendData = [
  { date: '01-09', count: 8 },
  { date: '01-10', count: 12 },
  { date: '01-11', count: 10 },
  { date: '01-12', count: 15 },
  { date: '01-13', count: 18 },
  { date: '01-14', count: 14 },
  { date: '01-15', count: 20 },
];
