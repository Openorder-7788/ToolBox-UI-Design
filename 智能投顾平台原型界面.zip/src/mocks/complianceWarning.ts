// 违规类型
export const violationTypes = [
  { id: 'promise-return', name: '承诺收益类' },
  { id: 'beyond-scope', name: '超范围投顾' },
  { id: 'no-contract', name: '未签约提供投顾' },
  { id: 'improper-product', name: '不当产品推荐' },
  { id: 'insider-info', name: '内幕信息传播' },
  { id: 'misleading', name: '误导性陈述' },
];

// 违规等级
export const violationLevels = [
  { id: 'high', name: '严重违规' },
  { id: 'medium', name: '一般违规' },
  { id: 'low', name: '轻微违规' },
];

// 处理状态
export const processingStatuses = [
  { id: 'pending', name: '待处理' },
  { id: 'notified', name: '已通知' },
  { id: 'rectifying', name: '整改中' },
  { id: 'reviewing', name: '复查中' },
  { id: 'completed', name: '已完成' },
];

// 违规事件列表
export const violationEvents = [
  {
    id: 'V001',
    violator: '张伟',
    team: '华东一区',
    supervisor: '李明',
    violationType: 'promise-return',
    violationTypeName: '承诺收益类',
    violationLevel: 'high',
    status: 'pending',
    occurredAt: '2024-01-15 14:30',
    historyCount: 2,
    content: `客户经理：王先生，这款产品非常稳健，年化收益可以保证在8%以上。

客户：真的能保证吗？

客户经理：当然可以，我们公司的产品一向稳赚不赔，您完全可以放心投资。这个收益率是有保障的，绝对不会亏损。`,
    violatedRules: [
      {
        ruleName: '禁止收益承诺',
        description: '不得对客户承诺投资收益或保证本金安全，包括但不限于"保证收益"、"稳赚不赔"等表述。',
      },
      {
        ruleName: '风险提示不充分',
        description: '在介绍产品时必须充分提示投资风险，不得片面强调收益而忽略风险。',
      },
    ],
    historyRecords: [
      {
        violationType: '承诺收益类',
        date: '2023-12-10',
        status: 'completed',
      },
      {
        violationType: '风险提示不充分',
        date: '2023-11-05',
        status: 'completed',
      },
    ],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-15 15:00',
        operator: '合规专员-王芳',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '待发送预警',
        description: '等待向客户经理和主管发送预警通知',
        time: '',
        operator: '',
        icon: 'ri-notification-3-line',
        completed: false,
      },
      {
        status: '整改中',
        description: '客户经理进行整改学习',
        time: '',
        operator: '',
        icon: 'ri-tools-line',
        completed: false,
      },
      {
        status: '复查通过',
        description: '合规人员复查整改结果',
        time: '',
        operator: '',
        icon: 'ri-checkbox-circle-line',
        completed: false,
      },
    ],
  },
  {
    id: 'V002',
    violator: '李娜',
    team: '华南二区',
    supervisor: '赵强',
    violationType: 'no-contract',
    violationTypeName: '未签约提供投顾',
    violationLevel: 'high',
    status: 'notified',
    occurredAt: '2024-01-15 10:20',
    historyCount: 0,
    content: `客户：李经理，我最近想投资股票，有什么推荐吗？

客户经理：根据您的情况，我建议您重点关注新能源板块，特别是比亚迪和宁德时代这两只股票。现在正是入场的好时机，建议您可以分批建仓。

客户：好的，那我应该怎么操作呢？

客户经理：您可以先买入30%的仓位，如果后续回调再加仓。目标价位我建议设在比亚迪280元，宁德时代600元。`,
    violatedRules: [
      {
        ruleName: '投顾服务需签约',
        description: '提供具体投资建议前，必须确认客户已签署投资顾问服务协议。未签约不得提供具体股票推荐、买卖时机等投顾服务。',
      },
      {
        ruleName: '禁止未授权投顾',
        description: '未取得投资顾问资格或未在授权范围内，不得向客户提供投资建议。',
      },
    ],
    historyRecords: [],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-15 11:00',
        operator: '合规专员-王芳',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '已发送预警',
        description: '已向客户经理和主管发送预警通知',
        time: '2024-01-15 11:30',
        operator: '合规专员-王芳',
        icon: 'ri-notification-3-line',
        completed: true,
      },
      {
        status: '整改中',
        description: '客户经理正在进行整改学习',
        time: '',
        operator: '',
        icon: 'ri-tools-line',
        completed: false,
      },
      {
        status: '复查通过',
        description: '合规人员复查整改结果',
        time: '',
        operator: '',
        icon: 'ri-checkbox-circle-line',
        completed: false,
      },
    ],
  },
  {
    id: 'V003',
    violator: '王强',
    team: '华北三区',
    supervisor: '孙丽',
    violationType: 'insider-info',
    violationTypeName: '内幕信息传播',
    violationLevel: 'high',
    status: 'rectifying',
    occurredAt: '2024-01-14 16:45',
    historyCount: 1,
    content: `客户经理：刘总，我这边有个独家消息，某上市公司下周要发布重大利好公告，现在股价还没涨，是个很好的机会。

客户：什么公司？

客户经理：具体名字我不方便在这里说，但消息绝对可靠，是内部渠道得来的。您如果感兴趣，我们可以线下详聊。`,
    violatedRules: [
      {
        ruleName: '禁止传播内幕信息',
        description: '严禁传播、使用或建议他人使用内幕信息进行证券交易。不得以"独家消息"、"内部消息"等名义诱导客户交易。',
      },
      {
        ruleName: '信息来源合规性',
        description: '向客户提供的信息必须来源合法、公开，不得使用未经证实或来源不明的信息。',
      },
    ],
    historyRecords: [
      {
        violationType: '误导性陈述',
        date: '2023-10-20',
        status: 'completed',
      },
    ],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-14 17:00',
        operator: '合规专员-张华',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '已发送预警',
        description: '已向客户经理和主管发送预警通知',
        time: '2024-01-14 17:30',
        operator: '合规专员-张华',
        icon: 'ri-notification-3-line',
        completed: true,
      },
      {
        status: '整改中',
        description: '客户经理正在进行整改学习，要求3日内完成',
        time: '2024-01-14 18:00',
        operator: '合规专员-张华',
        icon: 'ri-tools-line',
        completed: true,
      },
      {
        status: '复查通过',
        description: '合规人员复查整改结果',
        time: '',
        operator: '',
        icon: 'ri-checkbox-circle-line',
        completed: false,
      },
    ],
  },
  {
    id: 'V004',
    violator: '陈静',
    team: '华东一区',
    supervisor: '李明',
    violationType: 'misleading',
    violationTypeName: '误导性陈述',
    violationLevel: 'medium',
    status: 'reviewing',
    occurredAt: '2024-01-14 09:15',
    historyCount: 0,
    content: `客户经理：张女士，这款基金过去三年的年化收益率都在15%以上，表现非常优秀。

客户：那未来也能保持这个收益吗？

客户经理：从历史数据来看，这款基金一直表现稳定，未来继续保持高收益的可能性很大。而且基金经理经验丰富，您可以放心投资。`,
    violatedRules: [
      {
        ruleName: '禁止误导性陈述',
        description: '不得使用历史业绩暗示或保证未来收益。在介绍产品时必须明确说明"过往业绩不代表未来表现"。',
      },
    ],
    historyRecords: [],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-14 10:00',
        operator: '合规专员-王芳',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '已发送预警',
        description: '已向客户经理和主管发送预警通知',
        time: '2024-01-14 10:30',
        operator: '合规专员-王芳',
        icon: 'ri-notification-3-line',
        completed: true,
      },
      {
        status: '整改完成',
        description: '客户经理已完成整改学习',
        time: '2024-01-15 09:00',
        operator: '客户经理-陈静',
        icon: 'ri-tools-line',
        completed: true,
      },
      {
        status: '复查中',
        description: '合规人员正在复查整改结果',
        time: '2024-01-15 14:00',
        operator: '合规专员-王芳',
        icon: 'ri-checkbox-circle-line',
        completed: true,
      },
    ],
  },
  {
    id: 'V005',
    violator: '刘洋',
    team: '华南二区',
    supervisor: '赵强',
    violationType: 'improper-product',
    violationTypeName: '不当产品推荐',
    violationLevel: 'medium',
    status: 'completed',
    occurredAt: '2024-01-13 14:20',
    historyCount: 0,
    content: `客户：刘经理，我是保守型投资者，有什么产品推荐吗？

客户经理：我建议您可以考虑这款股票型基金，虽然风险稍高，但收益也更好。您年轻，完全可以承受这个风险。

客户：但我的风险测评结果是保守型啊。

客户经理：那个测评结果不用太在意，很多客户都是这样，实际上您的承受能力比测评结果要强。`,
    violatedRules: [
      {
        ruleName: '适当性管理要求',
        description: '必须严格遵守投资者适当性管理要求，不得向客户推荐超出其风险承受能力的产品。',
      },
    ],
    historyRecords: [],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-13 15:00',
        operator: '合规专员-张华',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '已发送预警',
        description: '已向客户经理和主管发送预警通知',
        time: '2024-01-13 15:30',
        operator: '合规专员-张华',
        icon: 'ri-notification-3-line',
        completed: true,
      },
      {
        status: '整改完成',
        description: '客户经理已完成整改学习',
        time: '2024-01-14 10:00',
        operator: '客户经理-刘洋',
        icon: 'ri-tools-line',
        completed: true,
      },
      {
        status: '复查通过',
        description: '合规人员复查通过，事件处理完成',
        time: '2024-01-14 16:00',
        operator: '合规专员-张华',
        icon: 'ri-checkbox-circle-line',
        completed: true,
      },
    ],
  },
  {
    id: 'V006',
    violator: '周敏',
    team: '华北三区',
    supervisor: '孙丽',
    violationType: 'beyond-scope',
    violationTypeName: '超范围投顾',
    violationLevel: 'medium',
    status: 'pending',
    occurredAt: '2024-01-15 11:30',
    historyCount: 1,
    content: `客户：周经理，我想了解一下房地产投资的机会。

客户经理：房地产方面，我建议您可以关注一线城市的核心地段，现在政策有所放松，是个不错的投资时机。您可以考虑在深圳或上海购置一套投资性房产。

客户：具体应该怎么操作呢？

客户经理：我可以帮您联系一些靠谱的房产中介，他们有很多优质房源。`,
    violatedRules: [
      {
        ruleName: '业务范围限制',
        description: '客户经理只能在授权的业务范围内提供服务，不得超范围提供房地产、保险等非证券类投资建议。',
      },
    ],
    historyRecords: [
      {
        violationType: '超范围投顾',
        date: '2023-09-15',
        status: 'completed',
      },
    ],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-15 12:00',
        operator: '合规专员-王芳',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '待发送预警',
        description: '等待向客户经理和主管发送预警通知',
        time: '',
        operator: '',
        icon: 'ri-notification-3-line',
        completed: false,
      },
      {
        status: '整改中',
        description: '客户经理进行整改学习',
        time: '',
        operator: '',
        icon: 'ri-tools-line',
        completed: false,
      },
      {
        status: '复查通过',
        description: '合规人员复查整改结果',
        time: '',
        operator: '',
        icon: 'ri-checkbox-circle-line',
        completed: false,
      },
    ],
  },
  {
    id: 'V007',
    violator: '吴涛',
    team: '华东一区',
    supervisor: '李明',
    violationType: 'promise-return',
    violationTypeName: '承诺收益类',
    violationLevel: 'low',
    status: 'notified',
    occurredAt: '2024-01-15 08:45',
    historyCount: 0,
    content: `客户经理：这款理财产品的预期收益率是5.5%，历史上从未出现过亏损的情况。

客户：那是不是可以理解为基本不会亏？

客户经理：从历史数据来看确实是这样的，产品非常稳健。`,
    violatedRules: [
      {
        ruleName: '风险提示充分性',
        description: '在介绍产品时必须充分提示风险，不得使用"从未亏损"等暗示保本的表述。',
      },
    ],
    historyRecords: [],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-15 09:30',
        operator: '合规专员-张华',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '已发送预警',
        description: '已向客户经理发送提醒通知',
        time: '2024-01-15 10:00',
        operator: '合规专员-张华',
        icon: 'ri-notification-3-line',
        completed: true,
      },
      {
        status: '整改中',
        description: '客户经理正在进行整改学习',
        time: '',
        operator: '',
        icon: 'ri-tools-line',
        completed: false,
      },
      {
        status: '复查通过',
        description: '合规人员复查整改结果',
        time: '',
        operator: '',
        icon: 'ri-checkbox-circle-line',
        completed: false,
      },
    ],
  },
  {
    id: 'V008',
    violator: '郑雪',
    team: '华南二区',
    supervisor: '赵强',
    violationType: 'misleading',
    violationTypeName: '误导性陈述',
    violationLevel: 'low',
    status: 'completed',
    occurredAt: '2024-01-12 16:30',
    historyCount: 0,
    content: `客户经理：这只股票最近表现很好，连续上涨了5天，技术形态非常漂亮，后市看涨。

客户：那我现在买入合适吗？

客户经理：从技术面来看，现在是个不错的买入时机。`,
    violatedRules: [
      {
        ruleName: '投资建议规范性',
        description: '提供投资建议时应保持客观中立，不得使用过于确定性的表述，必须提示投资风险。',
      },
    ],
    historyRecords: [],
    processingTimeline: [
      {
        status: '违规事件确认',
        description: 'AI系统检测到违规内容，合规人员已确认',
        time: '2024-01-12 17:00',
        operator: '合规专员-王芳',
        icon: 'ri-alert-line',
        completed: true,
      },
      {
        status: '已发送预警',
        description: '已向客户经理发送提醒通知',
        time: '2024-01-12 17:30',
        operator: '合规专员-王芳',
        icon: 'ri-notification-3-line',
        completed: true,
      },
      {
        status: '整改完成',
        description: '客户经理已完成整改学习',
        time: '2024-01-13 10:00',
        operator: '客户经理-郑雪',
        icon: 'ri-tools-line',
        completed: true,
      },
      {
        status: '复查通过',
        description: '合规人员复查通过，事件处理完成',
        time: '2024-01-13 15:00',
        operator: '合规专员-王芳',
        icon: 'ri-checkbox-circle-line',
        completed: true,
      },
    ],
  },
];
