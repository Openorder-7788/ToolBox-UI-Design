import type { RouteObject } from "react-router-dom";
import { lazy, Suspense } from "react";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import Customers from "../pages/customers/page";
import Service from "../pages/service/page";
import ScriptsLibrary from "../pages/scripts/page";
import AITrainingLibrary from "../pages/training/page";

// Lazy load components with Suspense wrapper
const LazyAdvisoryProducts = lazy(() => import("../pages/advisory-products/page"));
const LazyAdvisoryContent = lazy(() => import("../pages/advisory-content/page"));
const LazyAdvisoryActivities = lazy(() => import("../pages/advisory-activities/page"));
const LazyAdvisoryRecommendations = lazy(() => import("../pages/advisory-recommendations/page"));
const LazyContentMarketing = lazy(() => import("../pages/content-marketing/page"));

// Lazy load follow-up pages
const LazyFollowUpOpenAccount = lazy(() => import("../pages/follow-up/open-account/page"));
const LazyFollowUpOpenAccountDetail = lazy(() => import("../pages/follow-up/open-account/[id]/page"));
const LazyFollowUpHighValue = lazy(() => import("../pages/follow-up/high-value/page"));
const LazyFollowUpHighValueDetail = lazy(() => import("../pages/follow-up/high-value/[id]/page"));
const LazyFollowUpBehavior = lazy(() => import("../pages/follow-up/behavior/page"));
const LazyFollowUpBehaviorDetail = lazy(() => import("../pages/follow-up/behavior/[id]/page"));
const LazyFollowUpSleeping = lazy(() => import("../pages/follow-up/sleeping/page"));
const LazyFollowUpSleepingDetail = lazy(() => import("../pages/follow-up/sleeping/[id]/page"));

// Lazy load settings pages
const LazySettings = lazy(() => import("../pages/settings/page"));
const LazyAccountSettings = lazy(() => import("../pages/settings/account/page"));
const LazyRoleConfig = lazy(() => import("../pages/settings/account/role-config/page"));
const LazyOperationLogs = lazy(() => import("../pages/settings/account/operation-logs/page"));
const LazyPersonalSettings = lazy(() => import("../pages/settings/personal/page"));
const LazyNotificationSettings = lazy(() => import("../pages/settings/notification/page"));

// Lazy load customer detail page
const LazyCustomerDetail = lazy(() => import("../pages/customers/[id]/page"));

// Lazy load WeChat sidebar page
const LazyWeChatSidebarCustomerInfo = lazy(() => import("../pages/wechat-sidebar/customer-info/page"));

// Lazy load supervisor pages
const LazySupervisorDashboard = lazy(() => import("../pages/supervisor/dashboard/page"));
const LazySupervisorMemberDetail = lazy(() => import("../pages/supervisor/member/[id]/page"));
const LazySupervisorTasks = lazy(() => import("../pages/supervisor/tasks/page"));
const LazySupervisorTasksCreate = lazy(() => import("../pages/supervisor/tasks/create/page"));

// Lazy load compliance pages
const LazyComplianceDashboard = lazy(() => import("../pages/compliance/dashboard/page"));
const LazyComplianceReview = lazy(() => import("../pages/compliance/review/page"));
const LazyComplianceWarning = lazy(() => import("../pages/compliance/warning/page"));
const LazyComplianceRules = lazy(() => import("../pages/compliance/rules/page"));

const routes: RouteObject[] = [
  {
    path: "/",
    element: <Home />,
  },
  {
    path: "/customers",
    element: <Customers />,
  },
  {
    path: "/customers/:id",
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyCustomerDetail />
      </Suspense>
    ),
  },
  {
    path: "/service",
    element: <Service />,
  },
  {
    path: "/scripts",
    element: <ScriptsLibrary />,
  },
  {
    path: "/training",
    element: <AITrainingLibrary />,
  },
  {
    path: "/advisory-products",
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyAdvisoryProducts />
      </Suspense>
    ),
  },
  {
    path: "/advisory-content",
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyAdvisoryContent />
      </Suspense>
    ),
  },
  {
    path: "/advisory-activities",
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyAdvisoryActivities />
      </Suspense>
    ),
  },
  {
    path: "/advisory-recommendations",
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyAdvisoryRecommendations />
      </Suspense>
    ),
  },
  {
    path: "/content-marketing",
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyContentMarketing />
      </Suspense>
    ),
  },
  // 客户跟进模块路由
  {
    path: '/follow-up/open-account',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpOpenAccount />
      </Suspense>
    ),
  },
  {
    path: '/follow-up/open-account/:id',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpOpenAccountDetail />
      </Suspense>
    ),
  },
  {
    path: '/follow-up/high-value',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpHighValue />
      </Suspense>
    ),
  },
  {
    path: '/follow-up/high-value/:id',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpHighValueDetail />
      </Suspense>
    ),
  },
  {
    path: '/follow-up/behavior',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpBehavior />
      </Suspense>
    ),
  },
  {
    path: '/follow-up/behavior/:id',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpBehaviorDetail />
      </Suspense>
    ),
  },
  {
    path: '/follow-up/sleeping',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpSleeping />
      </Suspense>
    ),
  },
  {
    path: '/follow-up/sleeping/:id',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyFollowUpSleepingDetail />
      </Suspense>
    ),
  },
  // 系统设置模块路由
  {
    path: '/settings',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazySettings />
      </Suspense>
    ),
  },
  {
    path: '/settings/account',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyAccountSettings />
      </Suspense>
    ),
  },
  {
    path: '/settings/account/role-config',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyRoleConfig />
      </Suspense>
    ),
  },
  {
    path: '/settings/account/operation-logs',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyOperationLogs />
      </Suspense>
    ),
  },
  {
    path: '/settings/personal',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyPersonalSettings />
      </Suspense>
    ),
  },
  {
    path: '/settings/notification',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyNotificationSettings />
      </Suspense>
    ),
  },
  // 企业微信侧边栏路由
  {
    path: '/wechat-sidebar/customer-info',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyWeChatSidebarCustomerInfo />
      </Suspense>
    ),
  },
  // 主管工作台路由
  {
    path: '/supervisor/dashboard',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazySupervisorDashboard />
      </Suspense>
    ),
  },
  {
    path: '/supervisor/member/:id',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazySupervisorMemberDetail />
      </Suspense>
    ),
  },
  {
    path: '/supervisor/tasks',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazySupervisorTasks />
      </Suspense>
    ),
  },
  {
    path: '/supervisor/tasks/create',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazySupervisorTasksCreate />
      </Suspense>
    ),
  },
  // 合规风控模块路由
  {
    path: '/compliance/dashboard',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyComplianceDashboard />
      </Suspense>
    ),
  },
  {
    path: '/compliance/review',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyComplianceReview />
      </Suspense>
    ),
  },
  {
    path: '/compliance/warning',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyComplianceWarning />
      </Suspense>
    ),
  },
  {
    path: '/compliance/rules',
    element: (
      <Suspense fallback={<div>加载中...</div>}>
        <LazyComplianceRules />
      </Suspense>
    ),
  },
  {
    path: "*",
    element: <NotFound />,
  },
];

export default routes;
