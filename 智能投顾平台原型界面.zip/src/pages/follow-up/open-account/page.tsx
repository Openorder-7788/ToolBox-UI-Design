
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';
import StatusTag from '../../../components/common/StatusTag';
import DataTable from '../../../components/common/DataTable';
import { openAccountCustomers } from '../../../mocks/followUpTasks';

export default function OpenAccountFollowUp() {
  const navigate = useNavigate();
  const [customers] = useState(openAccountCustomers);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [valueFilter, setValueFilter] = useState('all');
  const [riskFilter, setRiskFilter] = useState('all');

  // 筛选客户
  const filteredCustomers = customers.filter((customer) => {
    const matchKeyword =
      customer.name.includes(searchKeyword) ||
      customer.id.includes(searchKeyword);
    const matchValue = valueFilter === 'all' || customer.valueLevel === valueFilter;
    const matchRisk = riskFilter === 'all' || customer.riskLevel === riskFilter;
    return matchKeyword && matchValue && matchRisk;
  });

  const columns = [
    {
      key: 'customer',
      title: '客户信息',
      render: (_value: any, row: any) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-sm font-medium flex-shrink-0">
            {row.name.charAt(0)}
          </div>
          <div>
            <div className="text-sm font-semibold text-gray-900">{row.name}</div>
            <div className="text-xs text-gray-500">{row.id}</div>
          </div>
        </div>
      ),
    },
    {
      key: 'openDate',
      title: '开户时间',
      render: (_value: any, row: any) => (
        <div>
          <div className="text-sm text-gray-900">{row.openDate}</div>
          <div className="text-xs text-red-600 font-medium">{row.days} 天</div>
        </div>
      ),
    },
    {
      key: 'valueLevel',
      title: '客户价值等级',
      render: (_value: any, row: any) => (
        <StatusTag
          type={
            row.valueLevel === '高价值'
              ? 'success'
              : row.valueLevel === '中价值'
              ? 'warning'
              : 'default'
          }
          label={row.valueLevel}
        />
      ),
    },
    {
      key: 'riskLevel',
      title: '风险偏好',
      render: (_value: any, row: any) => <StatusTag type="info" label={row.riskLevel} />,
    },
    {
      key: 'followUpProgress',
      title: '跟进进度',
      render: (_value: any, row: any) => (
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
          <span className="text-sm text-gray-700">{row.stage}</span>
        </div>
      ),
    },
    {
      key: 'lastContact',
      title: '最近联系时间',
      render: (_value: any, row: any) => (
        <div className="text-sm text-gray-900">{row.lastContactTime || '2024-01-10'}</div>
      ),
    },
    {
      key: 'actions',
      title: '操作',
      render: (_value: any, row: any) => (
        <Button
          type="primary"
          size="small"
          onClick={() => navigate(`/follow-up/open-account/${row.id}`)}
        >
          查看详情
        </Button>
      ),
    },
  ];

  return (
    <MainLayout>
      <PageHeader
        title="开户后未转化客户"
        description="已完成开户但尚未使用投顾服务的客户"
        breadcrumbs={[
          { label: '首页', path: '/' },
          { label: '客户跟进', path: '/' },
          { label: '开户后未转化' },
        ]}
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line">
              导出列表
            </Button>
            <Button type="primary" icon="ri-refresh-line">
              刷新数据
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* 数据概览区 */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-500 mb-1">客户总数</div>
                <div className="text-3xl font-bold text-gray-900">{customers.length}</div>
              </div>
              <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                <i className="ri-user-line text-2xl text-blue-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-500 mb-1">平均开户时长</div>
                <div className="text-3xl font-bold text-gray-900">
                  8<span className="text-lg text-gray-500 ml-1">天</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                <i className="ri-calendar-line text-2xl text-green-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-500 mb-1">最近7天新增</div>
                <div className="text-3xl font-bold text-gray-900">
                  5<span className="text-lg text-gray-500 ml-1">人</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                <i className="ri-user-add-line text-2xl text-purple-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
        </div>

        <div className="text-xs text-gray-400 mb-6">数据仅用于服务管理参考</div>

        {/* 筛选与搜索区 */}
        <div className="bg-white border border-gray-200 rounded-lg p-4 mb-6">
          <div className="grid grid-cols-4 gap-4">
            {/* 关键词搜索 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                关键词搜索
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  placeholder="客户姓名 / 编号"
                  className="w-full pl-9 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4 flex items-center justify-center"></i>
              </div>
            </div>

            {/* 客户价值等级筛选 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                客户价值等级
              </label>
              <select
                value={valueFilter}
                onChange={(e) => setValueFilter(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white text-gray-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">全部等级</option>
                <option value="高价值">高价值</option>
                <option value="中价值">中价值</option>
                <option value="低价值">低价值</option>
              </select>
            </div>

            {/* 风险偏好筛选 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                风险偏好
              </label>
              <select
                value={riskFilter}
                onChange={(e) => setRiskFilter(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white text-gray-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">全部类型</option>
                <option value="保守型">保守型</option>
                <option value="稳健型">稳健型</option>
                <option value="平衡型">平衡型</option>
                <option value="积极型">积极型</option>
              </select>
            </div>

            {/* 开户时间区间筛选 */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                开户时间区间
              </label>
              <select className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg bg-white text-gray-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option>全部时间</option>
                <option>最近7天</option>
                <option>最近30天</option>
                <option>30天以上</option>
              </select>
            </div>
          </div>
        </div>

        {/* 客户列表区 */}
        <DataTable columns={columns} data={filteredCustomers} rowKey="id" />

        {/* 操作提示区 */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-blue-600 text-lg w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5"></i>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-900 mb-1">跟进提示</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• 建议优先跟进开户时间较久的客户</li>
                <li>• 所有服务推荐需在沟通后进行</li>
                <li>• 点击客户行可进入详情页查看完整信息</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
