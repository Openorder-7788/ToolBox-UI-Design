
interface InputProps {
  type?: 'text' | 'number' | 'email' | 'password' | 'tel';
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  disabled?: boolean;
  prefix?: string;
  suffix?: string;
  error?: boolean;
}

export default function Input({
  type = 'text',
  placeholder,
  value,
  onChange,
  disabled = false,
  prefix,
  suffix,
  error = false,
}: InputProps) {
  return (
    <div className="relative">
      {prefix && (
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
          <i className={`${prefix} w-4 h-4 flex items-center justify-center`}></i>
        </span>
      )}
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        disabled={disabled}
        className={`w-full px-3 py-2 text-sm text-gray-700 bg-white border rounded-md transition-colors ${
          prefix ? 'pl-9' : ''
        } ${suffix ? 'pr-9' : ''} ${
          error
            ? 'border-red-300 focus:border-red-500 focus:ring-red-500'
            : 'border-gray-300 focus:border-blue-500 focus:ring-blue-500'
        } ${disabled ? 'bg-gray-50 text-gray-400 cursor-not-allowed' : ''} focus:outline-none focus:ring-1`}
      />
      {suffix && (
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm">
          <i className={`${suffix} w-4 h-4 flex items-center justify-center`}></i>
        </span>
      )}
    </div>
  );
}
