import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import StatusTag from '../../components/common/StatusTag';
import {
  advisoryContentData,
  contentCategories,
  contentTypeOptions,
} from '../../mocks/advisoryContent';

export default function AdvisoryContent() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedContent, setSelectedContent] = useState<any>(null);

  // 筛选内容
  const filteredContent = advisoryContentData.filter((content) => {
    const categoryMatch = selectedCategory === 'all' || content.category === selectedCategory;
    const typeMatch = selectedType === 'all' || content.type === selectedType;
    const keywordMatch =
      searchKeyword === '' ||
      content.title.includes(searchKeyword) ||
      content.summary.includes(searchKeyword) ||
      content.tags.some((tag) => tag.includes(searchKeyword));

    return categoryMatch && typeMatch && keywordMatch;
  });

  // 内容详情弹窗
  const ContentDetailModal = () => {
    if (!selectedContent) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
        <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">资讯详情</h3>
            <button
              onClick={() => setSelectedContent(null)}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-close-line text-xl w-5 h-5 flex items-center justify-center"></i>
            </button>
          </div>
          <div className="p-6 space-y-6">
            <div>
              <img
                src={selectedContent.thumbnail}
                alt={selectedContent.title}
                className="w-full h-64 object-cover object-top rounded-lg mb-4"
              />
              <h4 className="text-2xl font-bold text-gray-900 mb-3">{selectedContent.title}</h4>
              <div className="flex items-center gap-4 text-sm text-gray-500 mb-4">
                <span className="flex items-center gap-1">
                  <i className="ri-user-line w-4 h-4 flex items-center justify-center"></i>
                  {selectedContent.author}
                </span>
                <span className="flex items-center gap-1">
                  <i className="ri-calendar-line w-4 h-4 flex items-center justify-center"></i>
                  {selectedContent.publishDate}
                </span>
                <span className="flex items-center gap-1">
                  <i className="ri-time-line w-4 h-4 flex items-center justify-center"></i>
                  {selectedContent.duration}
                </span>
                <span className="flex items-center gap-1">
                  <i className="ri-eye-line w-4 h-4 flex items-center justify-center"></i>
                  {selectedContent.readCount} 次阅读
                </span>
              </div>
              <div className="flex items-center gap-2 mb-4">
                <StatusTag type="info" label={selectedContent.type} />
                <StatusTag type="default" label={selectedContent.category} />
              </div>
              <p className="text-gray-600 leading-relaxed text-base">{selectedContent.summary}</p>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="text-sm font-medium text-blue-900 mb-2">
                <i className="ri-user-heart-line w-4 h-4 flex items-center justify-center inline-flex mr-1"></i>
                适配客户人群
              </div>
              <div className="text-sm text-blue-700">{selectedContent.targetCustomer}</div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-700 mb-2">内容标签</div>
              <div className="flex flex-wrap gap-2">
                {selectedContent.tags.map((tag: string, index: number) => (
                  <span key={index} className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {selectedContent.relatedProducts && selectedContent.relatedProducts.length > 0 && (
              <div>
                <div className="text-sm font-medium text-gray-700 mb-3">关联投顾产品</div>
                <div className="space-y-2">
                  {selectedContent.relatedProducts.map((productId: string) => (
                    <div
                      key={productId}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                    >
                      <span className="text-sm text-gray-700">产品编号: {productId}</span>
                      <button className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap">
                        查看产品
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex items-center justify-end gap-3">
            <Button type="default" onClick={() => setSelectedContent(null)}>
              关闭
            </Button>
            <Button type="default" icon="ri-share-line">
              分享内容
            </Button>
            <Button type="primary" icon="ri-send-plane-line">
              推送给客户
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <MainLayout>
      <PageHeader
        title="投顾资讯库"
        description="统一管理投教内容与专业资讯，支持向客户传递服务价值"
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line" size="small">
              导出内容清单
            </Button>
            <Button type="primary" icon="ri-add-line">
              添加新内容
            </Button>
          </div>
        }
      />

      <div className="p-6">
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* 筛选区域 */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-4 mb-4">
              <div className="flex-1">
                <div className="relative">
                  <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 flex items-center justify-center"></i>
                  <input
                    type="text"
                    placeholder="搜索内容标题、摘要或标签..."
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
              >
                {contentTypeOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            {/* 内容分类标签 */}
            <div className="flex items-center gap-2 flex-wrap">
              {contentCategories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {category.name}
                  <span className="ml-2 opacity-75">({category.count})</span>
                </button>
              ))}
            </div>
          </div>

          {/* 内容列表 */}
          <div className="p-6">
            <div className="mb-4 text-sm text-gray-500">
              共找到 <span className="font-medium text-gray-900">{filteredContent.length}</span> 条内容
            </div>
            <div className="space-y-4">
              {filteredContent.map((content) => (
                <div
                  key={content.id}
                  className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-all bg-gradient-to-br from-white to-gray-50"
                >
                  <div className="flex gap-5">
                    {/* 缩略图 */}
                    <div className="w-48 h-32 flex-shrink-0">
                      <img
                        src={content.thumbnail}
                        alt={content.title}
                        className="w-full h-full object-cover object-top rounded-lg"
                      />
                    </div>

                    {/* 内容信息 */}
                    <div className="flex-1 flex flex-col">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="text-base font-semibold text-gray-900 flex-1 pr-4">{content.title}</h4>
                        <div className="flex items-center gap-2">
                          <StatusTag type="info" label={content.type} />
                        </div>
                      </div>

                      <p className="text-sm text-gray-600 mb-3 line-clamp-2 leading-relaxed">{content.summary}</p>

                      <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                        <span className="flex items-center gap-1">
                          <i className="ri-user-line w-3.5 h-3.5 flex items-center justify-center"></i>
                          {content.author}
                        </span>
                        <span className="flex items-center gap-1">
                          <i className="ri-calendar-line w-3.5 h-3.5 flex items-center justify-center"></i>
                          {content.publishDate}
                        </span>
                        <span className="flex items-center gap-1">
                          <i className="ri-time-line w-3.5 h-3.5 flex items-center justify-center"></i>
                          {content.duration}
                        </span>
                        <span className="flex items-center gap-1">
                          <i className="ri-eye-line w-3.5 h-3.5 flex items-center justify-center"></i>
                          {content.readCount} 次阅读
                        </span>
                      </div>

                      <div className="flex items-center justify-between mt-auto">
                        <div className="flex flex-wrap gap-1.5">
                          {content.tags.slice(0, 3).map((tag, index) => (
                            <span key={index} className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
                              #{tag}
                            </span>
                          ))}
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setSelectedContent(content)}
                            className="px-4 py-1.5 bg-white border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
                          >
                            查看详情
                          </button>
                          <button className="px-4 py-1.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                            推送客户
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 内容详情弹窗 */}
      <ContentDetailModal />
    </MainLayout>
  );
}
