
import { ReactNode } from 'react';
import TopBar from './TopBar';
import Sidebar from './Sidebar';

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <TopBar />
      <Sidebar />
      <main className="fixed top-14 left-56 right-0 bottom-0 overflow-auto">
        {children}
      </main>
    </div>
  );
}
