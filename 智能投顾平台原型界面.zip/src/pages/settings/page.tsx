import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';

export default function Settings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('account');

  // 获取当前用户角色（实际应从认证系统获取）
  const currentUserRole = 'manager'; // manager | admin | compliance

  // 设置模块配置
  const settingModules = [
    {
      id: 'account',
      title: '账户与权限',
      icon: 'ri-shield-user-line',
      description: '账号管理、角色权限配置与操作日志',
      path: '/settings/account',
      roles: ['manager', 'admin', 'compliance'],
      subItems: [
        { id: 'profile', label: '账号信息', path: '/settings/account/profile', roles: ['manager', 'admin', 'compliance'] },
        { id: 'role', label: '角色权限', path: '/settings/account/role', roles: ['admin'] },
        { id: 'logs', label: '操作日志', path: '/settings/account/logs', roles: ['admin', 'compliance'] },
      ],
    },
    {
      id: 'personal',
      title: '个人中心',
      icon: 'ri-user-settings-line',
      description: '个人信息、偏好设置与操作记录',
      path: '/settings/personal',
      roles: ['manager', 'admin', 'compliance'],
      subItems: [
        { id: 'info', label: '个人信息', path: '/settings/personal/info', roles: ['manager', 'admin', 'compliance'] },
        { id: 'preferences', label: '偏好设置', path: '/settings/personal/preferences', roles: ['manager', 'admin', 'compliance'] },
        { id: 'shortcuts', label: '快捷工具', path: '/settings/personal/shortcuts', roles: ['manager', 'admin', 'compliance'] },
        { id: 'history', label: '操作记录', path: '/settings/personal/history', roles: ['manager', 'admin', 'compliance'] },
      ],
    },
    {
      id: 'notification',
      title: '消息通知',
      icon: 'ri-notification-3-line',
      description: '待办提醒、合规预警与系统通知',
      path: '/settings/notification',
      roles: ['manager', 'admin', 'compliance'],
      subItems: [
        { id: 'todo', label: '待办提醒', path: '/settings/notification/todo', roles: ['manager', 'admin', 'compliance'] },
        { id: 'compliance', label: '合规预警', path: '/settings/notification/compliance', roles: ['manager', 'admin', 'compliance'] },
        { id: 'system', label: '系统通知', path: '/settings/notification/system', roles: ['manager', 'admin', 'compliance'] },
        { id: 'rules', label: '提醒规则', path: '/settings/notification/rules', roles: ['manager', 'admin'] },
      ],
    },
  ];

  // 根据角色过滤模块
  const filteredModules = settingModules.filter(module => 
    module.roles.includes(currentUserRole)
  );

  return (
    <MainLayout>
      <PageHeader
        title="系统设置"
        description="管理账户权限、个人偏好与消息通知"
        breadcrumb={[
          { label: '首页', path: '/' },
          { label: '系统设置' },
        ]}
      />

      <div className="p-6">
        <div className="grid grid-cols-3 gap-5">
          {filteredModules.map((module) => (
            <button
              key={module.id}
              onClick={() => navigate(module.path)}
              className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg hover:border-blue-300 transition-all cursor-pointer text-left group"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg flex items-center justify-center text-blue-600 group-hover:from-blue-100 group-hover:to-blue-200 transition-all flex-shrink-0">
                  <i className={`${module.icon} text-2xl w-6 h-6 flex items-center justify-center`}></i>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-base font-semibold text-gray-900 mb-1 group-hover:text-blue-600 transition-colors">
                    {module.title}
                  </h3>
                  <p className="text-sm text-gray-500 mb-4 leading-relaxed">
                    {module.description}
                  </p>
                  <div className="space-y-1.5">
                    {module.subItems
                      .filter(item => item.roles.includes(currentUserRole))
                      .map((subItem) => (
                        <div
                          key={subItem.id}
                          className="flex items-center gap-2 text-sm text-gray-600 group-hover:text-blue-600 transition-colors"
                        >
                          <i className="ri-arrow-right-s-line text-base w-4 h-4 flex items-center justify-center"></i>
                          <span>{subItem.label}</span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* 合规提示 */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-5">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 flex items-center justify-center text-blue-600 flex-shrink-0 mt-0.5">
              <i className="ri-information-line text-lg w-5 h-5 flex items-center justify-center"></i>
            </div>
            <div className="flex-1 text-sm text-blue-900 leading-relaxed space-y-1">
              <p><strong>合规说明：</strong></p>
              <p>• 系统操作均记录在案，供合规审计使用</p>
              <p>• 提醒与建议仅用于服务管理参考</p>
              <p>• 不构成投资建议或业务指令</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
