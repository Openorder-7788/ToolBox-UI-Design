
import { ReactNode } from 'react';

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: ReactNode;
  breadcrumb?: Array<{ label: string; path?: string }>;
}

export default function PageHeader({ title, description, actions, breadcrumb }: PageHeaderProps) {
  return (
    <div className="bg-white border-b border-gray-200">
      <div className="px-6 py-5">
        {/* 面包屑 */}
        {breadcrumb && breadcrumb.length > 0 && (
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-3">
            {breadcrumb.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                {index > 0 && <i className="ri-arrow-right-s-line text-gray-400"></i>}
                {item.path ? (
                  <a href={item.path} className="hover:text-gray-700 cursor-pointer">
                    {item.label}
                  </a>
                ) : (
                  <span className="text-gray-700">{item.label}</span>
                )}
              </div>
            ))}
          </div>
        )}

        {/* 标题和操作 */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">{title}</h2>
            {description && <p className="mt-1 text-sm text-gray-500">{description}</p>}
          </div>
          {actions && <div className="flex items-center gap-3">{actions}</div>}
        </div>
      </div>
    </div>
  );
}
