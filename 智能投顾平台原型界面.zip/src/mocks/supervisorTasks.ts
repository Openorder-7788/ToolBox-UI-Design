export const supervisorTasksData = {
  activeTasks: [
    {
      id: 'TASK001',
      name: 'Q1投顾产品推广任务',
      description: '针对已开户未转化客户，推广智投组合A产品，提升产品购买率',
      goal: '提升投顾产品购买率',
      status: 'active',
      startDate: '2024-01-01',
      endDate: '2024-01-31',
      assignedTo: 'all',
      targetCustomerType: '已开户未转化',
      rules: [
        '向目标客户推荐"智投组合A"产品',
        '使用"产品推荐话术"模板进行沟通',
        '每位客户至少跟进3次',
        '记录客户反馈和购买意向'
      ],
      progress: {
        targetCustomers: 450,
        executedCustomers: 312,
        recommendations: 856,
        conversions: 128,
        conversionRate: 41.0,
        completionRate: 69
      },
      executionTracking: [
        {
          managerId: 'M001',
          managerName: '张经理',
          executedCustomers: 42,
          recommendations: 115,
          conversions: 22,
          conversionRate: 52.4,
          completionRate: 84
        },
        {
          managerId: 'M002',
          managerName: '李经理',
          executedCustomers: 38,
          recommendations: 98,
          conversions: 18,
          conversionRate: 47.4,
          completionRate: 76
        },
        {
          managerId: 'M003',
          managerName: '王经理',
          executedCustomers: 35,
          recommendations: 89,
          conversions: 15,
          conversionRate: 42.9,
          completionRate: 70
        },
        {
          managerId: 'M004',
          managerName: '赵经理',
          executedCustomers: 33,
          recommendations: 85,
          conversions: 14,
          conversionRate: 42.4,
          completionRate: 66
        },
        {
          managerId: 'M005',
          managerName: '刘经理',
          executedCustomers: 31,
          recommendations: 78,
          conversions: 12,
          conversionRate: 38.7,
          completionRate: 62
        },
        {
          managerId: 'M006',
          managerName: '陈经理',
          executedCustomers: 29,
          recommendations: 72,
          conversions: 11,
          conversionRate: 37.9,
          completionRate: 58
        },
        {
          managerId: 'M007',
          managerName: '杨经理',
          executedCustomers: 27,
          recommendations: 68,
          conversions: 10,
          conversionRate: 37.0,
          completionRate: 54
        },
        {
          managerId: 'M008',
          managerName: '周经理',
          executedCustomers: 25,
          recommendations: 62,
          conversions: 9,
          conversionRate: 36.0,
          completionRate: 50
        },
        {
          managerId: 'M009',
          managerName: '吴经理',
          executedCustomers: 22,
          recommendations: 55,
          conversions: 7,
          conversionRate: 31.8,
          completionRate: 44
        },
        {
          managerId: 'M010',
          managerName: '郑经理',
          executedCustomers: 18,
          recommendations: 48,
          conversions: 6,
          conversionRate: 33.3,
          completionRate: 36
        },
        {
          managerId: 'M011',
          managerName: '孙经理',
          executedCustomers: 12,
          recommendations: 38,
          conversions: 4,
          conversionRate: 33.3,
          completionRate: 24
        }
      ],
      effectiveness: {
        conversionRateChange: '+8.5%',
        dealIncrease: '+42笔',
        topPerformers: ['张经理', '李经理', '王经理']
      }
    },
    {
      id: 'TASK002',
      name: '沉睡客户唤醒专项任务',
      description: '针对3个月未活跃的沉睡客户，进行唤醒沟通，提升客户活跃度',
      goal: '唤醒沉睡客户',
      status: 'active',
      startDate: '2024-01-10',
      endDate: '2024-01-24',
      assignedTo: 'selected',
      assignedManagers: ['M001', 'M002', 'M003', 'M004', 'M005'],
      targetCustomerType: '沉睡客户',
      rules: [
        '使用"沉睡客户唤醒话术"进行沟通',
        '了解客户沉睡原因',
        '推荐适合的投教内容或产品',
        '每位客户至少跟进2次'
      ],
      progress: {
        targetCustomers: 280,
        executedCustomers: 156,
        recommendations: 312,
        conversions: 45,
        conversionRate: 28.8,
        completionRate: 56
      },
      executionTracking: [
        {
          managerId: 'M001',
          managerName: '张经理',
          executedCustomers: 38,
          recommendations: 76,
          conversions: 12,
          conversionRate: 31.6,
          completionRate: 68
        },
        {
          managerId: 'M002',
          managerName: '李经理',
          executedCustomers: 35,
          recommendations: 70,
          conversions: 11,
          conversionRate: 31.4,
          completionRate: 63
        },
        {
          managerId: 'M003',
          managerName: '王经理',
          executedCustomers: 32,
          recommendations: 64,
          conversions: 9,
          conversionRate: 28.1,
          completionRate: 57
        },
        {
          managerId: 'M004',
          managerName: '赵经理',
          executedCustomers: 28,
          recommendations: 56,
          conversions: 7,
          conversionRate: 25.0,
          completionRate: 50
        },
        {
          managerId: 'M005',
          managerName: '刘经理',
          executedCustomers: 23,
          recommendations: 46,
          conversions: 6,
          conversionRate: 26.1,
          completionRate: 41
        }
      ],
      effectiveness: {
        conversionRateChange: '+12.3%',
        dealIncrease: '+28笔',
        topPerformers: ['张经理', '李经理']
      }
    }
  ],
  completedTasks: [
    {
      id: 'TASK003',
      name: '高价值客户深度服务任务',
      description: '针对高价值客户，提供专属投顾服务，提升客户满意度和产品购买率',
      goal: '高价值客户深度服务',
      status: 'completed',
      startDate: '2023-12-01',
      endDate: '2023-12-31',
      assignedTo: 'all',
      targetCustomerType: '高价值客户',
      rules: [
        '使用"高价值客户维护话术"进行沟通',
        '推荐"量化策略产品"或"成长型基金组合"',
        '每位客户至少跟进4次',
        '提供市场分析和投资建议'
      ],
      progress: {
        targetCustomers: 180,
        executedCustomers: 180,
        recommendations: 720,
        conversions: 95,
        conversionRate: 52.8,
        completionRate: 100
      },
      executionTracking: [
        {
          managerId: 'M001',
          managerName: '张经理',
          executedCustomers: 18,
          recommendations: 72,
          conversions: 12,
          conversionRate: 66.7,
          completionRate: 100
        },
        {
          managerId: 'M002',
          managerName: '李经理',
          executedCustomers: 17,
          recommendations: 68,
          conversions: 10,
          conversionRate: 58.8,
          completionRate: 100
        },
        {
          managerId: 'M003',
          managerName: '王经理',
          executedCustomers: 16,
          recommendations: 64,
          conversions: 9,
          conversionRate: 56.3,
          completionRate: 100
        },
        {
          managerId: 'M004',
          managerName: '赵经理',
          executedCustomers: 15,
          recommendations: 60,
          conversions: 8,
          conversionRate: 53.3,
          completionRate: 100
        },
        {
          managerId: 'M005',
          managerName: '刘经理',
          executedCustomers: 15,
          recommendations: 60,
          conversions: 8,
          conversionRate: 53.3,
          completionRate: 100
        },
        {
          managerId: 'M006',
          managerName: '陈经理',
          executedCustomers: 15,
          recommendations: 60,
          conversions: 7,
          conversionRate: 46.7,
          completionRate: 100
        },
        {
          managerId: 'M007',
          managerName: '杨经理',
          executedCustomers: 15,
          recommendations: 60,
          conversions: 7,
          conversionRate: 46.7,
          completionRate: 100
        },
        {
          managerId: 'M008',
          managerName: '周经理',
          executedCustomers: 15,
          recommendations: 60,
          conversions: 7,
          conversionRate: 46.7,
          completionRate: 100
        },
        {
          managerId: 'M009',
          managerName: '吴经理',
          executedCustomers: 15,
          recommendations: 60,
          conversions: 7,
          conversionRate: 46.7,
          completionRate: 100
        },
        {
          managerId: 'M010',
          managerName: '郑经理',
          executedCustomers: 14,
          recommendations: 56,
          conversions: 7,
          conversionRate: 50.0,
          completionRate: 100
        },
        {
          managerId: 'M011',
          managerName: '孙经理',
          executedCustomers: 14,
          recommendations: 56,
          conversions: 6,
          conversionRate: 42.9,
          completionRate: 100
        },
        {
          managerId: 'M012',
          managerName: '黄经理',
          executedCustomers: 11,
          recommendations: 44,
          conversions: 7,
          conversionRate: 63.6,
          completionRate: 100
        }
      ],
      effectiveness: {
        conversionRateChange: '+15.2%',
        dealIncrease: '+38笔',
        topPerformers: ['张经理', '黄经理', '李经理']
      }
    },
    {
      id: 'TASK004',
      name: '新开户客户转化任务',
      description: '针对新开户客户，进行首次产品推荐，提升新客转化率',
      goal: '提升开户转化率',
      status: 'completed',
      startDate: '2023-11-15',
      endDate: '2023-11-30',
      assignedTo: 'all',
      targetCustomerType: '新开户客户',
      rules: [
        '使用"产品推荐话术"进行沟通',
        '推荐"稳健理财计划"作为首次产品',
        '每位客户至少跟进2次',
        '了解客户投资偏好和风险承受能力'
      ],
      progress: {
        targetCustomers: 320,
        executedCustomers: 320,
        recommendations: 640,
        conversions: 156,
        conversionRate: 48.8,
        completionRate: 100
      },
      executionTracking: [
        {
          managerId: 'M001',
          managerName: '张经理',
          executedCustomers: 32,
          recommendations: 64,
          conversions: 18,
          conversionRate: 56.3,
          completionRate: 100
        },
        {
          managerId: 'M002',
          managerName: '李经理',
          executedCustomers: 30,
          recommendations: 60,
          conversions: 16,
          conversionRate: 53.3,
          completionRate: 100
        },
        {
          managerId: 'M003',
          managerName: '王经理',
          executedCustomers: 28,
          recommendations: 56,
          conversions: 14,
          conversionRate: 50.0,
          completionRate: 100
        },
        {
          managerId: 'M004',
          managerName: '赵经理',
          executedCustomers: 27,
          recommendations: 54,
          conversions: 13,
          conversionRate: 48.1,
          completionRate: 100
        },
        {
          managerId: 'M005',
          managerName: '刘经理',
          executedCustomers: 26,
          recommendations: 52,
          conversions: 13,
          conversionRate: 50.0,
          completionRate: 100
        },
        {
          managerId: 'M006',
          managerName: '陈经理',
          executedCustomers: 26,
          recommendations: 52,
          conversions: 12,
          conversionRate: 46.2,
          completionRate: 100
        },
        {
          managerId: 'M007',
          managerName: '杨经理',
          executedCustomers: 26,
          recommendations: 52,
          conversions: 12,
          conversionRate: 46.2,
          completionRate: 100
        },
        {
          managerId: 'M008',
          managerName: '周经理',
          executedCustomers: 26,
          recommendations: 52,
          conversions: 12,
          conversionRate: 46.2,
          completionRate: 100
        },
        {
          managerId: 'M009',
          managerName: '吴经理',
          executedCustomers: 25,
          recommendations: 50,
          conversions: 11,
          conversionRate: 44.0,
          completionRate: 100
        },
        {
          managerId: 'M010',
          managerName: '郑经理',
          executedCustomers: 25,
          recommendations: 50,
          conversions: 11,
          conversionRate: 44.0,
          completionRate: 100
        },
        {
          managerId: 'M011',
          managerName: '孙经理',
          executedCustomers: 25,
          recommendations: 50,
          conversions: 12,
          conversionRate: 48.0,
          completionRate: 100
        },
        {
          managerId: 'M012',
          managerName: '黄经理',
          executedCustomers: 24,
          recommendations: 48,
          conversions: 12,
          conversionRate: 50.0,
          completionRate: 100
        }
      ],
      effectiveness: {
        conversionRateChange: '+11.8%',
        dealIncrease: '+52笔',
        topPerformers: ['张经理', '李经理', '王经理']
      }
    }
  ]
};
