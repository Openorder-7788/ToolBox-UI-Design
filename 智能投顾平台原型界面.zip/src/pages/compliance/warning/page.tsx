import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import {
  violationEvents,
  violationTypes,
  violationLevels,
  processingStatuses,
} from '../../../mocks/complianceWarning';

export default function ComplianceWarningPage() {
  const navigate = useNavigate();
  const [selectedEvent, setSelectedEvent] = useState(violationEvents[0]);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [warningType, setWarningType] = useState<'manager' | 'supervisor' | 'rectify'>('manager');

  // 筛选违规事件
  const filteredEvents = violationEvents.filter((event) => {
    if (selectedType !== 'all' && event.violationType !== selectedType) return false;
    if (selectedLevel !== 'all' && event.violationLevel !== selectedLevel) return false;
    if (selectedStatus !== 'all' && event.status !== selectedStatus) return false;
    return true;
  });

  // 违规等级映射
  const levelMap = {
    high: { label: '严重违规', color: 'bg-red-100 text-red-700 border-red-200' },
    medium: { label: '一般违规', color: 'bg-orange-100 text-orange-700 border-orange-200' },
    low: { label: '轻微违规', color: 'bg-yellow-100 text-yellow-700 border-yellow-200' },
  };

  // 处理状态映射
  const statusMap = {
    pending: { label: '待处理', color: 'bg-gray-100 text-gray-700 border-gray-200', icon: 'ri-time-line' },
    notified: { label: '已通知', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: 'ri-notification-3-line' },
    rectifying: { label: '整改中', color: 'bg-orange-100 text-orange-700 border-orange-200', icon: 'ri-tools-line' },
    reviewing: { label: '复查中', color: 'bg-purple-100 text-purple-700 border-purple-200', icon: 'ri-search-eye-line' },
    completed: { label: '已完成', color: 'bg-green-100 text-green-700 border-green-200', icon: 'ri-checkbox-circle-line' },
  };

  // 发送预警
  const handleSendWarning = () => {
    setShowWarningModal(false);
    alert(`已向${warningType === 'manager' ? '客户经理' : warningType === 'supervisor' ? '主管' : '相关人员'}发送${warningType === 'rectify' ? '整改通知' : '预警通知'}`);
  };

  return (
    <MainLayout>
      <div className="min-h-screen bg-gray-50">
        {/* 页面标题 */}
        <div className="bg-white border-b border-gray-200 px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">违规预警与处置中心</h1>
              <p className="text-sm text-gray-500 mt-1">
                对已确认的违规行为进行预警、通知与跟踪处理
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2">
                <i className="ri-download-line"></i>
                导出记录
              </button>
              <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm font-medium whitespace-nowrap flex items-center gap-2">
                <i className="ri-bar-chart-box-line"></i>
                统计报表
              </button>
            </div>
          </div>
        </div>

        <div className="p-8">
          <div className="grid grid-cols-12 gap-6">
            {/* 左侧：违规事件列表区 */}
            <div className="col-span-5 bg-white rounded-xl border border-gray-200">
              {/* 筛选区 */}
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-lg font-bold text-gray-900 mb-4">违规事件列表</h2>
                
                {/* 违规类型筛选 */}
                <div className="mb-4">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    违规类型
                  </label>
                  <select
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="all">全部类型</option>
                    {violationTypes.map((type) => (
                      <option key={type.id} value={type.id}>
                        {type.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 违规等级筛选 */}
                <div className="mb-4">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    违规等级
                  </label>
                  <select
                    value={selectedLevel}
                    onChange={(e) => setSelectedLevel(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="all">全部等级</option>
                    {violationLevels.map((level) => (
                      <option key={level.id} value={level.id}>
                        {level.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 处理状态筛选 */}
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    处理状态
                  </label>
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="all">全部状态</option>
                    {processingStatuses.map((status) => (
                      <option key={status.id} value={status.id}>
                        {status.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* 违规事件列表 */}
              <div className="overflow-y-auto" style={{ maxHeight: 'calc(100vh - 400px)' }}>
                {filteredEvents.length === 0 ? (
                  <div className="p-8 text-center">
                    <i className="ri-inbox-line text-4xl text-gray-300 mb-2"></i>
                    <p className="text-sm text-gray-500">暂无符合条件的违规事件</p>
                  </div>
                ) : (
                  filteredEvents.map((event) => (
                    <div
                      key={event.id}
                      onClick={() => setSelectedEvent(event)}
                      className={`p-4 border-b border-gray-100 cursor-pointer transition-colors ${
                        selectedEvent.id === event.id
                          ? 'bg-emerald-50 border-l-4 border-l-emerald-600'
                          : 'hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${
                              levelMap[event.violationLevel as keyof typeof levelMap].color
                            }`}
                          >
                            {levelMap[event.violationLevel as keyof typeof levelMap].label}
                          </span>
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${
                              statusMap[event.status as keyof typeof statusMap].color
                            }`}
                          >
                            <i className={`${statusMap[event.status as keyof typeof statusMap].icon}`}></i>
                            {statusMap[event.status as keyof typeof statusMap].label}
                          </span>
                        </div>
                      </div>

                      <div className="mb-2">
                        <div className="flex items-center gap-2 mb-1">
                          <div className="w-8 h-8 bg-gradient-to-br from-red-400 to-orange-500 rounded-full flex items-center justify-center text-white text-sm font-medium">
                            {event.violator.charAt(0)}
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {event.violator}
                            </div>
                            <div className="text-xs text-gray-500">
                              {event.team} · {event.supervisor}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="text-sm text-gray-700 mb-2">
                        <span className="font-medium">违规类型：</span>
                        {event.violationTypeName}
                      </div>

                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>
                          <i className="ri-time-line mr-1"></i>
                          {event.occurredAt}
                        </span>
                        {event.historyCount > 0 && (
                          <span className="text-red-600 font-medium">
                            历史违规 {event.historyCount} 次
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* 右侧：违规详情与操作区 */}
            <div className="col-span-7 space-y-6">
              {/* 违规详情与证据区 */}
              <div className="bg-white rounded-xl p-6 border border-gray-200">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-lg font-bold text-gray-900">违规详情与证据</h2>
                  <div className="flex items-center gap-2">
                    <span
                      className={`inline-flex items-center px-3 py-1.5 rounded-full text-sm font-medium border ${
                        levelMap[selectedEvent.violationLevel as keyof typeof levelMap].color
                      }`}
                    >
                      {levelMap[selectedEvent.violationLevel as keyof typeof levelMap].label}
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-medium border ${
                        statusMap[selectedEvent.status as keyof typeof statusMap].color
                      }`}
                    >
                      <i className={`${statusMap[selectedEvent.status as keyof typeof statusMap].icon}`}></i>
                      {statusMap[selectedEvent.status as keyof typeof statusMap].label}
                    </span>
                  </div>
                </div>

                {/* 违规人员信息 */}
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs text-gray-500 mb-1">违规人员</div>
                      <div className="text-sm font-medium text-gray-900">
                        {selectedEvent.violator}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">所属团队</div>
                      <div className="text-sm font-medium text-gray-900">
                        {selectedEvent.team}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">直属主管</div>
                      <div className="text-sm font-medium text-gray-900">
                        {selectedEvent.supervisor}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-500 mb-1">发生时间</div>
                      <div className="text-sm font-medium text-gray-900">
                        {selectedEvent.occurredAt}
                      </div>
                    </div>
                  </div>
                </div>

                {/* 违规内容原文 */}
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-gray-900 mb-3">违规内容原文</h3>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div className="text-sm text-gray-700 leading-relaxed">
                      {selectedEvent.content.split('\n').map((line, index) => {
                        // 高亮违规关键词
                        const highlightedLine = line.replace(
                          /(保证收益|稳赚不赔|年化\s*\d+%|保本保息|必将|一定会|内幕消息|独家消息)/g,
                          '<span class="bg-red-200 text-red-900 font-medium px-1 rounded">$1</span>'
                        );
                        return (
                          <p
                            key={index}
                            className="mb-2"
                            dangerouslySetInnerHTML={{ __html: highlightedLine }}
                          />
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* 命中合规规则说明 */}
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-gray-900 mb-3">命中合规规则</h3>
                  <div className="space-y-3">
                    {selectedEvent.violatedRules.map((rule, index) => (
                      <div
                        key={index}
                        className="bg-orange-50 border border-orange-200 rounded-lg p-4"
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 bg-orange-500 text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <div className="text-sm font-medium text-gray-900 mb-1">
                              {rule.ruleName}
                            </div>
                            <div className="text-sm text-gray-600">{rule.description}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 历史类似违规记录 */}
                {selectedEvent.historyCount > 0 && (
                  <div>
                    <h3 className="text-sm font-bold text-gray-900 mb-3">
                      历史类似违规记录
                      <span className="ml-2 text-red-600">
                        （共 {selectedEvent.historyCount} 次）
                      </span>
                    </h3>
                    <div className="space-y-2">
                      {selectedEvent.historyRecords.map((record, index) => (
                        <div
                          key={index}
                          className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex items-center justify-between"
                        >
                          <div>
                            <div className="text-sm font-medium text-gray-900 mb-1">
                              {record.violationType}
                            </div>
                            <div className="text-xs text-gray-500">{record.date}</div>
                          </div>
                          <span
                            className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${
                              record.status === 'completed'
                                ? 'bg-green-100 text-green-700 border-green-200'
                                : 'bg-orange-100 text-orange-700 border-orange-200'
                            }`}
                          >
                            {record.status === 'completed' ? '已整改' : '整改中'}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* 预警与通知操作区 */}
              <div className="bg-white rounded-xl p-6 border border-gray-200">
                <h2 className="text-lg font-bold text-gray-900 mb-4">预警与通知操作</h2>
                
                <div className="grid grid-cols-3 gap-4 mb-6">
                  <button
                    onClick={() => {
                      setWarningType('manager');
                      setShowWarningModal(true);
                    }}
                    className="px-4 py-3 bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-lg hover:shadow-md transition-all text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                        <i className="ri-alarm-warning-line text-lg text-red-600"></i>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          向客户经理预警
                        </div>
                        <div className="text-xs text-gray-500">发送合规预警</div>
                      </div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setWarningType('supervisor');
                      setShowWarningModal(true);
                    }}
                    className="px-4 py-3 bg-gradient-to-r from-orange-50 to-yellow-50 border border-orange-200 rounded-lg hover:shadow-md transition-all text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                        <i className="ri-notification-3-line text-lg text-orange-600"></i>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          向主管通知
                        </div>
                        <div className="text-xs text-gray-500">发送管理提醒</div>
                      </div>
                    </div>
                  </button>

                  <button
                    onClick={() => {
                      setWarningType('rectify');
                      setShowWarningModal(true);
                    }}
                    className="px-4 py-3 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg hover:shadow-md transition-all text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i className="ri-file-edit-line text-lg text-blue-600"></i>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">
                          要求限期整改
                        </div>
                        <div className="text-xs text-gray-500">设置整改期限</div>
                      </div>
                    </div>
                  </button>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <i className="ri-information-line text-yellow-600 text-lg mt-0.5"></i>
                    <div className="text-sm text-yellow-800">
                      <div className="font-medium mb-1">预警说明</div>
                      <div>预警仅用于内部管理，不直接影响客户服务结果。</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* 处理状态跟踪区 */}
              <div className="bg-white rounded-xl p-6 border border-gray-200">
                <h2 className="text-lg font-bold text-gray-900 mb-4">处理状态跟踪</h2>
                
                <div className="space-y-4">
                  {selectedEvent.processingTimeline.map((item, index) => (
                    <div key={index} className="flex items-start gap-4">
                      <div className="flex flex-col items-center">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            item.completed
                              ? 'bg-emerald-100 text-emerald-600'
                              : 'bg-gray-100 text-gray-400'
                          }`}
                        >
                          <i className={`${item.icon} text-lg`}></i>
                        </div>
                        {index < selectedEvent.processingTimeline.length - 1 && (
                          <div
                            className={`w-0.5 h-12 ${
                              item.completed ? 'bg-emerald-200' : 'bg-gray-200'
                            }`}
                          ></div>
                        )}
                      </div>
                      <div className="flex-1 pb-4">
                        <div className="flex items-center justify-between mb-1">
                          <div className="text-sm font-medium text-gray-900">
                            {item.status}
                          </div>
                          {item.time && (
                            <div className="text-xs text-gray-500">{item.time}</div>
                          )}
                        </div>
                        <div className="text-sm text-gray-600">{item.description}</div>
                        {item.operator && (
                          <div className="text-xs text-gray-500 mt-1">
                            操作人：{item.operator}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 预警通知弹窗 */}
        {showWarningModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-6 w-full max-w-md">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-900">
                  {warningType === 'manager'
                    ? '向客户经理发送预警'
                    : warningType === 'supervisor'
                    ? '向主管发送通知'
                    : '要求限期整改'}
                </h3>
                <button
                  onClick={() => setShowWarningModal(false)}
                  className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>

              <div className="mb-4">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  {warningType === 'rectify' ? '整改期限' : '通知内容'}
                </label>
                {warningType === 'rectify' ? (
                  <input
                    type="date"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                ) : (
                  <textarea
                    rows={4}
                    placeholder="请输入通知内容..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  ></textarea>
                )}
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowWarningModal(false)}
                  className="flex-1 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium whitespace-nowrap"
                >
                  取消
                </button>
                <button
                  onClick={handleSendWarning}
                  className="flex-1 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm font-medium whitespace-nowrap"
                >
                  确认发送
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
