
interface Step {
  title: string;
  description?: string;
}

interface StepsProps {
  steps: Step[];
  current: number;
}

export default function Steps({ steps, current }: StepsProps) {
  return (
    <div className="w-full">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={index} className="flex-1 flex items-center">
            <div className="flex flex-col items-center">
              {/* 步骤圆圈 */}
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                  index < current
                    ? 'bg-blue-600 text-white'
                    : index === current
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-200 text-gray-500'
                }`}
              >
                {index < current ? (
                  <i className="ri-check-line w-4 h-4 flex items-center justify-center"></i>
                ) : (
                  index + 1
                )}
              </div>
              {/* 步骤文字 */}
              <div className="mt-2 text-center">
                <div
                  className={`text-sm font-medium ${
                    index <= current ? 'text-gray-900' : 'text-gray-500'
                  }`}
                >
                  {step.title}
                </div>
                {step.description && (
                  <div className="text-xs text-gray-500 mt-0.5">{step.description}</div>
                )}
              </div>
            </div>
            {/* 连接线 */}
            {index < steps.length - 1 && (
              <div className="flex-1 h-px bg-gray-200 mx-4 mb-8">
                <div
                  className={`h-full transition-all ${
                    index < current ? 'bg-blue-600' : 'bg-gray-200'
                  }`}
                  style={{ width: index < current ? '100%' : '0%' }}
                ></div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
