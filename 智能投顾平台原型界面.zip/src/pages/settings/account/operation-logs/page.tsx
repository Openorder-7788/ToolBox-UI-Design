import { useState } from 'react';
import MainLayout from '../../../../components/layout/MainLayout';
import PageHeader from '../../../../components/common/PageHeader';
import Button from '../../../../components/common/Button';
import DataTable from '../../../../components/common/DataTable';
import StatusTag from '../../../../components/common/StatusTag';

export default function OperationLogs() {
  const [filterType, setFilterType] = useState('all');
  const [dateRange, setDateRange] = useState('week');

  // 操作日志数据
  const logsData = [
    {
      id: 1,
      operator: '张明',
      role: '客户经理',
      action: '发布话术模板',
      module: '话术库',
      detail: '发布了新话术模板"基金定投推荐话术"',
      ip: '192.168.1.100',
      time: '2024-01-15 14:30:22',
      type: 'create',
      status: 'success',
    },
    {
      id: 2,
      operator: '李主管',
      role: '客户经理主管',
      action: '审核通过',
      module: '合规审核',
      detail: '审核通过话术模板"理财产品推介话术"',
      ip: '192.168.1.101',
      time: '2024-01-15 13:15:08',
      type: 'audit',
      status: 'success',
    },
    {
      id: 3,
      operator: '王合规',
      role: '合规风控人员',
      action: '驳回审核',
      module: '合规审核',
      detail: '驳回话术模板"股票推荐话术"，原因：存在承诺收益表述',
      ip: '192.168.1.102',
      time: '2024-01-15 11:45:33',
      type: 'audit',
      status: 'reject',
    },
    {
      id: 4,
      operator: '李管理员',
      role: '系统管理员',
      action: '修改权限',
      module: '权限管理',
      detail: '为角色"客户经理"新增"导出客户数据"权限',
      ip: '192.168.1.103',
      time: '2024-01-15 10:20:15',
      type: 'permission',
      status: 'success',
    },
    {
      id: 5,
      operator: '张明',
      role: '客户经理',
      action: '导出数据',
      module: '客户管理',
      detail: '导出了156条客户数据',
      ip: '192.168.1.100',
      time: '2024-01-15 09:30:42',
      type: 'export',
      status: 'success',
    },
    {
      id: 6,
      operator: '陈经理',
      role: '客户经理',
      action: '下架模板',
      module: '话术库',
      detail: '下架了话术模板"产品对比话术"',
      ip: '192.168.1.104',
      time: '2024-01-14 16:55:12',
      type: 'delete',
      status: 'success',
    },
    {
      id: 7,
      operator: '王合规',
      role: '合规风控人员',
      action: '查看日志',
      module: '操作日志',
      detail: '查看了2024年1月的操作日志',
      ip: '192.168.1.102',
      time: '2024-01-14 15:20:30',
      type: 'view',
      status: 'success',
    },
  ];

  const columns = [
    {
      key: 'operator',
      title: '操作人',
      width: '100px',
      render: (value: string, record: any) => (
        <div>
          <div className="font-medium text-gray-900">{value}</div>
          <div className="text-xs text-gray-500">{record.role}</div>
        </div>
      ),
    },
    {
      key: 'action',
      title: '操作类型',
      width: '100px',
      render: (value: string, record: any) => {
        const typeMap: any = {
          create: { color: 'blue', icon: 'ri-add-circle-line' },
          audit: { color: 'purple', icon: 'ri-shield-check-line' },
          permission: { color: 'orange', icon: 'ri-settings-3-line' },
          export: { color: 'green', icon: 'ri-download-line' },
          delete: { color: 'red', icon: 'ri-delete-bin-line' },
          view: { color: 'gray', icon: 'ri-eye-line' },
        };
        const type = typeMap[record.type];
        return (
          <div className="flex items-center gap-2">
            <i className={`${type.icon} text-${type.color}-600 w-4 h-4 flex items-center justify-center`}></i>
            <span className="text-sm text-gray-900">{value}</span>
          </div>
        );
      },
    },
    { key: 'module', title: '功能模块', width: '100px' },
    { key: 'detail', title: '操作详情', width: '300px' },
    { key: 'ip', title: 'IP地址', width: '120px' },
    { key: 'time', title: '操作时间', width: '150px' },
    {
      key: 'status',
      title: '状态',
      width: '80px',
      render: (value: string) => {
        if (value === 'reject') {
          return <StatusTag type="error" label="已驳回" icon="ri-close-circle-line" />;
        }
        return <StatusTag type="success" label="成功" icon="ri-checkbox-circle-line" />;
      },
    },
  ];

  // 操作类型统计
  const typeStats = [
    { type: 'create', label: '创建操作', count: 45, color: 'blue' },
    { type: 'audit', label: '审核操作', count: 32, color: 'purple' },
    { type: 'permission', label: '权限变更', count: 8, color: 'orange' },
    { type: 'export', label: '数据导出', count: 23, color: 'green' },
  ];

  return (
    <MainLayout>
      <PageHeader
        title="操作日志"
        description="查看系统关键操作记录，供合规审计使用"
        breadcrumb={[
          { label: '首页', path: '/' },
          { label: '系统设置', path: '/settings' },
          { label: '账户与权限', path: '/settings/account' },
          { label: '操作日志' },
        ]}
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-filter-3-line">
              筛选
            </Button>
            <Button type="primary" icon="ri-download-line">
              导出日志
            </Button>
          </div>
        }
      />

      <div className="p-6 space-y-6">
        {/* 操作统计 */}
        <div className="grid grid-cols-4 gap-4">
          {typeStats.map((stat) => (
            <div
              key={stat.type}
              className={`bg-white border border-gray-200 rounded-lg p-5 hover:shadow-md transition-all`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">{stat.label}</span>
                <div className={`w-8 h-8 bg-${stat.color}-100 rounded-lg flex items-center justify-center`}>
                  <i className={`ri-file-list-3-line text-${stat.color}-600 w-4 h-4 flex items-center justify-center`}></i>
                </div>
              </div>
              <div className="text-2xl font-semibold text-gray-900">{stat.count}</div>
              <div className="text-xs text-gray-500 mt-1">本周操作次数</div>
            </div>
          ))}
        </div>

        {/* 日志列表 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-gray-900">操作日志列表</h3>
              <p className="text-sm text-gray-500 mt-1">记录所有关键操作，供合规审计使用</p>
            </div>
            <div className="flex items-center gap-3">
              <select 
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer"
              >
                <option value="all">全部类型</option>
                <option value="create">创建操作</option>
                <option value="audit">审核操作</option>
                <option value="permission">权限变更</option>
                <option value="export">数据导出</option>
              </select>
              <select 
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer"
              >
                <option value="today">今天</option>
                <option value="week">本周</option>
                <option value="month">本月</option>
                <option value="custom">自定义</option>
              </select>
            </div>
          </div>
          <div className="p-6">
            <DataTable columns={columns} data={logsData} rowKey="id" />
          </div>
        </div>

        {/* 合规说明 */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-5">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 flex items-center justify-center text-blue-600 flex-shrink-0 mt-0.5">
              <i className="ri-information-line text-lg w-5 h-5 flex items-center justify-center"></i>
            </div>
            <div className="flex-1 text-sm text-blue-900 leading-relaxed">
              <p><strong>日志管理规范：</strong></p>
              <p>• 所有关键操作均被完整记录，不可篡改</p>
              <p>• 日志数据保存至少3年，符合金融监管要求</p>
              <p>• 仅管理员与合规人员可查看完整操作日志</p>
              <p>• 导出日志需经过二次确认并记录导出行为</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
