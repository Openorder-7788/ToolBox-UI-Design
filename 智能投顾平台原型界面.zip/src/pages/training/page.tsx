import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import StatusTag from '../../components/common/StatusTag';
import { trainingScenarios, trainingRecords } from '../../mocks/training';

type TrainingMode = 'script' | 'scenario' | 'assessment' | null;

export default function AITrainingLibrary() {
  const [selectedMode, setSelectedMode] = useState<TrainingMode>(null);
  const [selectedScenario, setSelectedScenario] = useState<any>(null);
  const [isTraining, setIsTraining] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'ai' | 'user'; content: string }>>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [trainingResult, setTrainingResult] = useState<any>(null);

  const modes = [
    {
      id: 'script' as TrainingMode,
      name: '话术练习模式',
      description: '与 AI 虚拟客户进行对话练习，重点训练话术表达与合规性',
      icon: 'ri-message-3-line',
    },
    {
      id: 'scenario' as TrainingMode,
      name: '场景模拟模式',
      description: '基于真实业务场景进行完整沟通流程模拟',
      icon: 'ri-team-line',
    },
    {
      id: 'assessment' as TrainingMode,
      name: '能力评估模式',
      description: '通过标准场景测试沟通能力，并生成能力反馈',
      icon: 'ri-bar-chart-line',
    },
  ];

  const handleStartTraining = (scenario: any) => {
    setSelectedScenario(scenario);
    setIsTraining(true);
    setMessages([
      {
        role: 'ai',
        content: scenario.initialMessage,
      },
    ]);
  };

  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    const newMessages = [...messages, { role: 'user' as const, content: inputMessage }];
    setMessages(newMessages);
    setInputMessage('');

    // 模拟 AI 回应
    setTimeout(() => {
      const aiResponses = [
        '这个我了解了，那具体的服务内容包括哪些呢？',
        '听起来不错，但我比较关心费用方面的问题。',
        '我还有些疑虑，能详细说明一下吗？',
        '谢谢您的介绍，我需要考虑一下。',
      ];
      const randomResponse = aiResponses[Math.floor(Math.random() * aiResponses.length)];
      setMessages([...newMessages, { role: 'ai', content: randomResponse }]);

      // 模拟训练结束
      if (newMessages.length >= 8) {
        setTimeout(() => {
          handleEndTraining();
        }, 1000);
      }
    }, 1000);
  };

  const handleEndTraining = () => {
    setShowResult(true);
    setTrainingResult({
      compliance: 92,
      clarity: 88,
      responsiveness: 85,
      completeness: 90,
      feedback:
        '您的沟通整体表现良好，合规性把握到位。建议在介绍服务权益时可以更加详细，增强客户理解度。',
    });
  };

  const handleBackToScenarios = () => {
    setIsTraining(false);
    setShowResult(false);
    setSelectedScenario(null);
    setMessages([]);
    setTrainingResult(null);
  };

  const handleBackToModes = () => {
    setSelectedMode(null);
    setIsTraining(false);
    setShowResult(false);
    setSelectedScenario(null);
    setMessages([]);
    setTrainingResult(null);
  };

  return (
    <MainLayout>
      <PageHeader
        title="AI 模拟训练库"
        description="用于练习客户沟通与投顾服务介绍的模拟训练环境"
      />

      <div className="p-6 space-y-6">
        {/* 模式选择区 */}
        {!selectedMode && (
          <div>
            <h3 className="text-base font-semibold text-gray-900 mb-4">选择训练模式</h3>
            <div className="grid grid-cols-3 gap-4">
              {modes.map((mode) => (
                <div
                  key={mode.id}
                  className="bg-white border border-gray-200 rounded-lg p-6 hover:border-blue-500 hover:shadow-sm transition-all cursor-pointer"
                  onClick={() => setSelectedMode(mode.id)}
                >
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 flex items-center justify-center bg-blue-50 rounded-lg">
                      <i className={`${mode.icon} text-blue-600 text-xl w-6 h-6 flex items-center justify-center`}></i>
                    </div>
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-gray-900 mb-2">{mode.name}</h4>
                      <p className="text-sm text-gray-600 leading-relaxed">{mode.description}</p>
                      <Button type="primary" size="small" className="mt-4 whitespace-nowrap">
                        进入训练
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 场景选择区 */}
        {selectedMode && !isTraining && !showResult && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-gray-900">选择训练场景</h3>
              <Button type="default" size="small" icon="ri-arrow-left-line" onClick={handleBackToModes}>
                返回模式选择
              </Button>
            </div>

            <div className="bg-white border border-gray-200 rounded-lg divide-y divide-gray-200">
              {trainingScenarios.map((scenario) => (
                <div key={scenario.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-gray-900 mb-3">{scenario.name}</h4>
                      <div className="flex items-center gap-2 flex-wrap">
                        <StatusTag type="info" label={scenario.customerType} />
                        <StatusTag type="default" label={scenario.riskPreference} />
                        <StatusTag type="default" label={scenario.category} />
                      </div>
                      <p className="text-sm text-gray-600 mt-3">{scenario.description}</p>
                    </div>
                    <div className="ml-6">
                      <Button
                        type="primary"
                        size="small"
                        icon="ri-play-line"
                        onClick={() => handleStartTraining(scenario)}
                      >
                        开始训练
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 训练进行中 */}
        {isTraining && !showResult && selectedScenario && (
          <div className="grid grid-cols-3 gap-6">
            {/* 左侧：AI 虚拟客户信息 + 实时提示 */}
            <div className="space-y-6">
              {/* AI 虚拟客户画像 */}
              <div className="bg-white border border-gray-200 rounded-lg p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-blue-50 rounded-full">
                    <i className="ri-user-3-line text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-gray-900">AI 虚拟客户</h4>
                    <p className="text-xs text-gray-500 mt-0.5">模拟对象，仅用于内部训练</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">客户类型</span>
                    <StatusTag type="info" label={selectedScenario.customerType} />
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">风险偏好</span>
                    <StatusTag type="default" label={selectedScenario.riskPreference} />
                  </div>
                  <div className="pt-3 border-t border-gray-200">
                    <p className="text-xs text-gray-600 mb-1">当前沟通目标</p>
                    <p className="text-sm text-gray-900">{selectedScenario.objective}</p>
                  </div>
                </div>
              </div>

              {/* 实时提示与合规提醒 */}
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-5">
                <div className="flex items-start gap-3">
                  <i className="ri-lightbulb-line text-amber-600 w-5 h-5 flex items-center justify-center mt-0.5"></i>
                  <div className="flex-1">
                    <h5 className="text-sm font-semibold text-amber-900 mb-2">训练提示</h5>
                    <div className="space-y-2">
                      <p className="text-xs text-amber-800">
                        <strong>合规提示：</strong>注意避免使用收益承诺类表述
                      </p>
                      <p className="text-xs text-amber-800">
                        <strong>沟通建议：</strong>可更多说明服务流程与专业支持
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* 训练控制 */}
              <div className="bg-white border border-gray-200 rounded-lg p-5">
                <Button
                  type="default"
                  size="small"
                  icon="ri-stop-circle-line"
                  onClick={handleEndTraining}
                  className="w-full"
                >
                  结束训练
                </Button>
                <Button
                  type="default"
                  size="small"
                  icon="ri-arrow-left-line"
                  onClick={handleBackToScenarios}
                  className="w-full mt-2"
                >
                  返回场景选择
                </Button>
              </div>
            </div>

            {/* 右侧：对话模拟区 */}
            <div className="col-span-2 bg-white border border-gray-200 rounded-lg flex flex-col" style={{ height: '700px' }}>
              {/* 对话头部 */}
              <div className="px-5 py-4 border-b border-gray-200">
                <h4 className="text-sm font-semibold text-gray-900">{selectedScenario.name}</h4>
                <p className="text-xs text-gray-500 mt-1">正在进行模拟对话训练</p>
              </div>

              {/* 对话内容区 */}
              <div className="flex-1 overflow-auto p-5 space-y-4">
                {messages.map((msg, index) => (
                  <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] ${msg.role === 'user' ? 'order-2' : 'order-1'}`}>
                      <div
                        className={`px-4 py-3 rounded-lg text-sm ${
                          msg.role === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-900 border border-gray-200'
                        }`}
                      >
                        {msg.content}
                      </div>
                      <p
                        className={`text-xs text-gray-500 mt-1 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}
                      >
                        {msg.role === 'user' ? '您' : 'AI 虚拟客户'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* 输入区 */}
              <div className="px-5 py-4 border-t border-gray-200 bg-gray-50">
                <div className="flex items-end gap-3">
                  <div className="flex-1">
                    <textarea
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      placeholder="输入您的回应内容..."
                      className="w-full px-4 py-3 text-sm text-gray-700 bg-white border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                      rows={3}
                    />
                  </div>
                  <Button type="primary" icon="ri-send-plane-fill" onClick={handleSendMessage}>
                    发送
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2">按 Enter 发送，Shift + Enter 换行</p>
              </div>
            </div>
          </div>
        )}

        {/* 训练结束反馈与评分 */}
        {showResult && trainingResult && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold text-gray-900">训练完成</h3>
              <div className="flex items-center gap-2">
                <Button type="default" size="small" icon="ri-restart-line" onClick={handleBackToScenarios}>
                  重新训练
                </Button>
                <Button type="default" size="small" icon="ri-arrow-left-line" onClick={handleBackToModes}>
                  返回模式选择
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {/* 评分维度 */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-5">能力评分</h4>
                <div className="space-y-4">
                  {[
                    { label: '合规性', value: trainingResult.compliance },
                    { label: '表达清晰度', value: trainingResult.clarity },
                    { label: '客户需求回应度', value: trainingResult.responsiveness },
                    { label: '服务介绍完整性', value: trainingResult.completeness },
                  ].map((item, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-700">{item.label}</span>
                        <span className="text-sm font-semibold text-gray-900">{item.value} 分</span>
                      </div>
                      <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 rounded-full transition-all"
                          style={{ width: `${item.value}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 pt-5 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-gray-900">综合评分</span>
                    <span className="text-2xl font-bold text-blue-600">
                      {Math.round(
                        (trainingResult.compliance +
                          trainingResult.clarity +
                          trainingResult.responsiveness +
                          trainingResult.completeness) /
                          4
                      )}{' '}
                      分
                    </span>
                  </div>
                </div>
              </div>

              {/* 反馈说明 */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h4 className="text-sm font-semibold text-gray-900 mb-4">训练反馈</h4>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <i className="ri-feedback-line text-blue-600 w-5 h-5 flex items-center justify-center mt-0.5"></i>
                    <div className="flex-1">
                      <p className="text-sm text-blue-900 leading-relaxed">{trainingResult.feedback}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 space-y-3">
                  <div className="flex items-start gap-3">
                    <i className="ri-checkbox-circle-line text-green-600 w-5 h-5 flex items-center justify-center mt-0.5"></i>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">表现优秀</p>
                      <p className="text-sm text-gray-600 mt-1">合规性把握到位，表达专业清晰</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <i className="ri-arrow-up-circle-line text-amber-600 w-5 h-5 flex items-center justify-center mt-0.5"></i>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">改进建议</p>
                      <p className="text-sm text-gray-600 mt-1">可以更详细地介绍服务权益内容</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-5 border-t border-gray-200">
                  <p className="text-xs text-gray-500">
                    评分与反馈仅用于能力提升参考，不涉及任何投资效果评价
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 训练记录与能力趋势 */}
        {!selectedMode && (
          <div>
            <h3 className="text-base font-semibold text-gray-900 mb-4">最近训练记录</h3>
            <div className="bg-white border border-gray-200 rounded-lg divide-y divide-gray-200">
              {trainingRecords.map((record) => (
                <div key={record.id} className="p-5 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <h4 className="text-sm font-semibold text-gray-900">{record.scenarioName}</h4>
                        <StatusTag type="info" label={record.mode} />
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-sm text-gray-600">
                        <span>{record.date}</span>
                        <span>•</span>
                        <span>用时 {record.duration}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-6 ml-6">
                      <div className="text-center">
                        <p className="text-xs text-gray-500 mb-1">综合评分</p>
                        <p className="text-lg font-bold text-blue-600">{record.score}</p>
                      </div>
                      <Button type="default" size="small" icon="ri-eye-line">
                        查看详情
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 bg-gray-50 border border-gray-200 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <i className="ri-information-line text-gray-600 w-5 h-5 flex items-center justify-center"></i>
                <p className="text-sm text-gray-600">训练数据仅用于个人能力提升参考</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
