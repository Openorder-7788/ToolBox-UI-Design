import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../../components/layout/MainLayout';
import PageHeader from '../../../../components/common/PageHeader';
import Button from '../../../../components/common/Button';
import FormItem from '../../../../components/common/FormItem';
import Input from '../../../../components/common/Input';
import Select from '../../../../components/common/Select';
import { supervisorDashboardData } from '../../../../mocks/supervisorDashboard';

const CreateTaskPage = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    goal: '',
    description: '',
    startDate: '',
    endDate: '',
    assignedTo: 'all',
    selectedManagers: [] as string[],
    targetCustomerType: '',
    targetCustomers: '',
    recommendedProducts: [] as string[],
    requiredScripts: [] as string[],
    minFollowUps: '',
  });

  const handleSubmit = () => {
    // 验证表单
    if (!formData.name || !formData.goal || !formData.startDate || !formData.endDate || !formData.targetCustomerType) {
      alert('请填写所有必填项');
      return;
    }

    // 提交任务
    alert('任务发布成功！');
    navigate('/supervisor/tasks');
  };

  const customerTypes = [
    { value: '已开户未转化', label: '已开户未转化' },
    { value: '沉睡客户', label: '沉睡客户' },
    { value: '高价值客户', label: '高价值客户' },
    { value: '新开户客户', label: '新开户客户' },
    { value: '活跃客户', label: '活跃客户' },
  ];

  const productOptions = [
    { value: '智投组合A', label: '智投组合A' },
    { value: '稳健理财计划', label: '稳健理财计划' },
    { value: '成长型基金组合', label: '成长型基金组合' },
    { value: '量化策略产品', label: '量化策略产品' },
  ];

  const scriptOptions = [
    { value: '开户邀约话术', label: '开户邀约话术' },
    { value: '产品推荐话术', label: '产品推荐话术' },
    { value: '沉睡客户唤醒话术', label: '沉睡客户唤醒话术' },
    { value: '高价值客户维护话术', label: '高价值客户维护话术' },
  ];

  return (
    <MainLayout>
      <PageHeader
        title="发布新任务"
        description="创建团队运营任务，推动转化提升"
        breadcrumb={[
          { label: '团队管理', path: '/supervisor/dashboard' },
          { label: '任务管理', path: '/supervisor/tasks' },
          { label: '发布新任务' }
        ]}
      />

      <div className="p-6">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white border border-gray-200 rounded-lg p-6 space-y-6">
            {/* 任务基本信息 */}
            <div>
              <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <i className="ri-file-list-3-line text-teal-600"></i>
                任务基本信息
              </h3>
              <div className="space-y-4">
                <FormItem label="任务名称" required>
                  <Input
                    placeholder="请输入任务名称，如：Q1投顾产品推广任务"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </FormItem>

                <FormItem label="任务目标" required>
                  <Select
                    value={formData.goal}
                    onChange={(e) => setFormData({ ...formData, goal: e.target.value })}
                  >
                    <option value="">请选择任务目标</option>
                    <option value="提升开户转化率">提升开户转化率</option>
                    <option value="提升投顾产品购买率">提升投顾产品购买率</option>
                    <option value="唤醒沉睡客户">唤醒沉睡客户</option>
                    <option value="高价值客户深度服务">高价值客户深度服务</option>
                  </Select>
                </FormItem>

                <FormItem label="任务描述">
                  <textarea
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                    rows={3}
                    placeholder="请输入任务描述，说明任务背景和期望达成的效果"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </FormItem>

                <div className="grid grid-cols-2 gap-4">
                  <FormItem label="开始日期" required>
                    <Input
                      type="date"
                      value={formData.startDate}
                      onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    />
                  </FormItem>
                  <FormItem label="结束日期" required>
                    <Input
                      type="date"
                      value={formData.endDate}
                      onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    />
                  </FormItem>
                </div>
              </div>
            </div>

            {/* 任务分配 */}
            <div className="pt-6 border-t border-gray-200">
              <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <i className="ri-user-settings-line text-teal-600"></i>
                任务分配
              </h3>
              <div className="space-y-4">
                <FormItem label="分配对象" required>
                  <div className="space-y-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="assignedTo"
                        value="all"
                        checked={formData.assignedTo === 'all'}
                        onChange={(e) => setFormData({ ...formData, assignedTo: e.target.value, selectedManagers: [] })}
                        className="w-4 h-4 text-teal-600 cursor-pointer"
                      />
                      <span className="text-sm text-gray-700">全体客户经理</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="radio"
                        name="assignedTo"
                        value="selected"
                        checked={formData.assignedTo === 'selected'}
                        onChange={(e) => setFormData({ ...formData, assignedTo: e.target.value })}
                        className="w-4 h-4 text-teal-600 cursor-pointer"
                      />
                      <span className="text-sm text-gray-700">指定客户经理</span>
                    </label>
                  </div>
                </FormItem>

                {formData.assignedTo === 'selected' && (
                  <FormItem label="选择客户经理">
                    <div className="border border-gray-300 rounded-lg p-4 max-h-60 overflow-y-auto">
                      <div className="space-y-2">
                        {supervisorDashboardData.teamMembers.map((member) => (
                          <label key={member.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                            <input
                              type="checkbox"
                              checked={formData.selectedManagers.includes(member.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setFormData({
                                    ...formData,
                                    selectedManagers: [...formData.selectedManagers, member.id]
                                  });
                                } else {
                                  setFormData({
                                    ...formData,
                                    selectedManagers: formData.selectedManagers.filter(id => id !== member.id)
                                  });
                                }
                              }}
                              className="w-4 h-4 text-teal-600 cursor-pointer"
                            />
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-teal-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
                                {member.name.charAt(0)}
                              </div>
                              <div>
                                <div className="text-sm font-medium text-gray-900">{member.name}</div>
                                <div className="text-xs text-gray-500">{member.id}</div>
                              </div>
                            </div>
                          </label>
                        ))}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 mt-2">
                      已选择 {formData.selectedManagers.length} 位客户经理
                    </div>
                  </FormItem>
                )}
              </div>
            </div>

            {/* 目标客户设置 */}
            <div className="pt-6 border-t border-gray-200">
              <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <i className="ri-group-line text-teal-600"></i>
                目标客户设置
              </h3>
              <div className="space-y-4">
                <FormItem label="目标客户类型" required>
                  <Select
                    value={formData.targetCustomerType}
                    onChange={(e) => setFormData({ ...formData, targetCustomerType: e.target.value })}
                  >
                    <option value="">请选择目标客户类型</option>
                    {customerTypes.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </Select>
                </FormItem>

                <FormItem label="目标客户数量">
                  <Input
                    type="number"
                    placeholder="请输入目标客户数量，留空则为全部符合条件的客户"
                    value={formData.targetCustomers}
                    onChange={(e) => setFormData({ ...formData, targetCustomers: e.target.value })}
                  />
                </FormItem>
              </div>
            </div>

            {/* 任务执行规则 */}
            <div className="pt-6 border-t border-gray-200">
              <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <i className="ri-list-check-2 text-teal-600"></i>
                任务执行规则
              </h3>
              <div className="space-y-4">
                <FormItem label="推荐产品">
                  <div className="border border-gray-300 rounded-lg p-4">
                    <div className="space-y-2">
                      {productOptions.map((product) => (
                        <label key={product.value} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                          <input
                            type="checkbox"
                            checked={formData.recommendedProducts.includes(product.value)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFormData({
                                  ...formData,
                                  recommendedProducts: [...formData.recommendedProducts, product.value]
                                });
                              } else {
                                setFormData({
                                  ...formData,
                                  recommendedProducts: formData.recommendedProducts.filter(p => p !== product.value)
                                });
                              }
                            }}
                            className="w-4 h-4 text-teal-600 cursor-pointer"
                          />
                          <span className="text-sm text-gray-700">{product.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    选择需要推荐的投顾产品，客户经理需向目标客户推荐这些产品
                  </div>
                </FormItem>

                <FormItem label="使用话术模板">
                  <div className="border border-gray-300 rounded-lg p-4">
                    <div className="space-y-2">
                      {scriptOptions.map((script) => (
                        <label key={script.value} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                          <input
                            type="checkbox"
                            checked={formData.requiredScripts.includes(script.value)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setFormData({
                                  ...formData,
                                  requiredScripts: [...formData.requiredScripts, script.value]
                                });
                              } else {
                                setFormData({
                                  ...formData,
                                  requiredScripts: formData.requiredScripts.filter(s => s !== script.value)
                                });
                              }
                            }}
                            className="w-4 h-4 text-teal-600 cursor-pointer"
                          />
                          <span className="text-sm text-gray-700">{script.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    选择建议使用的话术模板，帮助客户经理提升沟通效果
                  </div>
                </FormItem>

                <FormItem label="最少跟进次数">
                  <Input
                    type="number"
                    placeholder="请输入每位客户的最少跟进次数，如：3"
                    value={formData.minFollowUps}
                    onChange={(e) => setFormData({ ...formData, minFollowUps: e.target.value })}
                  />
                  <div className="text-xs text-gray-500 mt-2">
                    设置客户经理对每位目标客户的最少跟进次数要求
                  </div>
                </FormItem>
              </div>
            </div>

            {/* 任务说明 */}
            <div className="pt-6 border-t border-gray-200">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <i className="ri-information-line text-blue-600 text-lg mt-0.5"></i>
                  <div className="flex-1">
                    <h4 className="text-sm font-semibold text-blue-900 mb-2">任务说明</h4>
                    <div className="space-y-1 text-xs text-blue-800">
                      <p>• 任务发布后，相关客户经理将收到任务通知</p>
                      <p>• 客户经理可在"我的任务"中查看任务详情和执行进度</p>
                      <p>• 系统将自动追踪任务执行情况，您可随时查看进度</p>
                      <p>• 任务目标为服务推广，不构成投资指令，不强制客户购买</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 操作按钮 */}
            <div className="flex gap-3 pt-6 border-t border-gray-200">
              <Button
                type="primary"
                onClick={handleSubmit}
              >
                <i className="ri-send-plane-line mr-2"></i>
                发布任务
              </Button>
              <Button
                onClick={() => navigate('/supervisor/tasks')}
              >
                取消
              </Button>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CreateTaskPage;
