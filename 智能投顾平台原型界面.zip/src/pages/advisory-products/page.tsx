import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import StatusTag from '../../components/common/StatusTag';
import {
  advisoryProductsData,
  productCategories,
  riskLevelOptions,
  adaptationStageOptions,
} from '../../mocks/advisoryProducts';

export default function AdvisoryProducts() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedRiskLevel, setSelectedRiskLevel] = useState('all');
  const [selectedStage, setSelectedStage] = useState('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<any>(null);

  // 筛选产品
  const filteredProducts = advisoryProductsData.filter((product) => {
    const categoryMatch = selectedCategory === 'all' || product.serviceType === selectedCategory;
    const riskMatch = selectedRiskLevel === 'all' || product.riskLevel === selectedRiskLevel;
    const stageMatch = selectedStage === 'all' || product.adaptationStage === selectedStage;
    const keywordMatch =
      searchKeyword === '' ||
      product.name.includes(searchKeyword) ||
      product.description.includes(searchKeyword) ||
      product.tags.some((tag) => tag.includes(searchKeyword));

    return categoryMatch && riskMatch && stageMatch && keywordMatch;
  });

  // 产品详情弹窗
  const ProductDetailModal = () => {
    if (!selectedProduct) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
        <div className="bg-white rounded-lg w-full max-w-3xl max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">产品详情</h3>
            <button
              onClick={() => setSelectedProduct(null)}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-close-line text-xl w-5 h-5 flex items-center justify-center"></i>
            </button>
          </div>
          <div className="p-6 space-y-6">
            <div>
              <h4 className="text-2xl font-bold text-gray-900 mb-2">{selectedProduct.name}</h4>
              <div className="flex items-center gap-2 mb-4">
                <StatusTag type="info" label={selectedProduct.type} />
                <StatusTag type="default" label={selectedProduct.serviceType} />
                <span className="text-sm text-gray-500">
                  <i className="ri-user-line w-4 h-4 flex items-center justify-center inline-flex mr-1"></i>
                  {selectedProduct.subscriptionCount} 人订阅
                </span>
              </div>
              <p className="text-gray-600 leading-relaxed">{selectedProduct.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">服务形式</div>
                <div className="text-base font-medium text-gray-900">{selectedProduct.serviceForm}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">价格区间</div>
                <div className="text-base font-medium text-gray-900">{selectedProduct.priceRange}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">最低资产要求</div>
                <div className="text-base font-medium text-gray-900">{selectedProduct.minAssets}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">风险等级</div>
                <div className="text-base font-medium text-gray-900">{selectedProduct.riskLevel}</div>
              </div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-700 mb-2">适配客户人群</div>
              <p className="text-gray-600">{selectedProduct.targetCustomer}</p>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-700 mb-3">核心服务特色</div>
              <div className="space-y-2">
                {selectedProduct.features.map((feature: string, index: number) => (
                  <div key={index} className="flex items-start gap-2">
                    <i className="ri-check-line w-5 h-5 flex items-center justify-center text-green-600 mt-0.5"></i>
                    <span className="text-gray-600">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-700 mb-2">产品标签</div>
              <div className="flex flex-wrap gap-2">
                {selectedProduct.tags.map((tag: string, index: number) => (
                  <span key={index} className="px-3 py-1 bg-blue-50 text-blue-600 text-sm rounded-full">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex items-center justify-end gap-3">
            <Button type="default" onClick={() => setSelectedProduct(null)}>
              关闭
            </Button>
            <Button type="primary" icon="ri-user-add-line">
              推荐给客户
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <MainLayout>
      <PageHeader
        title="投顾产品库"
        description="统一管理所有投顾产品，支持按客户画像筛选适配产品"
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line" size="small">
              导出产品清单
            </Button>
            <Button type="primary" icon="ri-refresh-line">
              同步 APP 产品
            </Button>
          </div>
        }
      />

      <div className="p-6">
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* 筛选区域 */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-4 mb-4">
              <div className="flex-1">
                <div className="relative">
                  <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 flex items-center justify-center"></i>
                  <input
                    type="text"
                    placeholder="搜索产品名称、描述或标签..."
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <select
                value={selectedRiskLevel}
                onChange={(e) => setSelectedRiskLevel(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
              >
                {riskLevelOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <select
                value={selectedStage}
                onChange={(e) => setSelectedStage(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
              >
                {adaptationStageOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            {/* 产品分类标签 */}
            <div className="flex items-center gap-2">
              {productCategories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {category.name}
                  <span className="ml-2 opacity-75">({category.count})</span>
                </button>
              ))}
            </div>
          </div>

          {/* 产品列表 */}
          <div className="p-6">
            <div className="mb-4 text-sm text-gray-500">
              共找到 <span className="font-medium text-gray-900">{filteredProducts.length}</span> 个产品
            </div>
            <div className="grid grid-cols-2 gap-4">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  className="border border-gray-200 rounded-lg p-5 hover:shadow-md transition-all bg-gradient-to-br from-white to-gray-50"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="text-base font-semibold text-gray-900 mb-2">{product.name}</h4>
                      <div className="flex items-center gap-2 mb-3">
                        <StatusTag type="info" label={product.type} />
                        <StatusTag
                          type={
                            product.riskLevel === '低'
                              ? 'success'
                              : product.riskLevel === '中'
                              ? 'warning'
                              : 'error'
                          }
                          label={`${product.riskLevel}风险`}
                        />
                        <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
                          {product.adaptationStage}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">服务形式</span>
                      <span className="text-gray-900 font-medium">{product.serviceForm}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">价格区间</span>
                      <span className="text-gray-900 font-medium">{product.priceRange}</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">订阅人数</span>
                      <span className="text-gray-900 font-medium">{product.subscriptionCount} 人</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="text-xs text-gray-500 mb-2">适配客户</div>
                    <div className="text-sm text-gray-700 line-clamp-2">{product.targetCustomer}</div>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {product.tags.map((tag, index) => (
                      <span key={index} className="px-2 py-0.5 bg-blue-50 text-blue-600 text-xs rounded">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setSelectedProduct(product)}
                      className="flex-1 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      查看详情
                    </button>
                    <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                      推荐客户
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 产品详情弹窗 */}
      <ProductDetailModal />
    </MainLayout>
  );
}
