import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MainLayout from '../../../../components/layout/MainLayout';
import Button from '../../../../components/common/Button';
import { openAccountCustomers } from '../../../../mocks/followUpTasks';

// 推荐话术数据
const recommendedScripts = [
  {
    id: 'SCR001',
    title: '开户关怀话术',
    style: '亲和型',
    scene: '开户后服务',
    summary: '您好，我是您的专属客户经理。看到您已经完成开户，我想了解一下您对投资理财方面有什么需求或疑问吗？',
  },
  {
    id: 'SCR002',
    title: '产品服务介绍话术',
    style: '专业型',
    scene: '服务介绍',
    summary: '根据您的风险测评结果，我们有一些适合您的投顾服务。这些服务可以帮助您更好地了解市场...',
  },
];

// 推荐产品数据
const recommendedProducts = [
  {
    id: 'AP001',
    name: '基础投顾服务包',
    type: '入门服务',
    price: '¥299/月',
    reason: '适合刚开户的新客户，提供基础的投资指导和市场分析',
    tags: ['新手友好', '基础服务', '性价比高'],
  },
  {
    id: 'AP003',
    name: '智能投顾体验版',
    type: '智能服务',
    price: '¥599/月',
    reason: 'AI智能推荐，适合希望尝试智能化投资服务的客户',
    tags: ['AI推荐', '自动调仓', '风险监控'],
  },
];

// 推荐投教内容
const recommendedContent = [
  {
    id: 'AC001',
    title: '新手投资入门指南',
    type: '投教图文',
    duration: '8 分钟',
    reason: '帮助新开户客户了解基础投资知识',
  },
  {
    id: 'AC003',
    title: '如何选择适合自己的投顾服务',
    type: '服务说明',
    duration: '10 分钟',
    reason: '帮助客户理解不同投顾服务的区别和价值',
  },
];

const CustomerDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const customer = openAccountCustomers.find((c) => c.id === id);
  
  const [isEditingTags, setIsEditingTags] = useState(false);
  const [managerTags, setManagerTags] = useState(customer?.interests || []);
  const [newTag, setNewTag] = useState('');
  const [showAddNote, setShowAddNote] = useState(false);
  const [noteContent, setNoteContent] = useState('');

  if (!customer) {
    return (
      <MainLayout>
        <div className="p-6">
          <div className="text-center py-12">
            <i className="ri-error-warning-line text-6xl text-gray-300 w-16 h-16 flex items-center justify-center mx-auto mb-4"></i>
            <p className="text-gray-500">客户信息不存在</p>
          </div>
        </div>
      </MainLayout>
    );
  }

  const handleAddTag = () => {
    if (newTag.trim()) {
      setManagerTags([...managerTags, newTag.trim()]);
      setNewTag('');
    }
  };

  const handleRemoveTag = (index: number) => {
    setManagerTags(managerTags.filter((_, i) => i !== index));
  };

  const handleCopyScript = (script: any) => {
    navigator.clipboard.writeText(script.summary);
    alert('话术已复制到剪贴板');
  };

  const handleAddCommunicationNote = () => {
    if (noteContent.trim()) {
      alert('沟通记录已添加');
      setNoteContent('');
      setShowAddNote(false);
    }
  };

  const handleWeChatCommunication = () => {
    navigate(`/wechat-sidebar/customer-info?id=${id}`);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        {/* 1️⃣ 客户基础信息区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white text-2xl font-semibold">
                {customer.name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-semibold text-gray-900">{customer.name}</h1>
                  <span className="px-3 py-1 bg-blue-50 text-blue-700 text-sm font-medium rounded-full">
                    开户后未转化
                  </span>
                  <span className="px-3 py-1 bg-orange-50 text-orange-700 text-sm font-medium rounded-full">
                    {customer.stage}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>客户编号：{customer.id}</span>
                  <span>•</span>
                  <span>开户日期：{customer.openDate}</span>
                  <span>•</span>
                  <span className="text-red-600 font-medium">已开户 {customer.days} 天</span>
                </div>
              </div>
            </div>
            <Button onClick={() => navigate('/follow-up/open-account')}>
              <i className="ri-arrow-left-line mr-2"></i>
              返回列表
            </Button>
          </div>

          <div className="grid grid-cols-4 gap-6 pt-6 border-t border-gray-200">
            <div>
              <div className="text-sm text-gray-500 mb-1">联系电话</div>
              <div className="text-base font-medium text-gray-900">{customer.phone}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">风险偏好</div>
              <div className="text-base font-medium text-gray-900">{customer.riskLevel}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">近期行为</div>
              <div className="text-base font-medium text-blue-600">{customer.recentBehavior}</div>
            </div>
            <div>
              <div className="text-sm text-gray-500 mb-1">浏览时长</div>
              <div className="text-base font-medium text-gray-900">{customer.viewTime}</div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              客户信息仅用于内部服务管理
            </p>
          </div>
        </div>

        {/* 2️⃣ 客户画像与标签区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">客户画像与标签</h2>

          {/* 系统标签 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <h3 className="text-sm font-medium text-gray-700">系统标签</h3>
              <span className="text-xs text-gray-400">(系统生成，只读)</span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-shield-check-line text-lg text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">风险偏好</div>
                  <div className="text-sm font-medium text-gray-900">{customer.riskLevel}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-seedling-line text-lg text-green-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">投资阶段</div>
                  <div className="text-sm font-medium text-gray-900">新手期</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-pulse-line text-lg text-orange-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">生命周期</div>
                  <div className="text-sm font-medium text-gray-900">{customer.stage}</div>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <i className="ri-eye-line text-lg text-purple-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <div className="text-xs text-gray-500">行为标签</div>
                  <div className="text-sm font-medium text-gray-900">{customer.recentBehavior}</div>
                </div>
              </div>
            </div>
          </div>

          {/* 客户经理标签 */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-medium text-gray-700">客户经理标签</h3>
                <span className="text-xs text-gray-400">(可编辑)</span>
              </div>
              <button
                onClick={() => setIsEditingTags(!isEditingTags)}
                className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap"
              >
                {isEditingTags ? '完成编辑' : '编辑标签'}
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {managerTags.map((tag, index) => (
                <span
                  key={index}
                  className="px-3 py-1.5 bg-blue-50 text-blue-700 text-sm rounded-full flex items-center gap-2"
                >
                  {tag}
                  {isEditingTags && (
                    <button
                      onClick={() => handleRemoveTag(index)}
                      className="hover:text-blue-900 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-close-line"></i>
                    </button>
                  )}
                </span>
              ))}
              {isEditingTags && (
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="输入新标签"
                    className="px-3 py-1.5 border border-gray-300 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddTag()}
                  />
                  <button
                    onClick={handleAddTag}
                    className="px-3 py-1.5 bg-blue-600 text-white text-sm rounded-full hover:bg-blue-700 cursor-pointer whitespace-nowrap"
                  >
                    添加
                  </button>
                </div>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-3">
              <i className="ri-information-line mr-1"></i>
              标签编辑行为将记录为操作日志
            </p>
          </div>
        </div>

        {/* 3️⃣ 客户跟进进度管理区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">跟进进度管理</h2>
            <span className="text-sm text-gray-500">当前阶段：已触达</span>
          </div>

          <div className="relative">
            <div className="flex items-center justify-between">
              {[
                { id: 1, name: '已触达', completed: true },
                { id: 2, name: '已沟通', completed: false },
                { id: 3, name: '已推荐服务', completed: false },
                { id: 4, name: '客户考虑中', completed: false },
                { id: 5, name: '已转化', completed: false },
              ].map((stage, index, arr) => (
                <div key={stage.id} className="flex flex-col items-center flex-1">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold mb-2 ${
                      stage.completed
                        ? 'bg-blue-600 text-white'
                        : index === 0
                        ? 'bg-blue-100 text-blue-600 border-2 border-blue-600'
                        : 'bg-gray-100 text-gray-400'
                    }`}
                  >
                    {stage.completed ? <i className="ri-check-line"></i> : stage.id}
                  </div>
                  <div
                    className={`text-sm text-center ${
                      stage.completed || index === 0
                        ? 'text-gray-900 font-medium'
                        : 'text-gray-400'
                    }`}
                  >
                    {stage.name}
                  </div>
                  {index < arr.length - 1 && (
                    <div
                      className={`absolute top-5 h-0.5 ${
                        stage.completed ? 'bg-blue-600' : 'bg-gray-200'
                      }`}
                      style={{
                        left: `${(index / (arr.length - 1)) * 100 + 10}%`,
                        width: `${80 / (arr.length - 1)}%`,
                      }}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              <i className="ri-information-line mr-1"></i>
              进度状态仅用于服务管理参考，客户经理可手动调整当前进度
            </p>
          </div>
        </div>

        {/* 4️⃣ AI 跟进建议区 */}
        <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border border-purple-200 p-6">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
              <i className="ri-sparkling-line text-white text-lg"></i>
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-gray-900 mb-2">AI 跟进建议</h2>
              <p className="text-sm text-gray-600 mb-4">
                基于客户当前状态与行为分析，为您提供以下服务建议
              </p>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 mb-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-2">当前客户状态解读</h3>
            <p className="text-sm text-gray-700 leading-relaxed">
              客户{customer.name}已于{customer.openDate}完成开户，至今已{customer.days}天。
              客户风险偏好为{customer.riskLevel}，近期{customer.recentBehavior}，
              浏览时长{customer.viewTime}，表现出一定的投资兴趣，但尚未使用任何投顾服务。
              建议尽快与客户建立联系，了解其真实需求。
            </p>
          </div>

          <div className="bg-white rounded-lg p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">建议跟进方向</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-1 text-blue-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">主动联系客户</div>
                  <div className="text-sm text-gray-600">
                    通过电话或企业微信与客户建立联系，了解开户后的使用体验和投资需求
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-2 text-blue-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">推荐入门级服务</div>
                  <div className="text-sm text-gray-600">
                    根据客户的风险偏好，推荐适合新手的基础投顾服务或智能投顾体验版
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <i className="ri-number-3 text-blue-600 text-xs"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium text-gray-900 mb-1">提供投教内容</div>
                  <div className="text-sm text-gray-600">
                    发送新手投资入门指南等投教内容，帮助客户建立投资认知
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-purple-100 rounded-lg">
            <p className="text-xs text-purple-800">
              <i className="ri-information-line mr-1"></i>
              以上建议仅为服务辅助提示，不构成投资建议，所有服务推荐需经客户沟通确认
            </p>
          </div>
        </div>

        {/* 5️⃣ 推荐内容区 */}
        <div className="grid grid-cols-3 gap-6">
          {/* A. 推荐话术 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-chat-quote-line text-xl text-blue-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">推荐话术</h2>
            </div>
            <div className="space-y-4">
              {recommendedScripts.map((script) => (
                <div key={script.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-sm font-semibold text-gray-900 flex-1">{script.title}</h3>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">
                      {script.style}
                    </span>
                    <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">
                      {script.scene}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mb-3 line-clamp-2">{script.summary}</p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleCopyScript(script)}
                      className="flex-1 px-3 py-1.5 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-file-copy-line mr-1"></i>
                      复制话术
                    </button>
                    <button
                      onClick={() => navigate('/scripts')}
                      className="px-3 py-1.5 border border-gray-300 text-gray-700 text-xs rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                    >
                      查看详情
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* B. 投顾产品推荐 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-service-line text-xl text-purple-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">产品推荐</h2>
            </div>
            <div className="space-y-4">
              {recommendedProducts.map((product) => (
                <div key={product.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">{product.name}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded">
                      {product.type}
                    </span>
                    <span className="text-xs font-medium text-gray-900">{product.price}</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-3">
                    {product.tags.map((tag, index) => (
                      <span key={index} className="px-2 py-0.5 bg-gray-200 text-gray-600 text-xs rounded">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="p-2 bg-blue-50 rounded mb-3">
                    <p className="text-xs text-blue-800">
                      <i className="ri-lightbulb-line mr-1"></i>
                      推荐理由：{product.reason}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate('/advisory-products')}
                    className="w-full px-3 py-1.5 border border-purple-600 text-purple-600 text-xs rounded hover:bg-purple-50 cursor-pointer whitespace-nowrap"
                  >
                    查看详情
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* C. 投教内容推荐 */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-book-open-line text-xl text-green-600 w-6 h-6 flex items-center justify-center"></i>
              <h2 className="text-lg font-semibold text-gray-900">投教内容</h2>
            </div>
            <div className="space-y-4">
              {recommendedContent.map((content) => (
                <div key={content.id} className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <h3 className="text-sm font-semibold text-gray-900 mb-2">{content.title}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded">
                      {content.type}
                    </span>
                    <span className="text-xs text-gray-500">
                      <i className="ri-time-line mr-1"></i>
                      {content.duration}
                    </span>
                  </div>
                  <div className="p-2 bg-green-50 rounded mb-3">
                    <p className="text-xs text-green-800">
                      <i className="ri-lightbulb-line mr-1"></i>
                      {content.reason}
                    </p>
                  </div>
                  <button
                    onClick={() => navigate('/advisory-content')}
                    className="w-full px-3 py-1.5 border border-green-600 text-green-600 text-xs rounded hover:bg-green-50 cursor-pointer whitespace-nowrap"
                  >
                    查看详情
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 6️⃣ 客户沟通与记录区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">沟通记录</h2>
            <div className="flex gap-2">
              <Button onClick={handleWeChatCommunication}>
                <i className="ri-wechat-line mr-2"></i>
                企业微信沟通
              </Button>
              <Button onClick={() => alert('发起电话')}>
                <i className="ri-phone-line mr-2"></i>
                电话沟通
              </Button>
              <Button onClick={() => setShowAddNote(!showAddNote)}>
                <i className="ri-add-line mr-2"></i>
                添加记录
              </Button>
            </div>
          </div>

          {showAddNote && (
            <div className="mb-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">添加沟通记录</h3>
              <textarea
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                placeholder="请输入沟通内容摘要..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                rows={4}
              />
              <div className="flex justify-end gap-2 mt-3">
                <button
                  onClick={() => setShowAddNote(false)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 text-sm rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                >
                  取消
                </button>
                <button
                  onClick={handleAddCommunicationNote}
                  className="px-4 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 cursor-pointer whitespace-nowrap"
                >
                  保存记录
                </button>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <div className="p-4 border border-gray-200 rounded-lg">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                    <i className="ri-phone-line text-blue-600"></i>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">电话沟通</div>
                    <div className="text-xs text-gray-500">2025-01-14 10:30</div>
                  </div>
                </div>
              </div>
              <p className="text-sm text-gray-700 mb-2 ml-11">首次联系客户，了解开户原因和投资需求，客户表示想先了解一下</p>
              <div className="ml-11 p-2 bg-amber-50 rounded">
                <p className="text-xs text-amber-800">
                  <i className="ri-arrow-right-line mr-1"></i>
                  下一步行动：发送投教内容，3天后回访
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">服务记录</h3>
            <div className="text-center py-8 text-gray-400 text-sm">
              <i className="ri-inbox-line text-4xl mb-2 w-10 h-10 flex items-center justify-center mx-auto"></i>
              暂无服务记录
            </div>
          </div>
        </div>

        {/* 合规提示 */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-blue-600 text-lg flex-shrink-0 mt-0.5"></i>
            <div className="text-sm text-blue-800 space-y-1">
              <p>• 所有分析与推荐仅为服务辅助提示，不构成投资建议或收益承诺</p>
              <p>• 所有服务升级、产品推荐需经客户沟通确认后执行</p>
              <p>• 所有操作将被记录并可追溯，用于合规审计</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CustomerDetailPage;
