import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';

export default function PersonalSettings() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('info');

  const tabs = [
    { id: 'info', label: '个人信息', icon: 'ri-user-line' },
    { id: 'preferences', label: '偏好设置', icon: 'ri-settings-4-line' },
    { id: 'shortcuts', label: '快捷工具', icon: 'ri-star-line' },
    { id: 'history', label: '操作记录', icon: 'ri-history-line' },
  ];

  // 常用工具配置
  const availableTools = [
    { id: 'batch-operation', name: '批量客户运营', icon: 'ri-group-line', added: true },
    { id: 'asset-report', name: '资产诊断报告', icon: 'ri-file-chart-line', added: true },
    { id: 'ai-training', name: 'AI 模拟训练', icon: 'ri-robot-line', added: false },
    { id: 'data-analysis', name: '数据分析看板', icon: 'ri-dashboard-line', added: false },
    { id: 'customer-portrait', name: '客户画像', icon: 'ri-user-search-line', added: true },
    { id: 'compliance-check', name: '合规检测', icon: 'ri-shield-check-line', added: false },
  ];

  return (
    <MainLayout>
      <PageHeader
        title="个人中心"
        description="管理个人信息、偏好设置与操作记录"
        breadcrumb={[
          { label: '首页', path: '/' },
          { label: '系统设置', path: '/settings' },
          { label: '个人中心' },
        ]}
      />

      <div className="p-6">
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* 选项卡 */}
          <div className="border-b border-gray-200 px-6">
            <div className="flex gap-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <i className={`${tab.icon} text-base w-4 h-4 flex items-center justify-center`}></i>
                  <span className="text-sm font-medium">{tab.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 选项卡内容 */}
          <div className="p-6">
            {activeTab === 'info' && (
              <div className="max-w-3xl space-y-6">
                {/* 个人信息展示 */}
                <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-6">
                  <div className="flex items-start gap-4">
                    <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-2xl font-semibold flex-shrink-0">
                      张
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <h4 className="text-xl font-semibold text-gray-900">张明</h4>
                        <span className="px-2.5 py-1 bg-blue-600 text-white text-xs rounded">客户经理</span>
                      </div>
                      <div className="grid grid-cols-2 gap-3 text-sm text-gray-700">
                        <div className="flex items-center gap-2">
                          <i className="ri-building-line w-4 h-4 flex items-center justify-center text-gray-500"></i>
                          <span>营销服务部 · 北京分公司</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <i className="ri-phone-line w-4 h-4 flex items-center justify-center text-gray-500"></i>
                          <span>138****8888</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <i className="ri-mail-line w-4 h-4 flex items-center justify-center text-gray-500"></i>
                          <span>zhangming@securities.com</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <i className="ri-calendar-line w-4 h-4 flex items-center justify-center text-gray-500"></i>
                          <span>入职时间：2020-03-15</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 团队信息 */}
                <div className="border border-gray-200 rounded-lg p-5">
                  <h4 className="text-sm font-semibold text-gray-900 mb-4">团队信息</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center text-purple-600 font-semibold">
                          李
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">李主管</div>
                          <div className="text-xs text-gray-500">直属主管</div>
                        </div>
                      </div>
                      <Button type="text" size="small" icon="ri-message-3-line">
                        联系
                      </Button>
                    </div>
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="text-sm text-gray-700 mb-2">团队成员</div>
                      <div className="flex items-center gap-2">
                        {['王', '陈', '刘', '赵', '周'].map((name, index) => (
                          <div
                            key={index}
                            className="w-8 h-8 bg-gradient-to-br from-gray-400 to-gray-500 rounded-full flex items-center justify-center text-white text-xs font-medium"
                          >
                            {name}
                          </div>
                        ))}
                        <span className="text-xs text-gray-500 ml-1">共 12 人</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'preferences' && (
              <div className="max-w-3xl space-y-6">
                {/* 话术风格偏好 */}
                <div className="border border-gray-200 rounded-lg p-5">
                  <h4 className="text-sm font-semibold text-gray-900 mb-4">默认话术风格</h4>
                  <p className="text-sm text-gray-500 mb-4">选择您偏好的话术风格，系统将优先推荐该风格的话术模板</p>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'professional', name: '专业严谨', desc: '适合高净值客户' },
                      { id: 'friendly', name: '亲和温暖', desc: '适合普通客户' },
                      { id: 'concise', name: '简洁高效', desc: '适合快节奏沟通' },
                    ].map((style) => (
                      <button
                        key={style.id}
                        className="p-4 border-2 border-blue-500 bg-blue-50 rounded-lg text-left hover:shadow-md transition-all cursor-pointer"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-semibold text-gray-900">{style.name}</span>
                          <i className="ri-checkbox-circle-fill text-blue-600 text-lg w-5 h-5 flex items-center justify-center"></i>
                        </div>
                        <div className="text-xs text-gray-500">{style.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* 消息提醒频率 */}
                <div className="border border-gray-200 rounded-lg p-5">
                  <h4 className="text-sm font-semibold text-gray-900 mb-4">消息提醒频率</h4>
                  <p className="text-sm text-gray-500 mb-4">设置系统消息的提醒频率</p>
                  <div className="space-y-3">
                    {[
                      { id: 'high', name: '高频率', desc: '实时接收所有提醒' },
                      { id: 'medium', name: '中频率', desc: '每小时汇总一次（当前）' },
                      { id: 'low', name: '低频率', desc: '每天汇总一次' },
                    ].map((freq, index) => (
                      <label
                        key={freq.id}
                        className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="radio"
                            name="frequency"
                            defaultChecked={index === 1}
                            className="w-4 h-4 text-blue-600 border-gray-300 cursor-pointer"
                          />
                          <div>
                            <div className="text-sm font-medium text-gray-900">{freq.name}</div>
                            <div className="text-xs text-gray-500">{freq.desc}</div>
                          </div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* 保存按钮 */}
                <div className="flex justify-end">
                  <Button type="primary" icon="ri-save-line">
                    保存设置
                  </Button>
                </div>
              </div>
            )}

            {activeTab === 'shortcuts' && (
              <div className="max-w-4xl space-y-6">
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">常用工具收藏</h3>
                  <p className="text-sm text-gray-500">将常用功能添加到快捷入口，提升工作效率</p>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  {availableTools.map((tool) => (
                    <div
                      key={tool.id}
                      className={`border-2 rounded-lg p-5 transition-all ${
                        tool.added
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          tool.added ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'
                        }`}>
                          <i className={`${tool.icon} text-xl w-5 h-5 flex items-center justify-center`}></i>
                        </div>
                        {tool.added && (
                          <i className="ri-star-fill text-amber-500 text-lg w-5 h-5 flex items-center justify-center"></i>
                        )}
                      </div>
                      <div className="text-sm font-semibold text-gray-900 mb-2">{tool.name}</div>
                      <Button
                        type={tool.added ? 'default' : 'primary'}
                        size="small"
                        icon={tool.added ? 'ri-close-line' : 'ri-add-line'}
                      >
                        {tool.added ? '移除' : '添加'}
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'history' && (
              <div>
                <div className="mb-6">
                  <h3 className="text-base font-semibold text-gray-900 mb-1">操作记录</h3>
                  <p className="text-sm text-gray-500">查看您的历史操作记录，仅本人可见</p>
                </div>
                <Button 
                  type="primary" 
                  icon="ri-history-line"
                  onClick={() => navigate('/settings/personal/history')}
                >
                  查看完整记录
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
