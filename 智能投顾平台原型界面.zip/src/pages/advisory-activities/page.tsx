import { useState } from 'react';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import StatusTag from '../../components/common/StatusTag';
import {
  advisoryActivitiesData,
  activityTypeOptions,
  activityStatusOptions,
} from '../../mocks/advisoryActivities';

export default function AdvisoryActivities() {
  const [selectedType, setSelectedType] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedActivity, setSelectedActivity] = useState<any>(null);

  // 筛选活动
  const filteredActivities = advisoryActivitiesData.filter((activity) => {
    const typeMatch = selectedType === 'all' || activity.type === selectedType;
    const statusMatch = selectedStatus === 'all' || activity.status === selectedStatus;
    const keywordMatch =
      searchKeyword === '' ||
      activity.title.includes(searchKeyword) ||
      activity.description.includes(searchKeyword) ||
      activity.targetCustomer.includes(searchKeyword);

    return typeMatch && statusMatch && keywordMatch;
  });

  // 活动详情弹窗
  const ActivityDetailModal = () => {
    if (!selectedActivity) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-6">
        <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">活动详情</h3>
            <button
              onClick={() => setSelectedActivity(null)}
              className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-close-line text-xl w-5 h-5 flex items-center justify-center"></i>
            </button>
          </div>
          <div className="p-6 space-y-6">
            <div>
              <img
                src={selectedActivity.thumbnail}
                alt={selectedActivity.title}
                className="w-full h-64 object-cover object-top rounded-lg mb-4"
              />
              <h4 className="text-2xl font-bold text-gray-900 mb-3">{selectedActivity.title}</h4>
              <div className="flex items-center gap-2 mb-4">
                <StatusTag type="info" label={selectedActivity.type} />
                <StatusTag
                  type={
                    selectedActivity.status === 'upcoming'
                      ? 'warning'
                      : selectedActivity.status === 'ongoing'
                      ? 'success'
                      : 'default'
                  }
                  label={
                    selectedActivity.status === 'upcoming'
                      ? '即将开始'
                      : selectedActivity.status === 'ongoing'
                      ? '进行中'
                      : '已结束'
                  }
                />
              </div>
              <p className="text-gray-600 leading-relaxed text-base">{selectedActivity.description}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">开始时间</div>
                <div className="text-base font-medium text-gray-900">{selectedActivity.startTime}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">结束时间</div>
                <div className="text-base font-medium text-gray-900">{selectedActivity.endTime}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">主讲人</div>
                <div className="text-base font-medium text-gray-900">{selectedActivity.speaker}</div>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="text-sm text-gray-500 mb-1">报名情况</div>
                <div className="text-base font-medium text-gray-900">
                  {selectedActivity.registered} / {selectedActivity.capacity} 人
                </div>
              </div>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="text-sm font-medium text-blue-900 mb-2">
                <i className="ri-user-heart-line w-4 h-4 flex items-center justify-center inline-flex mr-1"></i>
                适配客户人群
              </div>
              <div className="text-sm text-blue-700 mb-3">{selectedActivity.targetCustomer}</div>
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs text-blue-600">客户类型:</span>
                {selectedActivity.customerType.map((type: string, index: number) => (
                  <span key={index} className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">
                    {type}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-blue-600">风险偏好:</span>
                {selectedActivity.riskPreference.map((risk: string, index: number) => (
                  <span key={index} className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">
                    {risk}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <div className="text-sm font-medium text-gray-700 mb-3">活动权益</div>
              <div className="space-y-2">
                {selectedActivity.benefits.map((benefit: string, index: number) => (
                  <div key={index} className="flex items-start gap-2">
                    <i className="ri-gift-line w-5 h-5 flex items-center justify-center text-green-600 mt-0.5"></i>
                    <span className="text-gray-600">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>

            {selectedActivity.relatedProducts && selectedActivity.relatedProducts.length > 0 && (
              <div>
                <div className="text-sm font-medium text-gray-700 mb-3">关联投顾产品</div>
                <div className="space-y-2">
                  {selectedActivity.relatedProducts.map((productId: string) => (
                    <div
                      key={productId}
                      className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
                    >
                      <span className="text-sm text-gray-700">产品编号: {productId}</span>
                      <button className="text-sm text-blue-600 hover:text-blue-700 cursor-pointer whitespace-nowrap">
                        查看产品
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="sticky bottom-0 bg-gray-50 border-t border-gray-200 px-6 py-4 flex items-center justify-end gap-3">
            <Button type="default" onClick={() => setSelectedActivity(null)}>
              关闭
            </Button>
            <Button type="default" icon="ri-download-line">
              导出参与名单
            </Button>
            <Button type="primary" icon="ri-user-add-line">
              邀约客户参加
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <MainLayout>
      <PageHeader
        title="投顾活动中心"
        description="统一管理投顾类活动，支持向客户邀约与跟进参与情况"
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-calendar-line" size="small">
              查看活动日历
            </Button>
            <Button type="primary" icon="ri-add-line">
              创建新活动
            </Button>
          </div>
        }
      />

      <div className="p-6">
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* 筛选区域 */}
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="relative">
                  <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5 flex items-center justify-center"></i>
                  <input
                    type="text"
                    placeholder="搜索活动名称、描述或适配人群..."
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
              >
                {activityTypeOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white text-gray-700 cursor-pointer"
              >
                {activityStatusOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* 活动列表 */}
          <div className="p-6">
            <div className="mb-4 text-sm text-gray-500">
              共找到 <span className="font-medium text-gray-900">{filteredActivities.length}</span> 个活动
            </div>
            <div className="grid grid-cols-2 gap-4">
              {filteredActivities.map((activity) => (
                <div
                  key={activity.id}
                  className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-all bg-white"
                >
                  {/* 活动缩略图 */}
                  <div className="w-full h-40">
                    <img
                      src={activity.thumbnail}
                      alt={activity.title}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>

                  <div className="p-5">
                    <div className="flex items-start justify-between mb-3">
                      <h4 className="text-base font-semibold text-gray-900 flex-1 pr-2">{activity.title}</h4>
                      <StatusTag
                        type={
                          activity.status === 'upcoming'
                            ? 'warning'
                            : activity.status === 'ongoing'
                            ? 'success'
                            : 'default'
                        }
                        label={
                          activity.status === 'upcoming'
                            ? '即将开始'
                            : activity.status === 'ongoing'
                            ? '进行中'
                            : '已结束'
                        }
                      />
                    </div>

                    <div className="flex items-center gap-2 mb-3">
                      <StatusTag type="info" label={activity.type} />
                    </div>

                    <p className="text-sm text-gray-600 mb-4 line-clamp-2 leading-relaxed">
                      {activity.description}
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <i className="ri-calendar-line w-4 h-4 flex items-center justify-center text-gray-400"></i>
                        <span>{activity.startTime}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <i className="ri-user-line w-4 h-4 flex items-center justify-center text-gray-400"></i>
                        <span>{activity.speaker}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <i className="ri-group-line w-4 h-4 flex items-center justify-center text-gray-400"></i>
                        <span>
                          已报名 {activity.registered} / {activity.capacity} 人
                        </span>
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden ml-2">
                          <div
                            className="h-full bg-blue-600 rounded-full"
                            style={{ width: `${(activity.registered / activity.capacity) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedActivity(activity)}
                        className="flex-1 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        查看详情
                      </button>
                      <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                        邀约客户
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 活动详情弹窗 */}
      <ActivityDetailModal />
    </MainLayout>
  );
}
