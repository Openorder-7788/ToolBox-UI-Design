import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';
import { supervisorTasksData } from '../../../mocks/supervisorTasks';

const SupervisorTasksPage = () => {
  const navigate = useNavigate();
  const [selectedTab, setSelectedTab] = useState<'active' | 'completed'>('active');
  const [selectedTask, setSelectedTask] = useState<string | null>(null);

  const { activeTasks, completedTasks } = supervisorTasksData;

  const currentTasks = selectedTab === 'active' ? activeTasks : completedTasks;

  // 获取任务详情
  const getTaskDetail = (taskId: string) => {
    return [...activeTasks, ...completedTasks].find(task => task.id === taskId);
  };

  const taskDetail = selectedTask ? getTaskDetail(selectedTask) : null;

  return (
    <MainLayout>
      <PageHeader
        title="团队任务管理"
        description="发布运营任务，推动团队转化提升"
        breadcrumb={[
          { label: '团队管理', path: '/supervisor/dashboard' },
          { label: '任务管理' }
        ]}
        actions={
          <Button 
            type="primary" 
            icon="ri-add-line"
            onClick={() => navigate('/supervisor/tasks/create')}
          >
            发布新任务
          </Button>
        }
      />

      <div className="p-6 space-y-6">
        {/* 任务列表区 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          {/* Tab 切换 */}
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSelectedTab('active')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  selectedTab === 'active'
                    ? 'bg-teal-50 text-teal-700 border border-teal-200'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                进行中任务 ({activeTasks.length})
              </button>
              <button
                onClick={() => setSelectedTab('completed')}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  selectedTab === 'completed'
                    ? 'bg-teal-50 text-teal-700 border border-teal-200'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                已完成任务 ({completedTasks.length})
              </button>
            </div>
          </div>

          {/* 任务列表 */}
          <div className="p-6">
            <div className="space-y-4">
              {currentTasks.map((task) => (
                <div
                  key={task.id}
                  onClick={() => setSelectedTask(task.id)}
                  className={`p-5 rounded-lg border-2 transition-all cursor-pointer ${
                    selectedTask === task.id
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-gray-200 hover:border-gray-300 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-base font-semibold text-gray-900">{task.name}</h3>
                        {task.status === 'active' && (
                          <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                            进行中
                          </span>
                        )}
                        {task.status === 'completed' && (
                          <span className="px-2 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full">
                            已完成
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{task.description}</p>
                      <div className="flex items-center gap-6 text-xs text-gray-500">
                        <span>
                          <i className="ri-calendar-line mr-1"></i>
                          {task.startDate} - {task.endDate}
                        </span>
                        <span>
                          <i className="ri-user-line mr-1"></i>
                          {task.assignedTo === 'all' ? '全体客户经理' : `${task.assignedManagers?.length || 0}位客户经理`}
                        </span>
                        <span>
                          <i className="ri-group-line mr-1"></i>
                          {task.targetCustomerType}
                        </span>
                      </div>
                    </div>
                    <div className="text-right ml-4">
                      <div className="text-2xl font-bold text-teal-600 mb-1">
                        {task.progress.completionRate}%
                      </div>
                      <div className="text-xs text-gray-500">完成率</div>
                    </div>
                  </div>

                  {/* 进度条 */}
                  <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
                    <div
                      className="h-2 rounded-full bg-gradient-to-r from-teal-500 to-teal-600 transition-all"
                      style={{ width: `${task.progress.completionRate}%` }}
                    ></div>
                  </div>

                  {/* 关键指标 */}
                  <div className="grid grid-cols-4 gap-4">
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <div className="text-lg font-semibold text-gray-900">
                        {task.progress.executedCustomers}/{task.progress.targetCustomers}
                      </div>
                      <div className="text-xs text-gray-500">已执行客户</div>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <div className="text-lg font-semibold text-gray-900">
                        {task.progress.recommendations}
                      </div>
                      <div className="text-xs text-gray-500">推荐次数</div>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <div className="text-lg font-semibold text-gray-900">
                        {task.progress.conversions}
                      </div>
                      <div className="text-xs text-gray-500">成交次数</div>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <div className="text-lg font-semibold text-teal-600">
                        {task.progress.conversionRate}%
                      </div>
                      <div className="text-xs text-gray-500">转化率</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 任务详情区 */}
        {taskDetail && (
          <div className="bg-white border border-gray-200 rounded-lg">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-base font-semibold text-gray-900">任务详情</h3>
            </div>
            <div className="p-6 space-y-6">
              {/* 任务基本信息 */}
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-3">任务基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-gray-500 mb-1">任务名称</div>
                    <div className="text-sm font-medium text-gray-900">{taskDetail.name}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-gray-500 mb-1">任务目标</div>
                    <div className="text-sm font-medium text-gray-900">{taskDetail.goal}</div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-gray-500 mb-1">任务周期</div>
                    <div className="text-sm font-medium text-gray-900">
                      {taskDetail.startDate} - {taskDetail.endDate}
                    </div>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="text-xs text-gray-500 mb-1">目标客户类型</div>
                    <div className="text-sm font-medium text-gray-900">{taskDetail.targetCustomerType}</div>
                  </div>
                </div>
              </div>

              {/* 任务执行规则 */}
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-3">任务执行规则</h4>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="space-y-2">
                    {taskDetail.rules.map((rule, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <i className="ri-checkbox-circle-line text-blue-600 text-sm mt-0.5 w-4 h-4 flex items-center justify-center"></i>
                        <span className="text-sm text-blue-900">{rule}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 任务执行进度追踪 */}
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-3">任务执行进度追踪</h4>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          客户经理
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                          已执行客户数
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                          推荐次数
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                          成交次数
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                          转化率
                        </th>
                        <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase">
                          完成度
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {taskDetail.executionTracking.map((tracking) => (
                        <tr key={tracking.managerId} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-teal-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
                                {tracking.managerName.charAt(0)}
                              </div>
                              <div>
                                <div className="text-sm font-medium text-gray-900">{tracking.managerName}</div>
                                <div className="text-xs text-gray-500">{tracking.managerId}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className="text-sm font-medium text-gray-900">
                              {tracking.executedCustomers}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className="text-sm font-medium text-gray-900">
                              {tracking.recommendations}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className="text-sm font-medium text-gray-900">
                              {tracking.conversions}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <span className="text-sm font-semibold text-teal-600">
                              {tracking.conversionRate}%
                            </span>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <div className="flex flex-col items-center gap-1">
                              <span className="text-sm font-semibold text-gray-900">
                                {tracking.completionRate}%
                              </span>
                              <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-gradient-to-r from-teal-500 to-teal-600 rounded-full"
                                  style={{ width: `${tracking.completionRate}%` }}
                                ></div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 任务效果评估 */}
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-3">任务效果评估</h4>
                <div className="grid grid-cols-3 gap-4">
                  {/* 转化率变化 */}
                  <div className="p-4 bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-10 h-10 bg-green-600 rounded-lg flex items-center justify-center">
                        <i className="ri-arrow-up-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 mb-1">转化率变化</div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold text-gray-900">
                        {taskDetail.effectiveness.conversionRateChange}
                      </span>
                      <span className="text-xs text-green-600 font-medium">
                        {parseFloat(taskDetail.effectiveness.conversionRateChange) > 0 ? '↑' : '↓'}
                      </span>
                    </div>
                  </div>

                  {/* 产品成交提升 */}
                  <div className="p-4 bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                        <i className="ri-shopping-cart-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 mb-1">产品成交提升</div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold text-gray-900">
                        {taskDetail.effectiveness.dealIncrease}
                      </span>
                      <span className="text-xs text-blue-600 font-medium">
                        {parseFloat(taskDetail.effectiveness.dealIncrease) > 0 ? '↑' : '↓'}
                      </span>
                    </div>
                  </div>

                  {/* 高表现客户经理 */}
                  <div className="p-4 bg-gradient-to-br from-amber-50 to-amber-100 border border-amber-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-10 h-10 bg-amber-600 rounded-lg flex items-center justify-center">
                        <i className="ri-trophy-line text-white text-xl w-5 h-5 flex items-center justify-center"></i>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 mb-1">高表现客户经理</div>
                    <div className="text-sm font-medium text-gray-900">
                      {taskDetail.effectiveness.topPerformers.join('、')}
                    </div>
                  </div>
                </div>
              </div>

              {/* 操作按钮 */}
              <div className="flex gap-3 pt-4 border-t border-gray-200">
                {taskDetail.status === 'active' && (
                  <>
                    <Button
                      type="primary"
                      onClick={() => alert('编辑任务功能开发中')}
                    >
                      <i className="ri-edit-line mr-2"></i>
                      编辑任务
                    </Button>
                    <Button
                      onClick={() => alert('结束任务功能开发中')}
                    >
                      <i className="ri-check-line mr-2"></i>
                      结束任务
                    </Button>
                  </>
                )}
                <Button
                  onClick={() => alert('导出报告功能开发中')}
                >
                  <i className="ri-download-line mr-2"></i>
                  导出报告
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* 快速操作提示 */}
        <div className="bg-gradient-to-r from-teal-50 to-blue-50 border border-teal-200 rounded-lg p-5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-teal-600 flex items-center justify-center flex-shrink-0">
              <i className="ri-lightbulb-line text-white text-lg"></i>
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-900 mb-2">任务管理建议</h4>
              <div className="space-y-1 text-sm text-gray-700">
                <p>• 任务目标应明确、可量化，便于追踪执行效果</p>
                <p>• 建议根据团队转化瓶颈环节设计针对性任务</p>
                <p>• 任务周期建议设置为1-2周，保持团队执行节奏</p>
                <p>• 定期查看任务执行进度，及时调整策略</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default SupervisorTasksPage;
