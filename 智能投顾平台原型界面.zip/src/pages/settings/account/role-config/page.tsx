import { useState } from 'react';
import MainLayout from '../../../../components/layout/MainLayout';
import PageHeader from '../../../../components/common/PageHeader';
import Button from '../../../../components/common/Button';
import DataTable from '../../../../components/common/DataTable';
import StatusTag from '../../../../components/common/StatusTag';

export default function RoleConfig() {
  const [selectedRole, setSelectedRole] = useState('manager');

  // 角色列表
  const roles = [
    { id: 'manager', name: '客户经理', count: 156, color: 'blue' },
    { id: 'supervisor', name: '客户经理主管', count: 12, color: 'purple' },
    { id: 'compliance', name: '合规风控人员', count: 8, color: 'green' },
    { id: 'admin', name: '系统管理员', count: 3, color: 'red' },
  ];

  // 功能模块权限配置
  const modulePermissions = [
    {
      module: '客户管理',
      manager: { view: true, edit: true, delete: false, export: true },
      supervisor: { view: true, edit: true, delete: true, export: true },
      compliance: { view: true, edit: false, delete: false, export: true },
    },
    {
      module: '话术库',
      manager: { view: true, edit: false, delete: false, export: false },
      supervisor: { view: true, edit: true, delete: false, export: true },
      compliance: { view: true, edit: false, delete: false, export: false },
    },
    {
      module: '营销活动',
      manager: { view: true, edit: true, delete: false, export: true },
      supervisor: { view: true, edit: true, delete: true, export: true },
      compliance: { view: true, edit: false, delete: false, export: true },
    },
    {
      module: '业绩数据',
      manager: { view: true, edit: false, delete: false, export: true },
      supervisor: { view: true, edit: true, delete: false, export: true },
      compliance: { view: true, edit: false, delete: false, export: true },
    },
    {
      module: '系统设置',
      manager: { view: true, edit: true, delete: false, export: false },
      supervisor: { view: true, edit: true, delete: false, export: false },
      compliance: { view: true, edit: false, delete: false, export: false },
    },
  ];

  // 权限变更记录
  const changeRecords = [
    {
      id: 1,
      operator: '李管理员',
      role: '客户经理',
      action: '新增导出权限',
      module: '客户管理',
      time: '2024-01-15 14:30:22',
      status: 'success',
    },
    {
      id: 2,
      operator: '王管理员',
      role: '合规风控人员',
      action: '新增查看权限',
      module: '操作日志',
      time: '2024-01-14 10:15:08',
      status: 'success',
    },
    {
      id: 3,
      operator: '李管理员',
      role: '客户经理主管',
      action: '新增删除权限',
      module: '客户管理',
      time: '2024-01-13 16:45:33',
      status: 'success',
    },
  ];

  const columns = [
    { key: 'operator', title: '操作人', width: '100px' },
    { key: 'role', title: '角色', width: '120px' },
    { key: 'action', title: '操作内容', width: '150px' },
    { key: 'module', title: '功能模块', width: '100px' },
    { key: 'time', title: '操作时间', width: '150px' },
    {
      key: 'status',
      title: '状态',
      width: '80px',
      render: (value: string) => (
        <StatusTag type="success" label="已生效" icon="ri-checkbox-circle-line" />
      ),
    },
  ];

  return (
    <MainLayout>
      <PageHeader
        title="角色权限配置"
        description="管理不同角色的功能模块与操作权限"
        breadcrumb={[
          { label: '首页', path: '/' },
          { label: '系统设置', path: '/settings' },
          { label: '账户与权限', path: '/settings/account' },
          { label: '角色权限配置' },
        ]}
        actions={
          <Button type="primary" icon="ri-save-line">
            保存配置
          </Button>
        }
      />

      <div className="p-6 space-y-6">
        {/* 角色选择 */}
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-4">选择角色</h3>
          <div className="grid grid-cols-4 gap-4">
            {roles.map((role) => (
              <button
                key={role.id}
                onClick={() => setSelectedRole(role.id)}
                className={`p-4 border-2 rounded-lg transition-all cursor-pointer text-left ${
                  selectedRole === role.id
                    ? `border-${role.color}-500 bg-${role.color}-50`
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-gray-900">{role.name}</span>
                  {selectedRole === role.id && (
                    <i className={`ri-checkbox-circle-fill text-${role.color}-600 text-lg w-5 h-5 flex items-center justify-center`}></i>
                  )}
                </div>
                <div className="text-xs text-gray-500">当前 {role.count} 人</div>
              </button>
            ))}
          </div>
        </div>

        {/* 权限配置表 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-base font-semibold text-gray-900">功能模块权限</h3>
            <p className="text-sm text-gray-500 mt-1">
              当前配置角色：<span className="font-medium text-gray-900">{roles.find(r => r.id === selectedRole)?.name}</span>
            </p>
          </div>
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 text-sm font-semibold text-gray-900">功能模块</th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-900">查看</th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-900">编辑</th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-900">删除</th>
                    <th className="text-center py-3 px-4 text-sm font-semibold text-gray-900">导出</th>
                  </tr>
                </thead>
                <tbody>
                  {modulePermissions.map((item, index) => {
                    const permissions = item[selectedRole as keyof typeof item] as any;
                    return (
                      <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-3 px-4 text-sm text-gray-900">{item.module}</td>
                        <td className="py-3 px-4 text-center">
                          <input
                            type="checkbox"
                            checked={permissions?.view || false}
                            className="w-4 h-4 text-blue-600 border-gray-300 rounded cursor-pointer"
                            readOnly
                          />
                        </td>
                        <td className="py-3 px-4 text-center">
                          <input
                            type="checkbox"
                            checked={permissions?.edit || false}
                            className="w-4 h-4 text-blue-600 border-gray-300 rounded cursor-pointer"
                            readOnly
                          />
                        </td>
                        <td className="py-3 px-4 text-center">
                          <input
                            type="checkbox"
                            checked={permissions?.delete || false}
                            className="w-4 h-4 text-blue-600 border-gray-300 rounded cursor-pointer"
                            readOnly
                          />
                        </td>
                        <td className="py-3 px-4 text-center">
                          <input
                            type="checkbox"
                            checked={permissions?.export || false}
                            className="w-4 h-4 text-blue-600 border-gray-300 rounded cursor-pointer"
                            readOnly
                          />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* 权限变更记录 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-base font-semibold text-gray-900">权限变更记录</h3>
            <p className="text-sm text-gray-500 mt-1">最近的权限配置变更操作</p>
          </div>
          <div className="p-6">
            <DataTable columns={columns} data={changeRecords} rowKey="id" />
          </div>
        </div>

        {/* 合规提示 */}
        <div className="bg-red-50 border border-red-200 rounded-lg p-5">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 flex items-center justify-center text-red-600 flex-shrink-0 mt-0.5">
              <i className="ri-error-warning-line text-lg w-5 h-5 flex items-center justify-center"></i>
            </div>
            <div className="flex-1 text-sm text-red-900 leading-relaxed">
              <p><strong>重要提示：</strong></p>
              <p>• 权限配置变更将立即生效，请谨慎操作</p>
              <p>• 所有变更操作将被记录并可供合规审计</p>
              <p>• 不允许通过权限配置绕过合规审核流程</p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
