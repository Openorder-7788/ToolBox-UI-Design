import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../components/layout/MainLayout';
import PageHeader from '../../components/common/PageHeader';
import Button from '../../components/common/Button';
import DataTable from '../../components/common/DataTable';
import StatusTag from '../../components/common/StatusTag';
import Input from '../../components/common/Input';
import Select from '../../components/common/Select';
import { customersData } from '../../mocks/customers';

const CustomersPage = () => {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const statusOptions = [
    { label: '全部状态', value: 'all' },
    { label: '正常', value: 'active' },
    { label: '待跟进', value: 'pending' },
    { label: '未激活', value: 'inactive' },
  ];

  // 客户跟进模块数据
  const followUpModules = [
    {
      id: 1,
      title: '开户后未转化',
      count: 36,
      description: '已开户但尚未使用投顾服务的客户',
      icon: 'ri-user-add-line',
      path: '/follow-up/open-account',
      color: 'from-blue-50 to-blue-100',
      borderColor: 'border-blue-200',
      iconBg: 'bg-blue-600',
    },
    {
      id: 2,
      title: '高价值客户待服务升级',
      count: 24,
      description: '当前服务层级与潜在服务不匹配的客户',
      icon: 'ri-vip-crown-line',
      path: '/follow-up/high-value',
      color: 'from-purple-50 to-purple-100',
      borderColor: 'border-purple-200',
      iconBg: 'bg-purple-600',
    },
    {
      id: 3,
      title: '行为触发待跟进',
      count: 12,
      description: '近期存在明显行为信号的客户',
      icon: 'ri-flashlight-line',
      path: '/follow-up/behavior',
      color: 'from-green-50 to-green-100',
      borderColor: 'border-green-200',
      iconBg: 'bg-green-600',
    },
    {
      id: 4,
      title: '沉睡客户待唤醒',
      count: 7,
      description: '长时间未互动的客户',
      icon: 'ri-time-line',
      path: '/follow-up/sleeping',
      color: 'from-orange-50 to-orange-100',
      borderColor: 'border-orange-200',
      iconBg: 'bg-orange-600',
    },
  ];

  const columns = [
    {
      key: 'name',
      title: '客户姓名',
      width: '120px',
      render: (value: string, record: any) => (
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
            {value.charAt(0)}
          </div>
          <div>
            <div className="font-medium text-gray-900">{value}</div>
            <div className="text-xs text-gray-500">{record.id}</div>
          </div>
        </div>
      ),
    },
    {
      key: 'phone',
      title: '联系方式',
      width: '120px',
    },
    {
      key: 'assets',
      title: '资产规模',
      width: '100px',
      render: (value: string) => <span className="font-medium text-gray-900">{value}</span>,
    },
    {
      key: 'riskLevel',
      title: '风险等级',
      width: '100px',
      render: (value: string) => {
        const typeMap: any = {
          保守型: 'default',
          稳健型: 'info',
          平衡型: 'warning',
          积极型: 'error',
        };
        return <StatusTag type={typeMap[value] || 'default'} label={value} />;
      },
    },
    {
      key: 'status',
      title: '状态',
      width: '90px',
      render: (value: string) => {
        const statusMap: any = {
          active: { type: 'success', label: '正常', icon: 'ri-checkbox-circle-line' },
          pending: { type: 'warning', label: '待跟进', icon: 'ri-time-line' },
          inactive: { type: 'default', label: '未激活', icon: 'ri-close-circle-line' },
        };
        const status = statusMap[value];
        return <StatusTag type={status.type} label={status.label} icon={status.icon} />;
      },
    },
    {
      key: 'lastContact',
      title: '最近联系',
      width: '100px',
      render: (value: string) => <span className="text-gray-600">{value}</span>,
    },
    {
      key: 'nextFollowUp',
      title: '下次跟进',
      width: '100px',
      render: (value: string) => <span className="text-gray-600">{value}</span>,
    },
    {
      key: 'assignedTo',
      title: '负责人',
      width: '90px',
      render: (value: string) => <span className="text-gray-600">{value}</span>,
    },
    {
      key: 'tags',
      title: '标签',
      width: '150px',
      render: (value: string[]) => (
        <div className="flex gap-1.5 flex-wrap">
          {value.map((tag, index) => (
            <span key={index} className="px-2 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
              {tag}
            </span>
          ))}
        </div>
      ),
    },
    {
      key: 'actions',
      title: '操作',
      width: '150px',
      align: 'center' as const,
      render: (_: any, record: any) => (
        <div className="flex items-center justify-center gap-2">
          <button 
            onClick={() => navigate(`/customers/${record.id}`)}
            className="text-blue-600 hover:text-blue-700 text-sm cursor-pointer whitespace-nowrap"
          >
            详情
          </button>
          <span className="text-gray-300">|</span>
          <button className="text-blue-600 hover:text-blue-700 text-sm cursor-pointer whitespace-nowrap">
            跟进
          </button>
          <span className="text-gray-300">|</span>
          <button className="text-gray-600 hover:text-gray-700 text-sm cursor-pointer whitespace-nowrap">
            编辑
          </button>
        </div>
      ),
    },
  ];

  const filteredData = customersData.filter((item) => {
    const matchSearch = item.name.includes(searchText) || item.phone.includes(searchText);
    const matchStatus = filterStatus === 'all' || item.status === filterStatus;
    return matchSearch && matchStatus;
  });

  return (
    <MainLayout>
      <PageHeader
        title="客户管理"
        description="统一管理不同阶段与行为状态的客户"
        breadcrumb={[{ label: '首页', path: '/' }, { label: '客户管理' }]}
        actions={
          <>
            <Button type="default" icon="ri-upload-line">
              导入
            </Button>
            <Button type="primary" icon="ri-user-add-line">
              新增客户
            </Button>
          </>
        }
      />

      <div className="p-6">
        {/* 客户总览数据 */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {[
            { label: '总客户数', value: '248', icon: 'ri-team-line', color: 'text-blue-600' },
            { label: '高净值客户', value: '45', icon: 'ri-vip-crown-line', color: 'text-purple-600' },
            { label: '本月新增', value: '32', icon: 'ri-user-add-line', color: 'text-green-600' },
            { label: '待跟进', value: '79', icon: 'ri-notification-3-line', color: 'text-orange-600' },
          ].map((stat, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-gray-500 mb-1">{stat.label}</div>
                  <div className="text-2xl font-semibold text-gray-900">{stat.value}</div>
                </div>
                <div className={`w-10 h-10 bg-gray-50 rounded-lg flex items-center justify-center ${stat.color}`}>
                  <i className={`${stat.icon} text-xl w-5 h-5 flex items-center justify-center`}></i>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* 客户跟进模块入口 */}
        <div className="bg-white border border-gray-200 rounded-lg mb-6">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-gray-900">客户跟进模块</h3>
                <p className="text-sm text-gray-500 mt-0.5">按客户阶段与行为特征分类管理</p>
              </div>
              <div className="text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded">
                以下内容仅为服务提示,不构成投资建议
              </div>
            </div>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-4 gap-4">
              {followUpModules.map((module) => (
                <button
                  key={module.id}
                  onClick={() => navigate(module.path)}
                  className={`bg-gradient-to-br ${module.color} border ${module.borderColor} rounded-lg p-5 hover:shadow-md transition-all cursor-pointer text-left`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-10 h-10 ${module.iconBg} rounded-lg flex items-center justify-center`}>
                      <i className={`${module.icon} text-white text-xl w-5 h-5 flex items-center justify-center`}></i>
                    </div>
                    <div className="text-2xl font-bold text-gray-900">{module.count}</div>
                  </div>
                  <div className="text-sm font-semibold text-gray-900 mb-2">{module.title}</div>
                  <div className="text-xs text-gray-600 leading-relaxed">{module.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 筛选区域 */}
        <div className="bg-white border border-gray-200 rounded-lg p-5 mb-6">
          <div className="grid grid-cols-4 gap-4">
            <div>
              <Input
                placeholder="搜索客户姓名或手机号"
                prefix="ri-search-line"
                value={searchText}
                onChange={setSearchText}
              />
            </div>
            <div>
              <Select options={statusOptions} value={filterStatus} onChange={(v) => setFilterStatus(v as string)} />
            </div>
            <div>
              <Select
                options={[
                  { label: '全部风险等级', value: 'all' },
                  { label: '保守型', value: 'conservative' },
                  { label: '稳健型', value: 'stable' },
                  { label: '平衡型', value: 'balanced' },
                  { label: '积极型', value: 'aggressive' },
                ]}
                placeholder="风险等级"
              />
            </div>
            <div className="flex gap-2">
              <Button type="primary" icon="ri-search-line" className="flex-1">
                查询
              </Button>
              <Button type="default" icon="ri-refresh-line">
                重置
              </Button>
            </div>
          </div>
        </div>

        {/* 客户列表 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-gray-900">客户列表</h3>
              <p className="text-sm text-gray-500 mt-0.5">共找到 {filteredData.length} 条记录</p>
            </div>
            <div className="flex items-center gap-3">
              <Button type="default" size="small" icon="ri-download-line">
                导出数据
              </Button>
              <Button type="default" size="small" icon="ri-settings-3-line">
                列设置
              </Button>
            </div>
          </div>
          <div className="p-6">
            <DataTable columns={columns} data={filteredData} />
          </div>
          {/* 分页 */}
          <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
            <div className="text-sm text-gray-500">显示第 1 - {filteredData.length} 条，共 {filteredData.length} 条</div>
            <div className="flex items-center gap-2">
              <button className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 hover:bg-gray-50 cursor-pointer whitespace-nowrap">
                上一页
              </button>
              <button className="px-3 py-1.5 text-sm border border-blue-600 bg-blue-600 rounded-md text-white cursor-pointer whitespace-nowrap">
                1
              </button>
              <button className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 hover:bg-gray-50 cursor-pointer whitespace-nowrap">
                2
              </button>
              <button className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 hover:bg-gray-50 cursor-pointer whitespace-nowrap">
                3
              </button>
              <button className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 hover:bg-gray-50 cursor-pointer whitespace-nowrap">
                下一页
              </button>
            </div>
          </div>
        </div>

        {/* 合规提示 */}
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-blue-600 text-xl w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5"></i>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-900 mb-1">合规说明</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                客户行为分析仅用于提升服务体验,服务升级需经客户沟通确认后执行。
                所有跟进建议仅为服务提示,不构成投资建议或收益承诺。
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default CustomersPage;
