import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

interface MenuItem {
  id: string;
  label: string;
  icon: string;
  path: string;
  badge?: number;
  children?: MenuItem[];
}

const menuItems: MenuItem[] = [
  { id: 'home', label: '首页', icon: 'ri-home-4-line', path: '/' },
  { id: 'customers', label: '客户管理', icon: 'ri-team-line', path: '/customers', badge: 3 },
  {
    id: 'supervisor',
    label: '团队管理',
    icon: 'ri-team-line',
    path: '/supervisor/dashboard',
    children: [
      { id: 'supervisor-dashboard', label: '团队总览', icon: 'ri-dashboard-line', path: '/supervisor/dashboard' },
      { id: 'supervisor-tasks', label: '任务管理', icon: 'ri-task-line', path: '/supervisor/tasks' },
    ],
  },
  {
    id: 'compliance',
    label: '合规风控',
    icon: 'ri-shield-check-line',
    path: '/compliance/dashboard',
    children: [
      { id: 'compliance-dashboard', label: '合规风控总览', icon: 'ri-dashboard-line', path: '/compliance/dashboard' },
      { id: 'compliance-review', label: '合规审核中心', icon: 'ri-file-list-3-line', path: '/compliance/review' },
      { id: 'compliance-warning', label: '预警中心', icon: 'ri-alarm-warning-line', path: '/compliance/warning' },
      { id: 'compliance-rules', label: '合规规则库', icon: 'ri-book-2-line', path: '/compliance/rules' },
    ],
  },
  { id: 'scripts', label: '话术库', icon: 'ri-chat-quote-line', path: '/scripts' },
  {
    id: 'advisory',
    label: '营销活动',
    icon: 'ri-briefcase-line',
    path: '/advisory-products',
    children: [
      { id: 'advisory-products', label: '产品库', icon: 'ri-store-line', path: '/advisory-products' },
      { id: 'advisory-content', label: '资讯库', icon: 'ri-article-line', path: '/advisory-content' },
      { id: 'advisory-activities', label: '活动中心', icon: 'ri-calendar-event-line', path: '/advisory-activities' },
      { id: 'advisory-recommendations', label: '个性化推荐', icon: 'ri-lightbulb-line', path: '/advisory-recommendations' },
      { id: 'content-marketing', label: '投教赋能', icon: 'ri-magic-line', path: '/content-marketing' },
    ],
  },
  { id: 'performance', label: '业绩数据', icon: 'ri-bar-chart-box-line', path: '/service' },
  { id: 'settings', label: '系统设置', icon: 'ri-settings-3-line', path: '/settings' },
];

export default function Sidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState<string[]>(['advisory']);

  const isActive = (path: string) => location.pathname === path;

  const toggleExpand = (menuId: string) => {
    if (expandedMenus.includes(menuId)) {
      setExpandedMenus(expandedMenus.filter((id) => id !== menuId));
    } else {
      setExpandedMenus([...expandedMenus, menuId]);
    }
  };

  return (
    <aside 
      className={`fixed top-14 left-0 bottom-0 bg-white border-r border-gray-200 transition-all duration-300 ${
        collapsed ? 'w-16' : 'w-56'
      }`}
    >
      <nav className="h-full flex flex-col">
        {/* 导航菜单 */}
        <div className="flex-1 py-4 overflow-y-auto">
          {menuItems.map((item) => (
            <div key={item.id}>
              {item.children ? (
                // 有子菜单的项
                <div>
                  <button
                    onClick={() => {
                      if (collapsed) {
                        setCollapsed(false);
                        setExpandedMenus([...expandedMenus, item.id]);
                      } else {
                        toggleExpand(item.id);
                      }
                    }}
                    className={`w-full px-4 py-2.5 flex items-center gap-3 transition-colors cursor-pointer whitespace-nowrap ${
                      location.pathname.startsWith('/advisory') || location.pathname.startsWith('/supervisor') || location.pathname.startsWith('/compliance')
                        ? (location.pathname.startsWith('/advisory') && item.id === 'advisory') ||
                          (location.pathname.startsWith('/supervisor') && item.id === 'supervisor') ||
                          (location.pathname.startsWith('/compliance') && item.id === 'compliance')
                          ? 'bg-blue-50 text-blue-600'
                          : 'text-gray-600 hover:bg-gray-50'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <i className={`${item.icon} text-lg w-5 h-5 flex items-center justify-center flex-shrink-0`}></i>
                    {!collapsed && (
                      <>
                        <span className="text-sm font-medium flex-1 text-left">{item.label}</span>
                        <i
                          className={`ri-arrow-${
                            expandedMenus.includes(item.id) ? 'down' : 'right'
                          }-s-line text-lg w-5 h-5 flex items-center justify-center transition-transform`}
                        ></i>
                      </>
                    )}
                  </button>
                  {!collapsed && expandedMenus.includes(item.id) && (
                    <div className="bg-gray-50">
                      {item.children.map((child) => (
                        <button
                          key={child.id}
                          onClick={() => navigate(child.path)}
                          className={`w-full pl-12 pr-4 py-2 flex items-center gap-3 transition-colors cursor-pointer whitespace-nowrap ${
                            isActive(child.path)
                              ? 'bg-blue-100 text-blue-600 border-r-2 border-blue-600'
                              : 'text-gray-600 hover:bg-gray-100'
                          }`}
                        >
                          <i className={`${child.icon} text-base w-4 h-4 flex items-center justify-center flex-shrink-0`}></i>
                          <span className="text-sm font-medium">{child.label}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                // 普通菜单项
                <button
                  onClick={() => navigate(item.path)}
                  className={`w-full px-4 py-2.5 flex items-center gap-3 transition-colors cursor-pointer whitespace-nowrap ${
                    isActive(item.path)
                      ? 'bg-blue-50 text-blue-600 border-r-2 border-blue-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <i className={`${item.icon} text-lg w-5 h-5 flex items-center justify-center flex-shrink-0`}></i>
                  {!collapsed && (
                    <>
                      <span className="text-sm font-medium flex-1 text-left">{item.label}</span>
                      {item.badge && (
                        <span className="px-1.5 py-0.5 bg-red-500 text-white text-xs rounded-full min-w-[18px] text-center">
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                </button>
              )}
            </div>
          ))}
        </div>

        {/* 折叠按钮 */}
        <div className="p-4 border-t border-gray-200">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-full h-9 flex items-center justify-center text-gray-500 hover:text-gray-700 hover:bg-gray-50 rounded-md transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className={`${collapsed ? 'ri-menu-unfold-line' : 'ri-menu-fold-line'} text-lg w-5 h-5 flex items-center justify-center`}></i>
            {!collapsed && <span className="ml-2 text-sm">收起菜单</span>}
          </button>
        </div>
      </nav>
    </aside>
  );
}
