import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import MainLayout from '../../../../components/layout/MainLayout';
import PageHeader from '../../../../components/common/PageHeader';
import Button from '../../../../components/common/Button';

// 模拟客户经理详细数据
const getManagerDetail = (id: string) => {
  const managers: Record<string, any> = {
    'M001': {
      id: 'M001',
      name: '张经理',
      code: 'M001',
      team: '华东一区',
      customerCount: 128,
      joinDate: '2022-03-15',
      
      // 个人业绩指标
      performance: {
        conversionRate: 78.5,
        productRecommendations: 56,
        productDeals: 29,
        sleepingCustomerWakeupRate: 65.2,
        newCustomers: 15,
        customerSatisfaction: 4.9,
      },
      
      // 话术使用分析
      scriptAnalysis: {
        totalUsage: 156,
        styleDistribution: [
          { style: '亲切型', count: 58, percentage: 37.2, conversionRate: 82.3, trend: 'high' },
          { style: '专业型', count: 45, percentage: 28.8, conversionRate: 75.6, trend: 'medium' },
          { style: '简洁型', count: 32, percentage: 20.5, conversionRate: 68.8, trend: 'medium' },
          { style: '严谨型', count: 21, percentage: 13.5, conversionRate: 71.4, trend: 'low' },
        ],
        sceneDistribution: [
          { scene: '开户关怀', count: 42, conversionRate: 78.6 },
          { scene: '产品推荐', count: 38, conversionRate: 73.7 },
          { scene: '客户唤醒', count: 28, conversionRate: 64.3 },
          { scene: '服务升级', count: 25, conversionRate: 80.0 },
          { scene: '投教内容', count: 23, conversionRate: 69.6 },
        ],
        highPerformanceInsights: [
          {
            title: '亲切型话术在新客户中表现优异',
            description: '使用亲切型话术与新开户客户沟通时，回复率达82.3%，继续沟通率71.8%',
            icon: 'ri-emotion-happy-line',
            color: 'green',
          },
          {
            title: '服务升级场景转化率最高',
            description: '在向高价值客户推荐服务升级时，成交转化率达80.0%',
            icon: 'ri-arrow-up-circle-line',
            color: 'blue',
          },
        ],
        lowPerformanceInsights: [
          {
            title: '沉睡客户唤醒话术使用频率偏低',
            description: '本月仅使用28次客户唤醒话术，建议加强对沉睡客户的主动触达',
            icon: 'ri-alarm-warning-line',
            color: 'orange',
          },
          {
            title: '严谨型话术使用较少',
            description: '严谨型话术仅占13.5%，但在高净值客户中效果较好，建议适当增加使用',
            icon: 'ri-file-list-line',
            color: 'red',
          },
        ],
      },
      
      // 产品推荐与转化分析
      productAnalysis: {
        topRecommendedProducts: [
          { name: '智能投顾服务 - 基础版', recommendations: 18, deals: 12, conversionRate: 66.7 },
          { name: '专属投顾服务 - 尊享版', recommendations: 15, deals: 8, conversionRate: 53.3 },
          { name: '家庭财富规划服务', recommendations: 12, deals: 5, conversionRate: 41.7 },
          { name: '投教课程包 - 进阶版', recommendations: 11, deals: 4, conversionRate: 36.4 },
        ],
        productTypePerformance: [
          { type: '基础投顾服务', recommendations: 28, deals: 18, conversionRate: 64.3, color: '#10B981' },
          { type: '高阶投顾服务', recommendations: 18, deals: 8, conversionRate: 44.4, color: '#3B82F6' },
          { type: '投教内容', recommendations: 10, deals: 3, conversionRate: 30.0, color: '#F59E0B' },
        ],
        unconvertedAnalysis: {
          totalRecommendations: 56,
          totalDeals: 29,
          unconvertedCount: 27,
          unconvertedRate: 48.2,
          mainReasons: [
            { reason: '客户表示需要时间考虑', count: 12, percentage: 44.4 },
            { reason: '客户认为价格偏高', count: 8, percentage: 29.6 },
            { reason: '客户暂无需求', count: 5, percentage: 18.5 },
            { reason: '其他原因', count: 2, percentage: 7.4 },
          ],
        },
      },
      
      // 客户类型分布与跟进表现
      customerTypeAnalysis: {
        distribution: [
          { type: '新开户客户', count: 35, percentage: 27.3, followUpRate: 94.3, conversionRate: 80.0 },
          { type: '高价值客户', count: 28, percentage: 21.9, followUpRate: 89.3, conversionRate: 75.0 },
          { type: '行为触发客户', count: 32, percentage: 25.0, followUpRate: 87.5, conversionRate: 71.9 },
          { type: '沉睡客户', count: 33, percentage: 25.8, followUpRate: 72.7, conversionRate: 60.6 },
        ],
      },
    },
    'M002': {
      id: 'M002',
      name: '李经理',
      code: 'M002',
      team: '华东一区',
      customerCount: 115,
      joinDate: '2022-06-20',
      
      performance: {
        conversionRate: 72.3,
        productRecommendations: 48,
        productDeals: 23,
        sleepingCustomerWakeupRate: 58.7,
        newCustomers: 12,
        customerSatisfaction: 4.7,
      },
      
      scriptAnalysis: {
        totalUsage: 132,
        styleDistribution: [
          { style: '专业型', count: 52, percentage: 39.4, conversionRate: 76.9, trend: 'high' },
          { style: '亲切型', count: 38, percentage: 28.8, conversionRate: 78.9, trend: 'high' },
          { style: '简洁型', count: 28, percentage: 21.2, conversionRate: 67.9, trend: 'medium' },
          { style: '严谨型', count: 14, percentage: 10.6, conversionRate: 71.4, trend: 'low' },
        ],
        sceneDistribution: [
          { scene: '开户关怀', count: 38, conversionRate: 76.3 },
          { scene: '产品推荐', count: 32, conversionRate: 71.9 },
          { scene: '客户唤醒', count: 22, conversionRate: 59.1 },
          { scene: '服务升级', count: 20, conversionRate: 75.0 },
          { scene: '投教内容', count: 20, conversionRate: 65.0 },
        ],
        highPerformanceInsights: [
          {
            title: '专业型话术表现稳定',
            description: '专业型话术使用频率最高，转化率达76.9%，适合当前客户群体',
            icon: 'ri-medal-line',
            color: 'green',
          },
        ],
        lowPerformanceInsights: [
          {
            title: '客户唤醒场景转化率偏低',
            description: '沉睡客户唤醒转化率仅59.1%，建议优化沟通策略',
            icon: 'ri-alarm-warning-line',
            color: 'orange',
          },
        ],
      },
      
      productAnalysis: {
        topRecommendedProducts: [
          { name: '智能投顾服务 - 基础版', recommendations: 16, deals: 10, conversionRate: 62.5 },
          { name: '专属投顾服务 - 尊享版', recommendations: 12, deals: 6, conversionRate: 50.0 },
          { name: '家庭财富规划服务', recommendations: 10, deals: 4, conversionRate: 40.0 },
          { name: '投教课程包 - 进阶版', recommendations: 10, deals: 3, conversionRate: 30.0 },
        ],
        productTypePerformance: [
          { type: '基础投顾服务', recommendations: 24, deals: 14, conversionRate: 58.3, color: '#10B981' },
          { type: '高阶投顾服务', recommendations: 16, deals: 7, conversionRate: 43.8, color: '#3B82F6' },
          { type: '投教内容', recommendations: 8, deals: 2, conversionRate: 25.0, color: '#F59E0B' },
        ],
        unconvertedAnalysis: {
          totalRecommendations: 48,
          totalDeals: 23,
          unconvertedCount: 25,
          unconvertedRate: 52.1,
          mainReasons: [
            { reason: '客户表示需要时间考虑', count: 11, percentage: 44.0 },
            { reason: '客户认为价格偏高', count: 7, percentage: 28.0 },
            { reason: '客户暂无需求', count: 5, percentage: 20.0 },
            { reason: '其他原因', count: 2, percentage: 8.0 },
          ],
        },
      },
      
      customerTypeAnalysis: {
        distribution: [
          { type: '新开户客户', count: 30, percentage: 26.1, followUpRate: 90.0, conversionRate: 76.7 },
          { type: '高价值客户', count: 25, percentage: 21.7, followUpRate: 88.0, conversionRate: 72.0 },
          { type: '行为触发客户', count: 28, percentage: 24.3, followUpRate: 85.7, conversionRate: 67.9 },
          { type: '沉睡客户', count: 32, percentage: 27.8, followUpRate: 68.8, conversionRate: 56.3 },
        ],
      },
    },
  };
  
  return managers[id] || managers['M001'];
};

const SupervisorMemberDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const manager = getManagerDetail(id || 'M001');
  
  const [selectedPeriod, setSelectedPeriod] = useState('30');

  return (
    <MainLayout>
      <PageHeader
        title="客户经理表现分析"
        description="深入分析客户经理的服务能力与转化表现"
        breadcrumb={[
          { label: '团队管理', path: '/supervisor/dashboard' },
          { label: '客户经理分析' }
        ]}
      />

      <div className="p-6 space-y-6">
        {/* 统计周期选择 */}
        <div className="flex items-center justify-between">
          <div className="text-sm text-gray-500">
            当前统计周期：<span className="font-medium text-gray-900">近{selectedPeriod}天</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedPeriod('7')}
              className={`px-4 py-2 text-sm rounded-lg border cursor-pointer whitespace-nowrap transition-colors ${
                selectedPeriod === '7'
                  ? 'bg-teal-50 border-teal-500 text-teal-700'
                  : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
              }`}
            >
              近7天
            </button>
            <button
              onClick={() => setSelectedPeriod('30')}
              className={`px-4 py-2 text-sm rounded-lg border cursor-pointer whitespace-nowrap transition-colors ${
                selectedPeriod === '30'
                  ? 'bg-teal-50 border-teal-500 text-teal-700'
                  : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
              }`}
            >
              近30天
            </button>
            <button
              onClick={() => setSelectedPeriod('90')}
              className={`px-4 py-2 text-sm rounded-lg border cursor-pointer whitespace-nowrap transition-colors ${
                selectedPeriod === '90'
                  ? 'bg-teal-50 border-teal-500 text-teal-700'
                  : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300'
              }`}
            >
              近90天
            </button>
          </div>
        </div>

        {/* 1️⃣ 客户经理基础信息区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center text-white text-2xl font-semibold">
                {manager.name.charAt(0)}
              </div>
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-2xl font-semibold text-gray-900">{manager.name}</h1>
                  <span className="px-3 py-1 bg-teal-50 text-teal-700 text-sm font-medium rounded-full">
                    {manager.code}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600">
                  <span>所属团队：{manager.team}</span>
                  <span>•</span>
                  <span>入职日期：{manager.joinDate}</span>
                </div>
              </div>
            </div>
            <Button onClick={() => navigate('/supervisor/dashboard')}>
              <i className="ri-arrow-left-line mr-2"></i>
              返回团队总览
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-6 mt-6 pt-6 border-t border-gray-200">
            <div className="text-center">
              <div className="text-3xl font-bold text-teal-600 mb-1">{manager.customerCount}</div>
              <div className="text-sm text-gray-500">当前负责客户数</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-1">{manager.performance.newCustomers}</div>
              <div className="text-sm text-gray-500">本月新增客户</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-amber-600 mb-1">{manager.performance.customerSatisfaction}</div>
              <div className="text-sm text-gray-500">客户满意度评分</div>
            </div>
          </div>
        </div>

        {/* 2️⃣ 个人业绩指标区 */}
        <div>
          <h3 className="text-base font-semibold text-gray-900 mb-4">个人业绩指标</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* 开户转化率 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
                  <i className="ri-arrow-right-up-line text-green-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{manager.performance.conversionRate}%</div>
              <div className="text-sm text-gray-500">开户转化率</div>
              <div className="mt-3 w-full bg-gray-100 rounded-full h-2">
                <div
                  className="h-2 rounded-full bg-green-500 transition-all"
                  style={{ width: `${manager.performance.conversionRate}%` }}
                ></div>
              </div>
            </div>

            {/* 产品推荐次数 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
                  <i className="ri-lightbulb-line text-purple-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{manager.performance.productRecommendations}</div>
              <div className="text-sm text-gray-500">产品推荐次数</div>
            </div>

            {/* 产品成交次数 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center">
                  <i className="ri-checkbox-circle-line text-orange-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{manager.performance.productDeals}</div>
              <div className="text-sm text-gray-500">产品成交次数</div>
            </div>

            {/* 沉睡客户唤醒率 */}
            <div className="bg-white border border-gray-200 rounded-lg p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                  <i className="ri-refresh-line text-blue-600 text-xl w-5 h-5 flex items-center justify-center"></i>
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{manager.performance.sleepingCustomerWakeupRate}%</div>
              <div className="text-sm text-gray-500">沉睡客户唤醒率</div>
              <div className="mt-3 w-full bg-gray-100 rounded-full h-2">
                <div
                  className="h-2 rounded-full bg-blue-500 transition-all"
                  style={{ width: `${manager.performance.sleepingCustomerWakeupRate}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* 3️⃣ 会话与话术使用分析区（重点） */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-5">会话与话术使用分析</h3>

          {/* 话术使用总览 */}
          <div className="mb-6 p-4 bg-gradient-to-r from-teal-50 to-blue-50 rounded-lg border border-teal-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-teal-600 rounded-lg flex items-center justify-center">
                  <i className="ri-message-3-line text-white text-xl"></i>
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">{manager.scriptAnalysis.totalUsage}</div>
                  <div className="text-sm text-gray-600">话术使用总次数</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-500 mb-1">平均每日使用</div>
                <div className="text-lg font-semibold text-teal-600">
                  {(manager.scriptAnalysis.totalUsage / parseInt(selectedPeriod)).toFixed(1)} 次
                </div>
              </div>
            </div>
          </div>

          {/* 话术风格分布与转化率 */}
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-900 mb-4">话术风格使用分布与转化表现</h4>
            <div className="space-y-3">
              {manager.scriptAnalysis.styleDistribution.map((item) => (
                <div key={item.style} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium text-gray-900">{item.style}</span>
                      <span className="text-xs text-gray-500">使用 {item.count} 次 ({item.percentage}%)</span>
                      {item.trend === 'high' && (
                        <span className="px-2 py-0.5 bg-green-100 text-green-700 text-xs rounded-full">
                          高转化
                        </span>
                      )}
                      {item.trend === 'medium' && (
                        <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">
                          中等转化
                        </span>
                      )}
                      {item.trend === 'low' && (
                        <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded-full">
                          待提升
                        </span>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-semibold text-gray-900">转化率 {item.conversionRate}%</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <div className="text-xs text-gray-500 mb-1">使用占比</div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="h-2 rounded-full bg-teal-500 transition-all"
                          style={{ width: `${item.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="text-xs text-gray-500 mb-1">转化率</div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="h-2 rounded-full bg-green-500 transition-all"
                          style={{ width: `${item.conversionRate}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 话术场景分布 */}
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-900 mb-4">话术场景使用分布</h4>
            <div className="grid grid-cols-5 gap-3">
              {manager.scriptAnalysis.sceneDistribution.map((item) => (
                <div key={item.scene} className="p-3 bg-gray-50 rounded-lg text-center">
                  <div className="text-lg font-bold text-gray-900 mb-1">{item.count}</div>
                  <div className="text-xs text-gray-500 mb-2">{item.scene}</div>
                  <div className="text-xs font-medium text-teal-600">转化 {item.conversionRate}%</div>
                </div>
              ))}
            </div>
          </div>

          {/* 高转化话术洞察 */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-medal-line text-green-600 w-5 h-5 flex items-center justify-center"></i>
              <h4 className="text-sm font-semibold text-gray-900">高转化话术洞察</h4>
            </div>
            <div className="space-y-3">
              {manager.scriptAnalysis.highPerformanceInsights.map((insight, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border-2 ${
                    insight.color === 'green'
                      ? 'bg-green-50 border-green-200'
                      : 'bg-blue-50 border-blue-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <i
                      className={`${insight.icon} text-xl w-6 h-6 flex items-center justify-center ${
                        insight.color === 'green' ? 'text-green-600' : 'text-blue-600'
                      }`}
                    ></i>
                    <div className="flex-1">
                      <div
                        className={`text-sm font-medium mb-1 ${
                          insight.color === 'green' ? 'text-green-900' : 'text-blue-900'
                        }`}
                      >
                        {insight.title}
                      </div>
                      <div
                        className={`text-xs leading-relaxed ${
                          insight.color === 'green' ? 'text-green-700' : 'text-blue-700'
                        }`}
                      >
                        {insight.description}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 待提升话术洞察 */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <i className="ri-focus-line text-orange-600 w-5 h-5 flex items-center justify-center"></i>
              <h4 className="text-sm font-semibold text-gray-900">待提升话术洞察</h4>
            </div>
            <div className="space-y-3">
              {manager.scriptAnalysis.lowPerformanceInsights.map((insight, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${
                    insight.color === 'orange'
                      ? 'bg-orange-50 border-orange-200'
                      : 'bg-red-50 border-red-200'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <i
                      className={`${insight.icon} text-xl w-6 h-6 flex items-center justify-center ${
                        insight.color === 'orange' ? 'text-orange-600' : 'text-red-600'
                      }`}
                    ></i>
                    <div className="flex-1">
                      <div
                        className={`text-sm font-medium mb-1 ${
                          insight.color === 'orange' ? 'text-orange-900' : 'text-red-900'
                        }`}
                      >
                        {insight.title}
                      </div>
                      <div
                        className={`text-xs leading-relaxed ${
                          insight.color === 'orange' ? 'text-orange-700' : 'text-red-700'
                        }`}
                      >
                        {insight.description}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 4️⃣ 产品推荐与转化分析区 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-5">产品推荐与转化分析</h3>

          {/* 推荐最多的产品 */}
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-900 mb-4">推荐最多的投顾产品</h4>
            <div className="space-y-3">
              {manager.productAnalysis.topRecommendedProducts.map((product, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-teal-100 rounded-full flex items-center justify-center text-teal-700 font-semibold text-sm">
                        {index + 1}
                      </div>
                      <span className="text-sm font-medium text-gray-900">{product.name}</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <div className="text-xs text-gray-500">推荐次数</div>
                        <div className="text-sm font-semibold text-gray-900">{product.recommendations}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-500">成交次数</div>
                        <div className="text-sm font-semibold text-gray-900">{product.deals}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-500">转化率</div>
                        <div className="text-sm font-semibold text-green-600">{product.conversionRate}%</div>
                      </div>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full bg-green-500 transition-all"
                      style={{ width: `${product.conversionRate}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 产品类型转化表现 */}
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-gray-900 mb-4">产品类型转化表现</h4>
            <div className="grid grid-cols-3 gap-4">
              {manager.productAnalysis.productTypePerformance.map((type) => (
                <div key={type.type} className="p-4 bg-gray-50 rounded-lg">
                  <div className="text-sm font-medium text-gray-900 mb-3">{type.type}</div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500">推荐</span>
                      <span className="font-medium text-gray-900">{type.recommendations} 次</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500">成交</span>
                      <span className="font-medium text-gray-900">{type.deals} 次</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-500">转化率</span>
                      <span className="font-semibold" style={{ color: type.color }}>
                        {type.conversionRate}%
                      </span>
                    </div>
                  </div>
                  <div className="mt-3 w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="h-2 rounded-full transition-all"
                      style={{ width: `${type.conversionRate}%`, backgroundColor: type.color }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 推荐后未成交分析 */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-4">推荐后未成交分析</h4>
            <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <i className="ri-alert-line text-amber-600 text-xl"></i>
                  <div>
                    <div className="text-sm font-medium text-amber-900">
                      未成交占比：{manager.productAnalysis.unconvertedAnalysis.unconvertedRate}%
                    </div>
                    <div className="text-xs text-amber-700">
                      共 {manager.productAnalysis.unconvertedAnalysis.unconvertedCount} 次推荐未成交
                    </div>
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="text-xs font-medium text-amber-900 mb-2">主要原因分布：</div>
                {manager.productAnalysis.unconvertedAnalysis.mainReasons.map((reason, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center gap-2 flex-1">
                      <div className="w-2 h-2 bg-amber-600 rounded-full"></div>
                      <span className="text-xs text-amber-800">{reason.reason}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-medium text-amber-900">{reason.count} 次</span>
                      <span className="text-xs text-amber-700">({reason.percentage}%)</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 客户类型分布与跟进表现 */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-5">客户类型分布与跟进表现</h3>
          <div className="space-y-3">
            {manager.customerTypeAnalysis.distribution.map((type) => (
              <div key={type.type} className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-gray-900">{type.type}</span>
                    <span className="text-xs text-gray-500">
                      {type.count} 人 ({type.percentage}%)
                    </span>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <div className="text-xs text-gray-500">跟进率</div>
                      <div className="text-sm font-semibold text-blue-600">{type.followUpRate}%</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-gray-500">转化率</div>
                      <div className="text-sm font-semibold text-green-600">{type.conversionRate}%</div>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <div className="text-xs text-gray-500 mb-1">跟进率</div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="h-2 rounded-full bg-blue-500 transition-all"
                        style={{ width: `${type.followUpRate}%` }}
                      ></div>
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500 mb-1">转化率</div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="h-2 rounded-full bg-green-500 transition-all"
                        style={{ width: `${type.conversionRate}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 5️⃣ 主管辅助决策建议区 */}
        <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border border-purple-200 p-6">
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center flex-shrink-0">
              <i className="ri-sparkling-line text-white text-lg"></i>
            </div>
            <div className="flex-1">
              <h3 className="text-base font-semibold text-gray-900 mb-2">主管辅助决策建议</h3>
              <p className="text-sm text-gray-600">
                基于该客户经理的表现数据，系统生成以下管理建议供参考
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {/* 建议1：话术使用优化 */}
            <div className="bg-white rounded-lg p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-chat-quote-line text-teal-600"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-900 mb-1">
                    建议加强沉睡客户唤醒话术使用
                  </div>
                  <div className="text-xs text-gray-600 leading-relaxed mb-2">
                    该客户经理在沉睡客户唤醒场景的话术使用频率偏低，
                    建议通过专项任务或培训，提升对沉睡客户的主动触达能力。
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate('/supervisor/tasks/create')}
                      className="px-3 py-1.5 bg-teal-600 text-white text-xs rounded hover:bg-teal-700 cursor-pointer whitespace-nowrap"
                    >
                      发布专项任务
                    </button>
                    <button
                      onClick={() => alert('查看相关话术')}
                      className="px-3 py-1.5 border border-gray-300 text-gray-700 text-xs rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                    >
                      查看相关话术
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 建议2：产品推荐优化 */}
            <div className="bg-white rounded-lg p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-lightbulb-line text-purple-600"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-900 mb-1">
                    建议优先推荐基础投顾服务
                  </div>
                  <div className="text-xs text-gray-600 leading-relaxed mb-2">
                    该客户经理在基础投顾服务的转化率表现优异（{manager.productAnalysis.productTypePerformance[0].conversionRate}%），
                    建议在客户沟通中优先推荐此类产品，提升整体成交率。
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate('/advisory-products')}
                      className="px-3 py-1.5 bg-purple-600 text-white text-xs rounded hover:bg-purple-700 cursor-pointer whitespace-nowrap"
                    >
                      查看产品详情
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* 建议3：客户分层运营 */}
            <div className="bg-white rounded-lg p-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-user-settings-line text-blue-600"></i>
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-gray-900 mb-1">
                    建议针对沉睡客户开展专项唤醒任务
                  </div>
                  <div className="text-xs text-gray-600 leading-relaxed mb-2">
                    该客户经理负责的沉睡客户占比为 {manager.customerTypeAnalysis.distribution[3].percentage}%，
                    跟进率和转化率相对较低，建议制定专项唤醒计划，提升客户活跃度。
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => navigate('/supervisor/tasks/create')}
                      className="px-3 py-1.5 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 cursor-pointer whitespace-nowrap"
                    >
                      创建唤醒任务
                    </button>
                    <button
                      onClick={() => navigate('/follow-up/sleeping')}
                      className="px-3 py-1.5 border border-gray-300 text-gray-700 text-xs rounded hover:bg-gray-50 cursor-pointer whitespace-nowrap"
                    >
                      查看沉睡客户
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-purple-100 rounded-lg">
            <p className="text-xs text-purple-800">
              <i className="ri-information-line mr-1"></i>
              以上建议基于数据分析生成，仅供管理决策参考，不构成强制执行要求
            </p>
          </div>
        </div>

        {/* 操作按钮区 */}
        <div className="flex gap-4">
          <Button
            type="primary"
            onClick={() => navigate('/supervisor/tasks/create')}
            className="flex-1"
          >
            <i className="ri-task-line mr-2"></i>
            为该客户经理发布任务
          </Button>
          <Button
            onClick={() => navigate('/supervisor/dashboard')}
            className="flex-1"
          >
            <i className="ri-arrow-left-line mr-2"></i>
            返回团队总览
          </Button>
        </div>
      </div>
    </MainLayout>
  );
};

export default SupervisorMemberDetailPage;
