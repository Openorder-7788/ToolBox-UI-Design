import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MainLayout from '../../../components/layout/MainLayout';
import PageHeader from '../../../components/common/PageHeader';
import Button from '../../../components/common/Button';
import StatusTag from '../../../components/common/StatusTag';
import { behaviorTriggerCustomers } from '../../../mocks/followUpTasks';

export default function BehaviorFollowUp() {
  const navigate = useNavigate();
  const [customers] = useState(behaviorTriggerCustomers);

  const getTriggerTypeColor = (type: string) => {
    switch (type) {
      case '浏览未购买':
        return 'bg-blue-50 text-blue-600 border-blue-200';
      case '活动未完成':
        return 'bg-green-50 text-green-600 border-green-200';
      case '内容反复查看':
        return 'bg-purple-50 text-purple-600 border-purple-200';
      default:
        return 'bg-gray-50 text-gray-600 border-gray-200';
    }
  };

  return (
    <MainLayout>
      <PageHeader
        title="行为触发客户待跟进"
        description="客户近期出现明显行为信号，建议抓住服务沟通窗口"
        breadcrumbs={[
          { label: '首页', path: '/' },
          { label: '客户跟进', path: '/' },
          { label: '行为触发客户待跟进' },
        ]}
        actions={
          <div className="flex items-center gap-3">
            <Button type="default" icon="ri-download-line">
              导出列表
            </Button>
            <Button type="primary" icon="ri-refresh-line">
              刷新数据
            </Button>
          </div>
        }
      />

      <div className="p-6">
        {/* 统计卡片 */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">待跟进客户</div>
                <div className="text-3xl font-bold text-gray-900">{customers.length}</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-user-search-line text-2xl text-green-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">浏览未购买</div>
                <div className="text-3xl font-bold text-gray-900">5</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-eye-line text-2xl text-blue-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 border border-purple-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">活动未完成</div>
                <div className="text-3xl font-bold text-gray-900">4</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-calendar-todo-line text-2xl text-purple-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-orange-50 to-orange-100 border border-orange-200 rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-600 mb-1">内容反复查看</div>
                <div className="text-3xl font-bold text-gray-900">3</div>
              </div>
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                <i className="ri-repeat-line text-2xl text-orange-600 w-6 h-6 flex items-center justify-center"></i>
              </div>
            </div>
          </div>
        </div>

        {/* 客户列表 */}
        <div className="bg-white border border-gray-200 rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-semibold text-gray-900">客户列表</h3>
              <div className="flex items-center gap-3">
                <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                  <option>全部触发类型</option>
                  <option>浏览未购买</option>
                  <option>活动未完成</option>
                  <option>内容反复查看</option>
                </select>
                <select className="px-3 py-1.5 text-sm border border-gray-300 rounded-md bg-white text-gray-700 cursor-pointer">
                  <option>按触发时间排序</option>
                  <option>按资产规模排序</option>
                  <option>按最近联系排序</option>
                </select>
              </div>
            </div>
          </div>

          <div className="divide-y divide-gray-200">
            {customers.map((customer) => (
              <div
                key={customer.id}
                className="p-6 hover:bg-gray-50 transition-colors cursor-pointer"
                onClick={() => navigate(`/follow-up/behavior/${customer.id}`)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4 flex-1">
                    {/* 客户头像 */}
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center text-white text-lg font-medium flex-shrink-0 relative">
                      {customer.name.charAt(0)}
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white"></div>
                    </div>

                    {/* 客户信息 */}
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-base font-semibold text-gray-900">{customer.name}</h4>
                        <span className="text-sm text-gray-500">{customer.id}</span>
                        <StatusTag type="warning" label={customer.riskLevel} />
                        <span className={`px-2 py-1 text-xs rounded border ${getTriggerTypeColor(customer.triggerType)}`}>
                          {customer.triggerType}
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-4 mb-3">
                        <div className="text-sm">
                          <span className="text-gray-500">联系方式：</span>
                          <span className="text-gray-900">{customer.phone}</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">资产规模：</span>
                          <span className="text-gray-900">{customer.assets}</span>
                        </div>
                        <div className="text-sm">
                          <span className="text-gray-500">触发时间：</span>
                          <span className="text-red-600">{customer.triggerTime}</span>
                        </div>
                      </div>
                      <div className="mb-3">
                        <div className="flex items-start gap-2 text-sm bg-green-50 border border-green-100 rounded p-3">
                          <i className="ri-flashlight-line text-green-600 w-4 h-4 flex items-center justify-center flex-shrink-0 mt-0.5"></i>
                          <div>
                            <span className="font-medium text-gray-900">触发行为：</span>
                            <span className="text-gray-700">{customer.behaviorDetail}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-500">关注点：</span>
                        {customer.focusPoint.map((point, index) => (
                          <span
                            key={index}
                            className="px-2 py-0.5 bg-blue-50 text-blue-600 text-xs rounded"
                          >
                            {point}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 操作按钮 */}
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      type="default"
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/follow-up/behavior/${customer.id}`);
                      }}
                    >
                      查看详情
                    </Button>
                    <Button
                      type="primary"
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        console.log('开始跟进', customer.id);
                      }}
                    >
                      立即跟进
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 跟进提示 */}
        <div className="mt-6 bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <i className="ri-information-line text-green-600 text-xl w-5 h-5 flex items-center justify-center flex-shrink-0 mt-0.5"></i>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-gray-900 mb-1">跟进建议</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                行为触发客户通常有明确的兴趣点，建议在触发后 24 小时内完成跟进。
                沟通时采用"解释型/提示型"方式，针对客户关注的内容进行专业解答，不使用催促或诱导话术。
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
